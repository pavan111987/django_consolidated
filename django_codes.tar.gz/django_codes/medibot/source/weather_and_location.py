import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random


def geo_loc(q):
  url = str('http://maps.googleapis.com/maps/api/geocode/json?address='+q)
  response = urllib.urlopen(url)
  data = json.loads(response.read())
  if (len(data['results'][0]['formatted_address'].split(','))<=2):
    return (str(','.join([data['results'][0]['formatted_address'].split(',')[-len(data['results'][0]['formatted_address'].split(','))],data['results'][0]['formatted_address'].split(',')[-1]])))
  else:
    return (str(','.join([data['results'][0]['formatted_address'].split(',')[-3],data['results'][0]['formatted_address'].split(',')[-1]])))



def weatherapi(location):
  owm = pyowm.OWM("611c26dae2bb2b138e30811e66721dca")	
  observation = owm.weather_at_place(str(location))
  w=observation.get_weather()
  temperature=w.get_temperature('celsius')["temp"]
  weather_cond=w.get_detailed_status()
  return weather_cond , temperature



def weather_by_latlon(lat,lon):
  owm = pyowm.OWM("611c26dae2bb2b138e30811e66721dca")	
  obs = owm.weather_at_coords(lat,lon)
  mn=round(json.loads(obs.to_JSON())['Weather']['temperature']['temp_min']-273,2)
  mx=round(json.loads(obs.to_JSON())['Weather']['temperature']['temp_max']-273,2)
  weather_cond=str(json.loads(obs.to_JSON())['Weather']['detailed_status'])
  temperature=round(json.loads(obs.to_JSON())['Weather']['temperature']['temp']-273,2)
  return weather_cond , temperature, mn, mx


def location_by_latlon(lat,lon):
  owm = pyowm.OWM("611c26dae2bb2b138e30811e66721dca")	
  observation = owm.weather_at_coords(lat,lon)
  w=observation.get_location()
  location=w.get_name()
  return location

