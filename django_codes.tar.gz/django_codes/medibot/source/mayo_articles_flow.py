import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *
from symptoms_cosymptoms import *
from dd_functions import *
from weather_and_location import *
from symptom_to_speciality import *
from mayo_articles_code import *
from name_to_gender import *
from drugs_code import *
from diagnostics_code import *
from chatbot_datafiles_code import *
from json_response_code import *
from symptom_checker_flow import *


words=stopwords.words('english')


def mayo_flow(mob,sessid,ip,request_type):
  if (str(read_sess_flow_id(sessid))=='mayo_articles_flow'):
    if (read_sess_name(sessid)!=''):
      text=nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+', what do you want to know?'
    else:
      text='What do you want to know?' 
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_mayo_articles_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_mayo_articles_flow'):
    ip=ip
    a=mayo_articles_url(ip)
    options=[]
    if (a[0]!='404'):
      for i in a:
        options.append([i,'url'])
      sess_flow_id('get_mayo_feedback',sessid)
      text='Here is some information that you might find useful'
      op_json=url_list_response_json(text,options,sessid)
      return (op_json) 
    else:
      text=('I could not find any relevant articles based on your query')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='get_mayo_feedback'):
    text='Was this information helpful?'
    options=['Yes','No']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_feedback_response',sessid)
    return (op_json)

