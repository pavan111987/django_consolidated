import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *


words=stopwords.words('english')

##########################################################################################################################
################ start logging

def write_main_log(q,sessid):
  with open("/home/buildadmin/yash/call-health-server/medibot/source/log/all_log_text.txt", "a") as myfile:
    myfile.write(str(sessid)+','+str(q))
    myfile.write('\n')



#########################################################################################################################

############# capture general user input


def sess_input(ip,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_input.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    if (str(i[0])==str(sessid)):
      data[i[0]]=ip
      flag=1
    else:
      data[i[0]]=i[1]    
  if (flag==0):
    data[str(sessid)]=ip
  new_data=[]
  for i,j in data.items():
    new_data.append(re.sub('[,]','',i))
    new_data.append(re.sub('[,]','',j))
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_input.csv',new_data,delimiter=',',fmt="%s")


############################################################################################################################
################### Read general input by the user

def read_sess_input(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_input.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    if (str(i[0])==str(sessid)):
      return str(i[1])



############################################################################################################################
############ capture the flow id changes for users


def sess_flow_id(ip,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_flow_id.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    if (str(i[0])==str(sessid)):
      data[i[0]]=ip
      flag=1
    else:
      data[i[0]]=i[1]    
  if (flag==0):
    data[str(sessid)]=ip
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_flow_id.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################# DD status (correct,wrong) for users

def dd_status_log_counter(ip,sessid):
  ip=ip.lower()
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_status_log.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    data[i[0]]=i[1:]
    if (str(i[0])==str(sessid)):
      flag=1
  new_data={}
  for i,j in data.items():
    new_data[i]=[int(j[0]),int(j[1])]
    if (flag==1):
      if ((str(ip)=='y') and (str(sessid)==str(i))):
        new_data[i]=[int(j[0])+1,int(j[1])]
      if ((str(ip)=='n') and (str(sessid)==str(i))):
        new_data[i]=[int(j[0]),int(j[1])+1]
      if ((str(ip)=='0') and (str(sessid)==str(i))):
        new_data[sessid]=[0,0]
      continue
    if (flag==0):
      if (str(ip)=='y'):
        new_data[sessid]=[1,0]
      if (str(ip)=='n'):
        new_data[sessid]=[0,1]
      if (str(ip)=='0'):
        new_data[sessid]=[0,0]
      continue
  data=[]
  for i,j in new_data.items():
    data.append(i)
    for k in j:
      data.append(k)
  data=np.array(data).reshape((len(data)/3),3)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_status_log.csv',data,delimiter=',',fmt="%s")


#####################################################################################################################
################################# DD status (correct,wrong) for users

def read_dd_status_log_counter(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_status_log.csv')
  f=csv.reader(f)
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1],i[2])



#####################################################################################################################
######################################## capture symptoms list for users
 
def write_symps_log(sym,sessid):
  data={}
  flag=0  
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv')
  f=csv.reader(f) 
  for i in f:
    if (str(i[0])==str(sessid)):
      flag=1
    if (i[1]!=''):
      data[i[0]]=i[1].split('XXXXX')
    else:
      data[i[0]]=[]
  if (flag==0):
    data[sessid]=[]  
  new_data={}
  for i,j in data.items():
    if (str(i)==str(sessid)):
      j.append(sym)
      new_data[i]=j
    else:
      new_data[i]=j
  data=[]
  for i,j in new_data.items():
    data.append(i)
    data.append('XXXXX'.join(j)) 
  data=np.array(data).reshape((len(data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv',data,delimiter=',',fmt="%s")



#####################################################################################################################
######################################## read captured symptoms list for users
 
def read_symps_log(sessid):
  data={}
  flag=0  
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv')
  f=csv.reader(f) 
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1].split('XXXXX'))




############################################################################################################################
############ read the flow id changes for users


def read_sess_flow_id(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_flow_id.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1])




##############################################################################################################
################################## capture raw input of users

def sess_raw_input(msg,sessid):
  ip=raw_input(str(msg))
  return (ip,sessid)


##############################################################################################################
################################## read captured user info to see existing or new user 

def read_user_profile(mob):
  if (mob!='404'):
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/user_profiles.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1:]
    flag=0
    for i,j in data.items():
      if (str(mob)==i):
        flag=1
        break
    if (flag==0):
      return ('404')
    else:
      return (data[mob])
  else:
    return ('404')
   

##############################################################################################################
################################## read captured user info to see existing or new user 

def write_user_profile(mob,name,age,gender,location):
  if (mob!='404'):
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/user_profiles.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1:]
    data[mob]=[name,age,gender,location]
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      for k in j:
        new_data.append(k)
    new_data=np.array(new_data).reshape((len(new_data)/5),5)
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/user_profiles.csv',new_data,delimiter=',',fmt="%s") 
  else:
    return ('404')


#####################################################################################################################
################################## read sessid mobile number 

def read_sess_mob(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_mob.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid mobile number 

def write_sess_mob(mob,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_mob.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(mob)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_mob.csv',new_data,delimiter=',',fmt="%s")


#####################################################################################################################
################################## read sessid name 

def read_sess_name(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_name.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid name 

def write_sess_name(name,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_name.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(name)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_name.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################## read sessid age 

def read_sess_age(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_age.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid age 

def write_sess_age(age,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_age.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(age)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_age.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################## read sessid gender 

def read_sess_gender(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_gender.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid gender 

def write_sess_gender(gender,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_gender.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(gender)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_gender.csv',new_data,delimiter=',',fmt="%s")


#####################################################################################################################
################################## read sessid location 

def read_sess_location(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_location.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid location 

def write_sess_location(location,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_location.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(location)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_location.csv',new_data,delimiter=',',fmt="%s")


################################## write sessid latlon 

def write_sess_latlon(location,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_latlon.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(location)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_latlon.csv',new_data,delimiter=',',fmt="%s")


################################## read sessid latlon 

def read_sess_latlon(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_latlon.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp.split('XXXXX'))
  else:
    return ('404') 


################################## write sessid time 

def write_sess_time(time,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_time.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(time)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_time.csv',new_data,delimiter=',',fmt="%s")




################################## read sessid latlon 

def read_sess_time(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_time.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 




################################## write sessid me_someone 

def write_sess_me_someone(txt,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_me_someone.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(txt)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_me_someone.csv',new_data,delimiter=',',fmt="%s")



################################## read sessid me_someone 

def read_sess_me_someone(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_me_someone.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid brand
def write_sess_brand(txt,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_brand.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(txt)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_brand.csv',new_data,delimiter=',',fmt="%s")



################################## read sessid brand

def read_sess_brand(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_brand.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



