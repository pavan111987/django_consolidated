import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random


def sym_speciality(age,gender,q):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/categories.csv')
  f=csv.reader(f)
  keywords=[]
  score=[]
  cat=[]
  for i in f:
    keywords.append(i[0])
    score.append(float(i[2]))
    cat.append(i[3])
  cat_uniq=np.unique(cat)
  if (age>=13):
    temp=[]
    for i in cat_uniq:
      if (i!='Pediatrics'):
        temp.append(i)
    cat_uniq=temp
  if (gender=='m' or gender=='M'):
    temp=[]
    for i in cat_uniq:
      if (i!='Obstetrtics and Gynaecology'):
        temp.append(i)
    cat_uniq=temp
  vote=np.zeros((len(cat_uniq),1))
  cat_uniq=np.array(cat_uniq)
  for i in q.split():
    if i in keywords:
      try:
        vote[np.where(cat[np.where(i==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]=score[np.where(i==np.array(keywords))[0][0]]+vote[np.where(cat[np.where(i==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]
      except:
        pass
    else:
      d=[]
      if (i not in words):
        for j in keywords:
          try:
            d.append((1-dist(embeddings_index[i],embeddings_index[j])))
          except:
            d.append(0)
        try:
          vote[np.where(cat[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]=score[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]+vote[np.where(cat[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0] 
        except:
          pass
  if (np.sum(vote)>0): 
    return (cat_uniq[np.argmax(vote)])
  else:
    return ('404') 


