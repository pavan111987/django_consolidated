import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *
from chatbot_datafiles_code import *


words=stopwords.words('english')




################################## write blank response with 888 as code

def blank_response_json(sessid):
  op_json={}
  op_json['data']=''
  op_json['options']=[]
  op_json['sessid']=str(sessid)
  op_json['response_type']='blank_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 


################################## write text response

def text_response_json(text,sessid):
  q=('Bot: '+str(text))
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=[]
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 


################################## write text+single selection response

def text_ss_response_json(text,options,sessid):
  q=('Bot: '+str(text)).encode('utf-8').strip()
  t=[]
  for i in np.arange(len(options)):
    t.append(' option '+str(i)+': '+str(options[i]).encode('utf-8').strip()+',')
  t=''.join(t).encode('utf-8').strip()
  q=str(q)+str(t).encode('utf-8').strip()    
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_and_ss_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 



################################## write text+list response

def text_list_response_json(text,options,sessid):
  q=('Bot: '+str(text))
  t=[]
  for i in np.arange(len(options)):
    t.append(' option '+str(i)+': '+str(options[i])+',')
  t=''.join(t)
  q=str(q)+str(t)    
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_list_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 



################################## write text+list response

def url_list_response_json(text,options,sessid):
  q=('Bot: '+str(text))
  t=[]
  for i in np.arange(len(options)):
    t.append(' option '+str(i)+': '+str(options[i])+',')
  t=''.join(t)
  q=str(q)+str(t)    
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='url_list_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 




################################## write text+list response

def text_blank_response_json(text,options,flow_id,sessid):
  q=('Bot: '+str(re.sub('[^a-zA-Z0-9]',' ',text)))
  t=[]
  for i in np.arange(len(options)):
    t.append(' option '+str(i)+': '+str(options[i])+',')
  t=''.join(t)
  q=str(q)+str(t)    
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_blank_response'
  op_json['response_code']='888'
  sess_flow_id(flow_id,sessid)  
  return (json.dumps(op_json)) 


####################################### Main menu response with image embedded

def main_menu_response_json(sessid):
  op_json={}
  op_json['data']='' 
  op_json['options']=[['Symptom Checker','https://chat.callhealth.com/img/symptomchecker.png'],['Medicines','https://chat.callhealth.com/img/medicines.png'],['Diagnostic Tests','https://chat.callhealth.com/img/diagnostics.png'],['Know more about health','https://chat.callhealth.com/img/abouthealth.png']]
  op_json['sessid']=str(sessid)
  op_json['response_type']='main_menu_response'
  op_json['response_code']='888'
  return (json.dumps(op_json))



