import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from wish_date_time import *
from symptom_anticipation_nlp import *
from symptoms_cosymptoms import *
from dd_functions import *
from weather_and_location import *
from symptom_to_speciality import *
from mayo_articles_code import *
from name_to_gender import *
from drugs_code import *
from diagnostics_code import *
from chatbot_datafiles_code import *
from json_response_code import *
from symptom_checker_flow import *
from mayo_articles_flow import *
from drugs_chatbot_flow import *
from diag_chatbot_flow import *
from intro_chatbot import *

words=stopwords.words('english')

f=open('/home/buildadmin/yash/call-health-server/medibot/source/symptoms filter.csv')
f=csv.reader(f)
sym_male=[]
sym_female=[]
for i in f:
  if (i[1]=='Yes'):
    sym_male.append(i[0])
  if (i[2]=='Yes'):
    sym_female.append(i[0])



f=open('/home/buildadmin/yash/call-health-server/medibot/source/all_mdp_symp_crawl.csv')
f=csv.reader(f)

sym_crawl={}
sym_list_final=[]
for i in f:
  sym_crawl[i[0]]=[re.sub(' +',' ',re.sub('[0-9]','',i[1])).lower()]  
  sym_list_final.append(i[0].lower())



sym_mdp_map={}
f=open('/home/buildadmin/yash/call-health-server/medibot/source/matching syn sym.csv')
f=csv.reader(f)
for i in f:
  key=i[0]
  t=[]
  for j in i[1:]:
    if (j!=''):
      t.append(j)
  value=t
  sym_mdp_map[key]=value




embeddings_index = {}
f = open('/home/buildadmin/yash/call-health-server/medibot/source/glove.6B.300d.txt')
for line in f:
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    embeddings_index[word] = coefs


f.close()   



pubmed_index={}
f = open('/home/buildadmin/yash/call-health-server/medibot/source/pubmet categories.csv')
f=csv.reader(f)
for i in f:
  pubmed_index[i[0]]=i[1:3]




f=open('/home/buildadmin/yash/call-health-server/medibot/source/medical bayes test.csv')
f=csv.reader(f)
dis=[]
sym=[]
for i in f:
  dis.append(i[0].lower())
  sym.append(i[2].lower())



dis=dis[1:]
sym=sym[1:]
dis_final=np.unique(dis)
sym_final=np.unique(sym)


  
#################################################################################


f=open('/home/buildadmin/yash/call-health-server/medibot/source/medical bayes test.csv')
f=csv.reader(f)
dis=[]
sym=[]
for i in f:
  dis.append(i[0].lower())
  sym.append(i[2].lower())



dis=dis[1:]
sym=sym[1:]
dis_final=np.unique(dis)
sym_final=np.unique(sym)

co=[]
f=open('/home/buildadmin/yash/call-health-server/medibot/source/co.csv')
f=csv.reader(f)
for i in f:
  for j in i:
    co.append(float(j))


co=np.array(co).reshape(len(sym_final),len(sym_final))


def cls_screen():
  os.system('cls')



##########################################################################################3


def extract_entities(text):
  for sent in nltk.sent_tokenize(text):
    for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(sent))):
      if hasattr(chunk, 'node'):
        return chunk.node, ' '.join(c[0] for c in chunk.leaves())



####################################################################################################################
############################# Edit distance function

def edit_distance(s1, s2):
    m=len(s1)+1
    n=len(s2)+1
    tbl = {}
    for i in range(m): tbl[i,0]=i
    for j in range(n): tbl[0,j]=j
    for i in range(1, m):
        for j in range(1, n):
            cost = 0 if s1[i-1] == s2[j-1] else 1
            tbl[i,j] = min(tbl[i, j-1]+1, tbl[i-1, j]+1, tbl[i-1, j-1]+cost)
    return tbl[i,j]




def email_otp(mailid,sessid):
  otp=str(random.randint(100000,999999))
  sess_input(otp,sessid)
  to = str(mailid)
  gmail_user = 'callhealthindia@gmail.com'
  gmail_pwd = 'Siva@123'
  smtpserver = smtplib.SMTP("smtp.gmail.com",587)
  smtpserver.ehlo()
  smtpserver.starttls()
  smtpserver.ehlo
  smtpserver.login(gmail_user, gmail_pwd)
  header = 'To:' + to + '\n' + 'From: ' + gmail_user + '\n' + 'Subject: Your OTP! \n'
  #print header
  msg = header + '\n Please Enter the OTP \n\n'+str(otp) 
  smtpserver.sendmail(gmail_user, to, msg)
  #print 'done!'
  smtpserver.close()



dis_urls={}
f=open('/home/buildadmin/yash/call-health-server/medibot/source/dis_urls.csv')
f=csv.reader(f)
for i in f:
  dis_urls[i[0]]=str(i[1])




#################################################################################################################
############################ DD API 



brand_molecule=get_brand_mole_mapping()
generic_symps=['pain','swelling','bleeding','discharge']


def dd_api(mob,sessid,ip,request_type):
  if (str(request_type)=='sec_search'):
    sec_log={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sec_log.csv')
    f=csv.reader(f)
    t=[]
    for i in f:
      t.append(str(i[0]))
      t.append(str(i[1]))
    t.append(str(sessid))
    t.append(str(ip))
    t=np.array(t).reshape((len(t)/2),2)
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sec_log.csv',t,delimiter=',',fmt="%s")
    op_json={}
    op_json['data']='Success'
    op_json['sessid']=str(sessid)
    return (json.dumps(op_json))
  if (str(ip)!='Hello'):
    write_main_log(('User: '+str(ip)),sessid)
  if (request_type=='auth_request'):
    email_otp(ip,sessid)
    sess_flow_id('authenticate',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='authenticate'):
    ip=ip
    print ip 
    if (str(ip)==str(read_sess_input(sessid))):
      op_json={}
      op_json['response_type']='auth_success'
      op_json['response_code']='888'
      op_json=json.dumps(op_json)
      return (op_json)
    else:
      op_json={}
      op_json['response_type']='auth_failure'
      op_json['response_code']='888'
      op_json=json.dumps(op_json)
      return (op_json)
  if (request_type=='initial_request'):
    d=ip.split('[')
    u=[]
    for i in d:
      for j in i.split(']'):
        if (j!=''):
          u.append(j)
    if (u[0]=='FALSE'):
      write_sess_name(u[1],sessid)
      write_sess_age(date_diff(u[2]),sessid)
      write_sess_gender(u[3].lower(),sessid)
      write_sess_location(u[4],sessid)
      write_sess_latlon(str(str(u[5])+'XXXXX'+str(u[6])),sessid)
      try:
        write_sess_time(str(u[7]),sessid)
        wish_on_time(sessid)
      except:
        write_sess_time(str(u[8]),sessid)
        wish_on_time(sessid)
      sess_flow_id('get_weather',sessid)
      #write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
      op_json=blank_response_json(sessid)
    else:
      write_sess_latlon(str(str(u[5])+'XXXXX'+str(u[6])),sessid)
      write_sess_time(str(u[7]),sessid)
      sess_flow_id('check_user',sessid)
      op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='None'):
    sess_flow_id('check_user',sessid)
    op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid)) in ['check_user','check_user_continue','new_user_gender_input_dd_gender','new_user_name','new_user_age','input_new_user_age','new_user_gender','new_user_input_gender_male_guess','new_user_input_gender_female_guess','new_user_gender_wrong','get_location','input_get_location','get_weather']):
    op_json=intro_bot_flow(mob,sessid,ip,request_type)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='main_menu'):
#    res=[]
#    res.append('1. Are you or your loved ones experiencing some symptoms and want to get them investigated ?')
#    res.append('2. Do you want to know information about drugs?')
#    res.append('3. Do you want to know information about diagnostic tests?')
#    res.append('4. Are you looking for some info on prevention and wellness ?')
#    text='Please select from the following options\n'
#    options=res
#    op_json=text_ss_response_json(text,options,sessid)
    op_json=main_menu_response_json(sessid)
    sess_flow_id('input_main_menu',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_main_menu'):
    sess_input(ip,sessid)
    sess_flow_id('service_choice_main_menu',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='service_choice_main_menu'):
    ip=read_sess_input(sessid)
    if (str(ip)=='1'):
      sess_flow_id('dd_age',sessid)
    if (str(ip)=='2'):
      sess_flow_id('drugs_flow',sessid)
    if (str(ip)=='3'):
      sess_flow_id('diag_flow',sessid)
    if (str(ip)=='4'):
      sess_flow_id('mayo_articles_flow',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid)) in ['dd_age','input_dd_age','continue_dd','dd_age_wrong','input_dd_gender','input_gender_male_guess','input_gender_female_guess','dd_gender','gender_wrong','input_dd_start','dd_start','input_dd_someone_else','someone_dd_age_wrong','dd_someone_else','input_dd_someone_else_gender','someone_gender_check','dd_someone_else_gender','input_sym_anti','dd_me','sym_anti','input_sym_correct_wrong','sym_correct_wrong','input_next_sym','next_sym','last_sym_input','input_other_symptom','dd_decision','less_than_two_symps','dd_yes_no','get_dd','dd_yes_no_proper','sym_to_speciality','sym_to_speciality_continue','sym_to_mayo_message','sym_to_mayo']):
    op_json=dd_flow(mob,sessid,ip,request_type)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_end'):
    text='Was this information helpful?'
    options=['Yes','No']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_feedback_response',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_feedback_response'):
    ip=ip[0]
    if (ip=='1'):
      sess_flow_id('reason_pos_feedback',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      sess_flow_id('reason_feedback',sessid)
      if (read_sess_name(sessid)!=''): 
        text=nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+", I am sorry. I could'nt be of more help this time.\nPlease tell me what went wrong so that I can improve"
      else:
        text="I am sorry. I could'nt be of more help this time.\nPlease tell me what went wrong so that I can improve"
      options=['You did not understand me','You asked me irrelevant questions','Results shown were not satisfactory','Others']
      op_json=text_ss_response_json(text,options,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='reason_pos_feedback'):
    if (read_sess_name(sessid)!=''): 
      text='Thanks '+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+'. I am pleased that I could help you'
    else:
      text='Thanks, I am pleased that I could help you' 
    options=[]
    flow_id='before_main_menu'
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='reason_feedback'):
    if (str(ip[0])=='4'):
      text='Please let me know the reason'
      options=[]
      sess_flow_id('before_main_menu',sessid)
      op_json=text_response_json(text,sessid)
      return (op_json)
    else:
      sess_flow_id('before_main_menu',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='before_main_menu'):
    if (read_sess_name(sessid)!=''): 
      text='Ok '+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+' do you want to know anything else?'
    else:
      text='Do you want to know anything else?'
    options=['Yes','No']
    sess_flow_id('end_session',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='end_session'):
    ip=ip[0]
    if (str(ip)=='2'):
      sess_flow_id('end_session_continue',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      sess_flow_id('main_menu',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='take_email'):
    text='Do you want me to send this chat to your E-Mail?'
    options=['Yes','No']
    sess_flow_id('input_take_email',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_take_email'):
    if (str(ip[0])=='1'):
      text='Enter your email'
      op_json=text_response_json(text,sessid)
      sess_flow_id('end_session_continue',sessid)
      return (op_json)
    else:
      op_json=blank_response_json(sessid)
      sess_flow_id('end_session_continue',sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='end_session_continue'):
      if (read_sess_name(sessid)!=''):
        text='Thank you! '+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! for using CallHealth 'My Personal Health Assistant'"
      else:
        text="Thank you! for using CallHealth 'My Personal Health Assistant'"
      options=[]
      flow_id='to_end_all'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
#      if (read_sess_name(sessid)!=''):
#        text='Thank you! '+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! for using CallHealth 'My Personal Health Assistant'"
#      else:
#        text="Thank you! for using CallHealth 'My Personal Health Assistant'"
#      options=[]
#      flow_id='take_email'
#      op_json=text_blank_response_json(text,options,flow_id,sessid)
#      return (op_json)
#    else:
#      sess_flow_id('main_menu',sessid)
#      op_json=blank_response_json(sessid)
#      return (op_json)
#  if (str(read_sess_flow_id(sessid))=='take_email'):
#    text='Do you want me to send this chat to your E-Mail?'
#    options=['Yes','No']
#    sess_flow_id('input_take_email',sessid)
#    op_json=text_ss_response_json(text,options,sessid)
#    return (op_json)
#  if (str(read_sess_flow_id(sessid))=='input_take_email'):
#    if (str(ip[0])=='1'):
#      text='Enter your email'
#      op_json=text_response_json(text,sessid)
#      sess_flow_id('to_end_all',sessid)
#      return (op_json)
#    else:
#      op_json=blank_response_json(sessid)
#      sess_flow_id('to_end_all',sessid)
#      return (op_json)
  if (str(read_sess_flow_id(sessid))=='to_end_all'):
    ip=ip
    op_json={}
    op_json['sessid']=sessid
    op_json['options']=[]
    op_json['response_code']='888'
    op_json['response_type']='end_session'
    op_json['data']=''
    sess_flow_id('end_all',sessid) 
    return (json.dumps(op_json))
  if (str(read_sess_flow_id(sessid)) in ['mayo_articles_flow','input_mayo_articles_flow','get_mayo_feedback']):
    op_json=mayo_flow(mob,sessid,ip,request_type)
    return (op_json)
  if (str(read_sess_flow_id(sessid)) in ['drugs_flow','input_drugs_flow','drugs_flow_continue','input_dose_form','input_drug_brand_names','drug_brand_names','drug_brand_names_continue','no_drug_match','mole_rx','drugs_info_final','input_drugs_info_final','drugs_info_final_continue','more_drugs_info','input_more_drugs_info']):
    op_json=drugs_bot_flow(mob,sessid,ip,request_type)
    return (op_json)
  if (str(read_sess_flow_id(sessid)) in ['input_diag_flow','diag_flow','diag_flow_continue','input_select_diag_name','select_diag_name','select_diag_name_continue','diag_feedback']):
    op_json=diag_bot_flow(mob,sessid,ip,request_type)
    return (op_json)      


