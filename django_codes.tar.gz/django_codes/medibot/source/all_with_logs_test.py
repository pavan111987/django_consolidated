import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
import numpy as np
from datetime import datetime
from itertools import groupby
import json

words=stopwords.words('english')

f=open('/home/buildadmin/yash/call-health-server/medibot/source/symptoms filter.csv')
f=csv.reader(f)
sym_male=[]
sym_female=[]
for i in f:
  if (i[1]=='Yes'):
    sym_male.append(i[0])
  if (i[2]=='Yes'):
    sym_female.append(i[0])



f=open('/home/buildadmin/yash/call-health-server/medibot/source/all_mdp_symp_crawl.csv')
f=csv.reader(f)

sym_crawl={}
sym_list_final=[]
for i in f:
  sym_crawl[i[0]]=[re.sub(' +',' ',re.sub('[0-9]','',i[1])).lower()]  
  sym_list_final.append(i[0].lower())



sym_mdp_map={}
f=open('/home/buildadmin/yash/call-health-server/medibot/source/matching syn sym.csv')
f=csv.reader(f)
for i in f:
  key=i[0]
  t=[]
  for j in i[1:]:
    if (j!=''):
      t.append(j)
  value=t
  sym_mdp_map[key]=value




def wish(): 
  current_hour = time.strptime(time.ctime(time.time())).tm_hour
  if (current_hour < 12):
    return ("Good Morning!")
  elif (current_hour == 12):
    return ("Good Noon!")
  elif (current_hour > 12 and current_hour < 18):
    return ("Good AfterNoon!")
  elif (current_hour >= 18):
    return ("Good Evening!")



def cleaned_query(q):
  stop_words=stopwords.words('english')
  q_clean=[]
  for i in q.split():
    if (i not in stop_words):
      if (i not in q_clean):
        q_clean.append(i)
  return (' '.join(q_clean))



def exact_match(gender,q):
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=0
      if (i.upper() in sym_male):
        if (cleaned_query(q)==i):
          t=t+1
      sym_list[i]=t
  else:
    for i,j in sym_crawl.items():
      t=0
      if (i.upper() in sym_female):
        if (cleaned_query(q)==i):
          t=t+1
      sym_list[i]=t
  return (sym_list)



def part_match1(q):
  sym_list={}
  nouns=[]
  adj=[]
  vbz=[]
  for i in nltk.pos_tag(cleaned_query(q).split()):
    if ('NN' in i[1]):
      nouns.append(i[0])
    if ('JJ' in i[1]):
      adj.append(i[0])
    if ('VB' in i[1]):
      vbz.append(i[0])
  flag=0
  for i,j in sym_crawl.items():
    if (q in j[0]):
      flag=1      
  if (flag==0):
    sent1=[]
    for i in q.lower().split():
      if (i not in words):
        sent1.append(i)
        nouns=[]
        adj=[]
        verbs=[]
        for i in pos_tag(sent1):
          if ('NN' in i[1]):
            nouns.append(i[0])
          elif ('JJ' in i[1]):
            adj.append(i[0])
          elif ('VB' in i[1]):
            vbz.append(i[0])
          else:
            pass
    vote=np.zeros(len(sym_list_final),)
    for i,j in sym_crawl.items():
      for k in nouns:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(10*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]]) 
      for k in adj:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(1*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]]) 
      for k in vbz:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(1*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]])  
    if (np.sum(vote)>0):
      for i in np.arange(len(sym_list_final)):
        sym_list[sym_list_final[i]]=vote[i]
    else:
      print ('Sorry I did not understand your query')
  else:
    vote=np.zeros(len(sym_list_final),)
    for i,j in sym_crawl.items():
      vote[np.where(i==np.array(sym_list_final))[0][0]]=len(j[0].split(q))-1
  for i in np.arange(len(sym_list_final)):
    sym_list[sym_list_final[i]]=vote[i]
  return (sym_list)



def phrase_match(gender,q):  
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=0
      if (cleaned_query(q) in j[0]):
        if (i.upper() in sym_male): 
          t=t+1 
      sym_list[i]=t
  else:
    for i,j in sym_crawl.items():
      t=0
      if (cleaned_query(q) in j[0]):
        if (i.upper() in sym_female): 
          t=t+1 
      sym_list[i]=t
  return (sym_list)



def syn_phrase_match(gender,q):
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_mdp_map.items():
      t=0
      if (cleaned_query(q) in j):
        if (i.upper() in sym_male):
          t=t+1
      for k in j:
        if (k in cleaned_query(q)):
          if (i.upper() in sym_male):
            t=t+1
      sym_list[i]=t
  if (gender=='f' or gender=='F'):
    for i,j in sym_mdp_map.items():
      t=0
      if (cleaned_query(q) in j):
        if (i.upper() in sym_female):
          t=t+1
      for k in j:
        if (k in cleaned_query(q)):
          if (i.upper() in sym_female):
            t=t+1
      sym_list[i]=t
  return (sym_list)




def syn_match(gender,q):
  q=cleaned_query(q).lower() 
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_mdp_map.items():
        t=0
        if (i.upper() in sym_male): 
          for k in j:
            if (k==q):
              t=t+50
            if ((k in q) or (q in k)):
              t=t+len(list(set(nltk.word_tokenize(cleaned_query(q))).intersection(nltk.word_tokenize(k))))
        sym_list[i]=t
  else:
    for i,j in sym_mdp_map.items():
        t=0
        for k in j:
          if (k==q):
            t=t+50
          if ((k in q) or (q in k)):
            t=t+len(list(set(nltk.word_tokenize(cleaned_query(q))).intersection(nltk.word_tokenize(k))))
        sym_list[i]=t
  return (sym_list)


embeddings_index = {}
f = open('/home/buildadmin/yash/call-health-server/medibot/source/glove.6B.300d.txt')
for line in f:
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    embeddings_index[word] = coefs


f.close()   



pubmed_index={}
f = open('/home/buildadmin/yash/call-health-server/medibot/source/pubmet categories.csv')
f=csv.reader(f)
for i in f:
  pubmed_index[i[0]]=i[1:3]



def part_match(gender,q):
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=[]
      for k in re.sub('[^a-zA-Z  ]','',i.lower()).split():
        for l in cleaned_query(q).split():
          try:
            if (i.upper() in sym_male):
              t.append((1-dist(embeddings_index[k],embeddings_index[l])))
          except:
            t.append(0)
      if (len(t)>0): 
        sym_list[i]=np.mean(t)
      else:
        sym_list[i]=0
  else:
    for i,j in sym_crawl.items():
      t=[]
      for k in re.sub('[^a-zA-Z  ]','',i.lower()).split():
        for l in cleaned_query(q).split():
          try:
            if (i.upper() in sym_female):
              t.append((1-dist(embeddings_index[k],embeddings_index[l])))
          except:
            t.append(0)
      if (len(t)>0): 
        sym_list[i]=np.mean(t)
      else:
        sym_list[i]=0
  return (sym_list)  




def wn_match(q):
  sym_list={}
  for i,j in sym_crawl.items():
    list=[]
    for word1 in re.sub('[^a-zA-Z  ]','',i).split():
      for word2 in re.sub('[^a-zA-Z  ]','',cleaned_query(q)).split():
        wordFromList1 = wordnet.synsets(word1)
        wordFromList2 = wordnet.synsets(word2)
        if wordFromList1 and wordFromList2: 
          s = wordFromList1[0].wup_similarity(wordFromList2[0])
          list.append(s)
    sym_list[i]=np.max(list)
  return (sym_list)



##############################################################################


def sym_anti(gender,q):
  sym_list_scores0=np.zeros((len(sym_list_final),))
  for key,value in exact_match(gender,q).items():
    sym_list_scores0[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores0)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores0)])
  sym_list_scores1=np.zeros((len(sym_list_final),))
  for key,value in syn_match(gender,q).items():
    sym_list_scores1[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores1)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores1)])
  sym_list_scores4=np.zeros((len(sym_list_final),))
  for key,value in part_match(gender,q).items():
    sym_list_scores4[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores4)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores4)])
  else:
    return ('404') 






f=open('/home/buildadmin/yash/call-health-server/medibot/source/medical bayes test.csv')
f=csv.reader(f)
dis=[]
sym=[]
for i in f:
  dis.append(i[0].lower())
  sym.append(i[2].lower())



dis=dis[1:]
sym=sym[1:]
dis_final=np.unique(dis)
sym_final=np.unique(sym)


  
#################################################################################

def gen_co_sym():
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/medical bayes test.csv')
  f=csv.reader(f)
  dis=[]
  sym=[]
  for i in f:
    dis.append(i[0].lower())
    sym.append(i[2].lower())
  dis=dis[1:]
  sym=sym[1:]
  dis_final=np.unique(dis)
  sym_final=np.unique(sym)
  co=np.zeros((len(sym_final),len(sym_final)))
  for k in dis_final:
    for i in np.array(sym)[k==np.array(dis)]:
      for j in np.array(sym)[k==np.array(dis)]:
        co[np.where(i==sym_final)[0][0],np.where(j==sym_final)[0][0]]=co[np.where(i==sym_final)[0][0],np.where(j==sym_final)[0][0]]+1
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/co.csv',co,delimiter=',',fmt="%d")




f=open('/home/buildadmin/yash/call-health-server/medibot/source/medical bayes test.csv')
f=csv.reader(f)
dis=[]
sym=[]
for i in f:
  dis.append(i[0].lower())
  sym.append(i[2].lower())



dis=dis[1:]
sym=sym[1:]
dis_final=np.unique(dis)
sym_final=np.unique(sym)

co=[]
f=open('/home/buildadmin/yash/call-health-server/medibot/source/co.csv')
f=csv.reader(f)
for i in f:
  for j in i:
    co.append(float(j))


co=np.array(co).reshape(len(sym_final),len(sym_final))



#s=['fever','headache','sore throat']
def co_sym_suggest(gender,s):
  if (gender=='m' or gender=='M'):
    temp=np.zeros((len(sym_final),))
    for i in s:
      if (i.upper() in sym_male): 
        temp=temp+co[np.where(i==sym_final)[0][0]]
    co_sym=[]
    for i in np.array(sym_final)[np.argsort(temp)[::-1][0:20]]:
      if (i not in s):
        if (i.upper() in sym_male): 
          co_sym.append(i)
  else:
    temp=np.zeros((len(sym_final),))
    for i in s:
      if (i.upper() in sym_female): 
        temp=temp+co[np.where(i==sym_final)[0][0]]
    co_sym=[]
    for i in np.array(sym_final)[np.argsort(temp)[::-1][0:20]]:
      if (i not in s):
        if (i.upper() in sym_female):
          co_sym.append(i)
  return (co_sym[0:3])



def diff_diag(age,gender,symps):
  object={}
  object['age']=age
  object['gender']=gender
  object['symptoms']=symps
  object['Medical History']=['NONE']
  object['Clinical Finding']=['NONE']
  ip_json=json.dumps(object)
  ip_json=str(ip_json)
  enc_ip_json=str('XXX'.join(ip_json.split('"')))
  command=str('Rscript /home/buildadmin/yash/call-health-server/medibot/source/dd/diff_diag.R "'+enc_ip_json+'"')
  os.system(command)
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/dd result.txt')
  lines = f.readlines()  
  f.close()
  op=json.loads(''.join(lines))
  dd=[]
  for i in np.arange(5):
    if (op[str(i+1)]['Score']>0):
      dd.append(str(op[str(i+1)]['Disease']))
      dd.append(str(round(op[str(i+1)]['Score']))) 
  dd=np.array(dd).reshape(int(len(dd)/2),2)
  return (dd)



def cls_screen():
  os.system('cls')




def correct(s_new,sym,c,f):   
  sym.append(s_new)
  c=c+1 
  return (sym,c,f)


def incorrect(sym,c,f):
  print ('I am sorry, I could not understand you. Please reword/rephrase your medical problem\n\n')
  f=f+1
  return (sym,c,f)


def no_match(sym,c,f):
  print ('I am sorry, I could not understand you. Please reword/rephrase your medical problem\n\n')
  f=f+1
  return (sym,c,f)
     

s=[]
count=0
flag=0

def symps_input():
  ip=raw_input('Please be very specific in your description\nI need to know some symptoms, like cold, fever etc. The more precise you are, the more relevant diagnosis I will be able to do \n\n')
  return (ip)




def diff_diag_converse(gender):
  s=[]
  flag=0
  count=0
  temp_q=[] 
  while ((flag<=3) and (count<5)):
    if (count==0):
      cls_screen()  
      ip=symps_input()
      temp_q.append(ip)
      s_temp=sym_anti(gender,ip)
      if (s_temp!='404'):
        print (str('Based on the description of your medical problem, I have identified "')+s_temp+str('" as the symptom\n'))
        d=raw_input('Do you want to proceed further (y/n)\n')     
      else:
        s,count,flag=no_match(s,count,flag)
      if ((d=='y') or (d=='Y')):
        f=open('/home/buildadmin/yash/call-health-server/medibot/source/correct.csv')
        f=csv.reader(f)
        data=[]
        for row in f:
          data.append(row[0])
          data.append(row[1])
        data.append(cleaned_query(ip))
        data.append(s_temp)
        data=np.array(data).reshape(int(len(data)/2),2)
        np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/correct.csv',data,delimiter=',',fmt="%s") 
        s,count,flag=correct(s_temp,s,count,flag) 
      else:
        f=open('/home/buildadmin/yash/call-health-server/medibot/source/incorrect.csv')
        f=csv.reader(f)
        data=[]
        for row in f:
          data.append(row[0])
          data.append(row[1])
        data.append(cleaned_query(ip))
        data.append(s_temp)
        data=np.array(data).reshape(int(len(data)/2),2)
        np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/incorrect.csv',data,delimiter=',',fmt="%s") 
        s,count,flag=incorrect(s,count,flag)
    else:
      cls_screen()
      print (np.array(co_sym_suggest(gender,s)).reshape(3,1))   
      print (np.array(['a. Enter another symptom','b. If you do not have any other symptom']).reshape(1,2)) 
      ip=raw_input('Please select the one of the co-symptoms suggested or select the relevant option\n\n')
      if (ip=='a'):
        cls_screen()
        ip=raw_input('Please enter your symptoms to be evaluated\n\n')
        temp_q.append(ip) 
        s_temp=sym_anti(gender,ip)
        if (s_temp!='404'):
          cls_screen()
          print (str('Based on the description of your medical problem, I have identified "')+s_temp+str('" as the symptom\n'))
          d=raw_input('Do you want to proceed further (y/n)\n')     
        else:
          s,count,flag=no_match(s,count,flag)
        if ((d=='y') or (d=='Y')):
          f=open('/home/buildadmin/yash/call-health-server/medibot/source/correct.csv')
          f=csv.reader(f)
          data=[]
          for row in f:
            data.append(row[0])
            data.append(row[1])
          data.append(cleaned_query(ip))
          data.append(s_temp)
          data=np.array(data).reshape(int(len(data)/2),2)
          np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/correct.csv',data,delimiter=',',fmt="%s") 
          s,count,flag=correct(s_temp,s,count,flag)
        else:
          f=open('/home/buildadmin/yash/call-health-server/medibot/source/incorrect.csv')
          f=csv.reader(f)
          data=[]
          for row in f:
            data.append(row[0])
            data.append(row[1])
          data.append(cleaned_query(ip))
          data.append(s_temp)
          data=np.array(data).reshape(int(len(data)/2),2)
          np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/incorrect.csv',data,delimiter=',',fmt="%s") 
          s,count,flag=incorrect(s,count,flag) 
      elif (ip=='1'):
        s.append(co_sym_suggest(gender,s)[0])
        temp_q.append(co_sym_suggest(gender,s)[0])
        count=count+1
      elif (ip=='2'):
        s.append(co_sym_suggest(gender,s)[1])
        temp_q.append(co_sym_suggest(gender,s)[1])
        count=count+1
      elif (ip=='3'):
        s.append(co_sym_suggest(gender,s)[2])
        temp_q.append(co_sym_suggest(gender,s)[2]) 
        count=count+1
      else:
        flag=0
        count=5
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/inputs_instance.csv',np.array(temp_q),delimiter=',',fmt="%s")
  return (s,flag,count)



def chat_diff_diag(age,gender):
  s,f,c=diff_diag_converse(gender)
  if (f>=3):
    print ('I am sorry that I could not help you..But I am a learning bot and will soon become smarter\n')
    return ('404') 
  if (c>=5):
    symps=[]
    for i in s:
      symps.append(i.upper())
    cls_screen()
    print ('Based on your profile and medical complaints, your are likely to be suffering from:\n')
    print (diff_diag(age,gender.upper(),symps))
    print ('\n\n***Please note that the suggested Diseases/Conditions are just likelihood estimates\n')
    print ('Please consult our specialist to evaluate your medical problems\n')  
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/symps_instance.csv',np.array(symps),delimiter=',',fmt="%s")
    return (diff_diag(age,gender.upper(),symps))




##########################################################################################3


def extract_entities(text):
  for sent in nltk.sent_tokenize(text):
    for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(sent))):
      if hasattr(chunk, 'node'):
        return chunk.node, ' '.join(c[0] for c in chunk.leaves())




def geo_loc(q):
  url = str('http://maps.googleapis.com/maps/api/geocode/json?address='+q)
  response = urllib.urlopen(url)
  data = json.loads(response.read())
  if (len(data['results'][0]['formatted_address'].split(','))<=2):
    return (str(','.join([data['results'][0]['formatted_address'].split(',')[-len(data['results'][0]['formatted_address'].split(','))],data['results'][0]['formatted_address'].split(',')[-1]])))
  else:
    return (str(','.join([data['results'][0]['formatted_address'].split(',')[-3],data['results'][0]['formatted_address'].split(',')[-1]])))



def weatherapi(location):
  owm = pyowm.OWM("611c26dae2bb2b138e30811e66721dca")	
  observation = owm.weather_at_place(str(location))
  w=observation.get_weather()
  temperature=w.get_temperature('celsius')["temp"]
  weather_cond=w.get_detailed_status()
  return weather_cond , temperature



def sym_speciality(age,gender,q):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/categories.csv')
  f=csv.reader(f)
  keywords=[]
  score=[]
  cat=[]
  for i in f:
    keywords.append(i[0])
    score.append(float(i[2]))
    cat.append(i[3])
  cat_uniq=np.unique(cat)
  if (age>=13):
    temp=[]
    for i in cat_uniq:
      if (i!='Pediatrics'):
        temp.append(i)
    cat_uniq=temp
  if (gender=='m' or gender=='M'):
    temp=[]
    for i in cat_uniq:
      if (i!='Obstetrtics and Gynaecology'):
        temp.append(i)
    cat_uniq=temp
  vote=np.zeros((len(cat_uniq),1))
  cat_uniq=np.array(cat_uniq)
  for i in q.split():
    if i in keywords:
      try:
        vote[np.where(cat[np.where(i==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]=score[np.where(i==np.array(keywords))[0][0]]+vote[np.where(cat[np.where(i==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]
      except:
        pass
    else:
      d=[]
      if (i not in words):
        for j in keywords:
          try:
            d.append((1-dist(embeddings_index[i],embeddings_index[j])))
          except:
            d.append(0)
        try:
          vote[np.where(cat[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]=score[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]+vote[np.where(cat[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0] 
        except:
          pass
  if (np.sum(vote)>0): 
    return (cat_uniq[np.argmax(vote)])
  else:
    return ('404') 



def mayo_articles_url(q):
  urls=[]
  q=cleaned_query(q)
  ques=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      ques.append(i)
  q=(' '.join(ques)) 	  
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/mayo_articles.csv')
  f=csv.reader(f)
  data=[]
  for i in f:
    data.append(i)
    urls.append(i[0])
  vote=np.zeros((len(data),1))
  for i in nltk.word_tokenize(q):
    for j in np.arange(len(data)):
      vote[j,0]=vote[j,0]+len(data[j][5].split(i))-1
      vote[j,0]=vote[j,0]+len(data[j][3].split(i))-1
      vote[j,0]=vote[j,0]+len(data[j][4].split(i))-1
  temp=[]
  for i in vote:
    temp.append(i[0])
  vote=temp
  if (np.sum(vote)>0):
    temp=[] 
    for i in np.array(urls)[np.argsort(vote)[::-1][0:15]]:
      temp.append(i.split('/')[4])
    pop_cat={}
    for i in np.unique(temp):
       pop_cat[i]=temp.count(i)
    count=[]
    cats=[]
    for i,j in pop_cat.items():
      count.append(j)
      cats.append(i)
    urls_final=[]
    for i in np.array(urls)[np.argsort(vote)[::-1][0:7]]:
      if (i.split('/')[4]==cats[np.argmax(count)]):
        urls_final.append(i)   
    return (np.array(urls_final))
  else:
    return (['404'])




def name_gender(q):
 try: 
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/indian_names.csv')
  f=csv.reader(f)
  m_names=[]
  f_names=[]
  for i in f:
    if (i[1]=='m'):
      m_names.append(i[0])
    else:
      f_names.append(i[0])
  first_name=nltk.word_tokenize(q)[0].capitalize()
  m=0
  f=0
  for i in nltk.word_tokenize(q):
    for j in m_names:
      if (i==j):
        m=m+1
    for j in f_names:
      if (i==j):
        f=f+1
  if (m>f):
    return ('m',first_name)
  elif (f>m):
    return ('f',first_name)
  else:
    return ('404',first_name)
 except:
  return (['404'])



def get_brand_mole_mapping():
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/brand_to_molecule.csv')
  f=csv.reader(f)
  brand_molecule={}
  for i in f:
    temp=[]
    for j in i[1].split('+'):
      temp.append(re.sub('[(]',' ',j))
    brand_molecule[i[0]]=[temp]
  cats=[]
  subcats=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/cat_subcat.csv')
  f=csv.reader(f)
  for i in f:
    subcats.append(i[0])
    cats.append(i[1])
  for i,j in brand_molecule.items():
     flag=0 
     for k in i.split():
       if (k in subcats):
         flag=1
         brand_molecule[i].append([subcats[np.where(k==np.array(subcats))[0][0]]]) 
         break
     if (flag==0):
       brand_molecule[i].append(['others'])
     flag=0
     for k in i.split():
       if (k in cats):
         flag=1
         brand_molecule[i].append([cats[np.where(k==np.array(cats))[0][0]]]) 
         break
     if (flag==0):
       brand_molecule[i].append(['others'])
  return (brand_molecule)



brand_molecule=get_brand_mole_mapping()



def get_brand_mole(q):
  vote=[]
  name=[]
  cat=[]
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      if (len(i)>=3):
        temp.append(i)
  q=(' '.join(temp))
  for i,j in brand_molecule.items():
    count=0
    name.append(i)
    cat.append(j[1])
    for k in q.split():
      if (k==i.split()[0]):
        count=count+1
      try:
        if (k==i.split()[1]):
          count=count+0.5
      except:
        pass 
    vote.append(count)
  if (np.sum(vote)>0):
    v=np.array(vote)[np.where(np.array(vote)>0)]
    c_uniq=np.unique(np.array(cat)[np.where(np.array(vote)>0)])
    c=np.array(cat)[np.where(np.array(vote)>0)]
    n=np.array(name)[np.where(np.array(vote)>0)]
    v=v[np.argsort(v)[::-1]]
    n=n[np.argsort(v)[::-1]]
    c=c[np.argsort(v)[::-1]]
    print (np.array(c_uniq).reshape(len(c_uniq),1))
    ip=raw_input('Please select from the following Dose Form\n')
    n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip)-1]==c)[0]]
    c_selected=np.array(c_uniq)[int(ip)-1]  
    n_final=n_final.reshape(len(n_final),1)
    print (n_final)
    ip=raw_input('Please select from the following brand names\n')
    for i,j in brand_molecule.items():
      if (i==n_final[int(ip)-1]):
        break
    return (n_final[int(ip)-1],j[0],c_selected) 
  else:
    return ('404')






def drugs_clean(q):
  rx_mole_list=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_rx_mole_master.csv')
  f=csv.reader(f)
  for i in f:
    rx_mole_list.append(i[0])
  drug_master_words=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_master_words.csv')
  f=csv.reader(f)
  for i in f:
    drug_master_words.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i in drug_master_words):
      temp.append(i)
  q=(' '.join(temp))
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      temp.append(i)
  q=(' '.join(temp))
  if (len(temp)>0):
    return (q)
  else:
    return ('404')






def mole_rx_mole(q):
  rx_mole_list=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_rx_mole_master.csv')
  f=csv.reader(f)
  for i in f:
    rx_mole_list.append(i[0])
  drug_master_words=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_master_words.csv')
  f=csv.reader(f)
  for i in f:
    drug_master_words.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i in drug_master_words):
      temp.append(i)
  q=(' '.join(temp))
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      temp.append(i)
  q=(' '.join(temp))
  mole=get_brand_mole(q)  
  c_selected=[mole[2]]
  mole=mole[1]
  vote=[]
  name=[]
  for i in rx_mole_list:
    count=0
    name.append(i) 
    for j in mole:
      for k in nltk.word_tokenize(j):
        if (i==k):
          count=count+1
    vote.append(count)
  if (np.sum(vote)>0):
    n=np.array(name)[np.where(np.max(vote)==np.array(vote))]	
    v=np.array(vote)[np.where(np.max(vote)==np.array(vote))]
    return (n,np.array(c_selected))
  else:
    return ([['404']])




def diag_names_match(q):
 try:
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_name.csv')
  f=csv.reader(f)
  dic=[]
  diag_name={}
  for i in f:
    temp=[]
    for j in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',i[0].lower())):
      if (j not in words):
        if (j!=''):
          temp.append(j)
    for j in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',i[1].lower())):
      if (j not in words):
        if (j!=''):
          temp.append(j) 
    for j in temp:
      if (j!='done'):
        if (len(j)>=3):
          dic.append(j)
    diag_name[i[0]]=[temp,i[2]]
  dic=np.unique(dic)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/diag_name_list.csv',dic,delimiter=',',fmt="%s") 
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/diag_name_list.csv')
  f=csv.reader(f)
  diag_names=[]
  for i in f:
    diag_names.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',q.lower())):
    if (i not in words):
      if (i in diag_names):
        if (i!=''):
          temp.append(i)
  q=(' '.join(temp))
  names=[]
  vote=[]
  codes=[]  
  for i,j in diag_name.items():
    names.append(i)
    codes.append(j[1])
    t=0
    for k in nltk.word_tokenize(q):
      t=t+(j[0].count(k))
    vote.append(t)
  if (np.sum(vote)>0):
    n=np.array(names)[np.where(np.array(vote)>0)]
    c=np.array(codes)[np.where(np.array(vote)>0)]
    if (len(n)>5):
      return (n[0:5],c[0:5])
    else:
      return (n,c)
  else:
    return ([['404']])
 except:
  return ([['404']])




def diag_full_info(q):
  res=diag_names_match(q)
  if (res[0][0]!='404'):
    names=res[0]
    codes=res[1]
    print (names.reshape(len(names),1))
    ip=raw_input('Please select the Diagnosic test based on the query\n')
    name=names[int(ip)-1]
    code=codes[int(ip)-1]
    diag_price={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_price.csv')
    f=csv.reader(f)
    for i in f:
      diag_price[i[0]]=[i[1],i[2]]
    diag_info={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_info.csv')
    f=csv.reader(f)
    for i in f:
      diag_info[i[0]]=[i[1]]
    diag_package={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_package.csv')
    f=csv.reader(f)
    for i in f:
      diag_package[i[0]]=[i[1:]]
    packages=[]
    for i,j in diag_package.items():
      if (code in j[0]):
        packages.append(i)
    if (len(packages)<=0):
      return ('The test '+str(name)+' is usually priced between Rs '+str(diag_price[code][0])+' and Rs '+str(diag_price[code][1])+' and has the following purpose \n'+str(diag_info[code][0]))     
    else:
      return ([['The test '+str(name)+' is usually priced between Rs '+str(diag_price[code][0])+' and Rs '+str(diag_price[code][1])+' and has the following purpose \n'+str(diag_info[code][0])+'\nThis test is available in the following packages\n'],[np.array(packages).reshape(len(packages),1)]])
  else:
    return ('404')




def drugs_info_final(q):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_dis_contra.csv')
  f=csv.reader(f)
  dis_contra={}
  for i in f:
    dis_contra[i[0]]=i[1:]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_moa.csv')
  f=csv.reader(f)
  drug_moa={}
  for i in f:
    drug_moa[i[0]]=i[1:]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_pe_induces.csv')
  f=csv.reader(f)
  drug_pe={}
  for i in f:
    drug_pe[i[0]]=i[1:]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_uses.csv')
  f=csv.reader(f)
  drug_uses={}
  for i in f:
    drug_uses[i[0]]=[' '.join((', '.join(i[1:]).split('\n')))]
  mole=mole_rx_mole(q)
  if (mole[0][0]!='404'):
    c_selected=mole[1]
    mole=mole[0]
    drug_info=[]
    for i in mole:
      try:
        drug_info.append(drug_uses[i][0])
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(drug_moa[i])))
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(dis_contra[i])))
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(drug_pe[i])))
      except:
        pass
    subs=[]
    for i,j in brand_molecule.items():
      if (set(j[0])==set(mole)):
        if (j[1][0]==c_selected[0]):
          subs.append(i)
    return (np.array(subs)[0:5],np.array(mole),(np.array(drug_info).reshape(len(drug_info),1)))
  else:
    return ('404')



     
##########################################################################################################################
################ start logging



#########################################################################################################################

############# capture general user input


def sess_input(ip,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_input.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    if (str(i[0])==str(sessid)):
      data[i[0]]=ip
      flag=1
    else:
      data[i[0]]=i[1]    
  if (flag==0):
    data[str(sessid)]=ip
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_input.csv',new_data,delimiter=',',fmt="%s")


############################################################################################################################
################### Read general input by the user

def read_sess_input(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_input.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    if (str(i[0])==str(sessid)):
      return str(i[1])



############################################################################################################################
############ capture the flow id changes for users


def sess_flow_id(ip,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_flow_id.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    if (str(i[0])==str(sessid)):
      data[i[0]]=ip
      flag=1
    else:
      data[i[0]]=i[1]    
  if (flag==0):
    data[str(sessid)]=ip
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_flow_id.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################# DD status (correct,wrong) for users

def dd_status_log_counter(ip,sessid):
  ip=ip.lower()
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_status_log.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    data[i[0]]=i[1:]
    if (str(i[0])==str(sessid)):
      flag=1
  new_data={}
  for i,j in data.items():
    new_data[i]=[int(j[0]),int(j[1])]
    if (flag==1):
      if ((str(ip)=='y') and (str(sessid)==str(i))):
        new_data[i]=[int(j[0])+1,int(j[1])]
      if ((str(ip)=='n') and (str(sessid)==str(i))):
        new_data[i]=[int(j[0]),int(j[1])+1]
      continue
    if (flag==0):
      if (str(ip)=='y'):
        new_data[sessid]=[1,0]
      if (str(ip)=='n'):
        new_data[sessid]=[0,1]
      if (str(ip)=='0'):
        new_data[sessid]=[0,0]
      continue
  data=[]
  for i,j in new_data.items():
    data.append(i)
    for k in j:
      data.append(k)
  data=np.array(data).reshape((len(data)/3),3)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_status_log.csv',data,delimiter=',',fmt="%s")


#####################################################################################################################
################################# DD status (correct,wrong) for users

def read_dd_status_log_counter(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/dd_status_log.csv')
  f=csv.reader(f)
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1],i[2])



#####################################################################################################################
######################################## capture symptoms list for users
 
def write_symps_log(sym,sessid):
  data={}
  flag=0  
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv')
  f=csv.reader(f) 
  for i in f:
    if (str(i[0])==str(sessid)):
      flag=1
    if (i[1]!=''):
      data[i[0]]=i[1].split('XXXXX')
    else:
      data[i[0]]=[]
  if (flag==0):
    data[sessid]=[]  
  new_data={}
  for i,j in data.items():
    if (str(i)==str(sessid)):
      j.append(sym)
      new_data[i]=j
    else:
      new_data[i]=j
  data=[]
  for i,j in new_data.items():
    data.append(i)
    data.append('XXXXX'.join(j)) 
  data=np.array(data).reshape((len(data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv',data,delimiter=',',fmt="%s")



#####################################################################################################################
######################################## read captured symptoms list for users
 
def read_symps_log(sessid):
  data={}
  flag=0  
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv')
  f=csv.reader(f) 
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1].split('XXXXX'))




############################################################################################################################
############ read the flow id changes for users


def read_sess_flow_id(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_flow_id.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1])




##############################################################################################################
################################## capture raw input of users

def sess_raw_input(msg,sessid):
  ip=raw_input(str(msg))
  return (ip,sessid)


##############################################################################################################
################################## read captured user info to see existing or new user 

def read_user_profile(mob):
  if (mob!='404'):
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/user_profiles.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1:]
    flag=0
    for i,j in data.items():
      if (str(mob)==i):
        flag=1
        break
    if (flag==0):
      return ('404')
    else:
      return (data[mob])
  else:
    return ('404')
   

##############################################################################################################
################################## read captured user info to see existing or new user 

def write_user_profile(mob,name,age,gender,location):
  if (mob!='404'):
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/user_profiles.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1:]
    data[mob]=[name,age,gender,location]
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      for k in j:
        new_data.append(k)
    new_data=np.array(new_data).reshape((len(new_data)/5),5)
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/user_profiles.csv',new_data,delimiter=',',fmt="%s") 
  else:
    return ('404')


#####################################################################################################################
################################## read sessid mobile number 

def read_sess_mob(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_mob.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid mobile number 

def write_sess_mob(mob,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_mob.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(mob)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_mob.csv',new_data,delimiter=',',fmt="%s")


#####################################################################################################################
################################## read sessid name 

def read_sess_name(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_name.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid name 

def write_sess_name(name,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_name.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(name)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_name.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################## read sessid age 

def read_sess_age(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_age.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid age 

def write_sess_age(age,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_age.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(age)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_age.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################## read sessid gender 

def read_sess_gender(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_gender.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid gender 

def write_sess_gender(gender,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_gender.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(gender)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_gender.csv',new_data,delimiter=',',fmt="%s")


#####################################################################################################################
################################## read sessid location 

def read_sess_location(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_location.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid location 

def write_sess_location(location,sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_location.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(location)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_location.csv',new_data,delimiter=',',fmt="%s")


################################## write blank response with 888 as code

def blank_response_json(sessid):
  op_json={}
  op_json['data']=''
  op_json['options']=[]
  op_json['sessid']=str(sessid)
  op_json['response_type']='blank_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 


################################## write text response

def text_response_json(text,sessid):
  op_json={}
  op_json['data']=text
  op_json['options']=[]
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 


################################## write text+single selection response

def text_ss_response_json(text,options,sessid):
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_and_ss_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 



################################## write text+list response

def text_list_response_json(text,options,sessid):
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_list_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 



################################## write text+list response

def url_list_response_json(text,options,sessid):
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='url_list_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 



################################## write text+list response

def text_blank_response_json(text,options,flow_id,sessid):
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_blank_response'
  op_json['response_code']='888'
  sess_flow_id(flow_id,sessid)  
  return (json.dumps(op_json)) 


#################################################################################################################
############################ DD API 



brand_molecule=get_brand_mole_mapping()


      
  
def dd_api(mob,sessid,ip):
  if (str(read_sess_flow_id(sessid))=='None'):
    sess_flow_id('check_user',sessid)
    op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='check_user'):
    if (read_user_profile(mob)!='404'):
      write_sess_name(read_user_profile(mob)[0],sessid)
      write_sess_age(read_user_profile(mob)[1],sessid)
      write_sess_gender(read_user_profile(mob)[2],sessid)
      write_sess_location(read_user_profile(mob)[3],sessid)
      sess_flow_id('get_weather',sessid)
      op_json=blank_response_json(sessid)
    elif (mob=='404'):
      write_sess_name('guest',sessid)
      write_sess_location('Hyderabad, India',sessid) 
      sess_flow_id('get_weather',sessid)
      op_json=blank_response_json(sessid) 
    else:
      text='It seems that you are new here..let me know of your name\n'
      op_json=text_response_json(text,sessid)
      sess_flow_id('new_user_name',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='new_user_name'):
    ip=ip
    write_sess_name(ip,sessid)
    sess_flow_id('get_location',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)    
  if (str(read_sess_flow_id(sessid))=='get_location'):
    text='Where are you from?\n'
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_get_location',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_get_location'):
    ip=ip
    location=geo_loc(ip)
    write_sess_location(re.sub('[^a-zA-Z0-9 ]','',location),sessid)
    sess_flow_id('get_weather',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='get_weather'):
    location=read_sess_location(sessid)
    try: 
      weather = weatherapi(location)
    except:
      location='Hyderabad, India'   
      weather = weatherapi(location)
    temperature = weather[1]
    weather_cond = weather[0]
    text = "It's "+str(temperature)+" degress in "+location+", enjoy the "+weather_cond+" outside. So how can I help you "+read_sess_name(sessid)+"?"
    write_sess_location(location,sessid)
    write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
    options=[]
    flow_id='main_menu'
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='main_menu'):
    res=[]
    res.append('1. Are you or your loved ones experiencing some symptoms and want to get them investigated ?')
    res.append('2. Do you want to know information about drugs?')
    res.append('3. Do you want to know information about diagnostic tests?')
    res.append('4. Are you looking for some info on prevention and wellness ?')
    text='Please select from the following options\n'
    options=res
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_main_menu',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_main_menu'):
    ip=ip[0]
    sess_input(ip,sessid)
    sess_flow_id('service_choice_main_menu',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='service_choice_main_menu'):
    ip=read_sess_input(sessid)
    if (str(ip)=='1'):
      sess_flow_id('dd_age',sessid)
    if (str(ip)=='2'):
      sess_flow_id('drugs_flow',sessid)
    if (str(ip)=='3'):
      sess_flow_id('diag_flow',sessid)
    if (str(ip)=='4'):
      sess_flow_id('mayo_articles_flow',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_age'):
    ip=ip
    ip=re.sub('[^0-9]','',ip)
    if ((int(ip)>=0) and (int(ip)<=100)):
      write_sess_age(ip,sessid)
      sess_flow_id('dd_gender',sessid)
    else:
      sess_flow_id('dd_age_wrong',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_age'):
    if (read_sess_age(sessid)=='404'):
      try:
        text='Please enter your age (for ex 33,45 etc)\n'
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_dd_age',sessid)
      except:
        op_json=blank_response_json(sessid)
        sess_flow_id('dd_age_wrong',sessid)
    else:
      op_json=blank_response_json(sessid)  
      sess_flow_id('dd_gender',sessid)
    return (op_json)  
  if (str(read_sess_flow_id(sessid))=='dd_age_wrong'):
    text='It seems that you have not entered your age in the right format\n'
    options=[]
    flow_id='dd_age'
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='input_dd_gender'):
    ip=ip[0]
    if (ip=='1'): 
      write_sess_gender('m',sessid)
    else:
      write_sess_gender('f',sessid)
    sess_flow_id('dd_start',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_gender_male_guess'):
    ip=ip[0]
    if (ip=='1'):
      write_sess_gender('m',sessid)
      sess_flow_id('dd_start',sessid)
    else:
      sess_input('f',sessid)
      sess_flow_id('gender_wrong',sessid)     
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_gender_female_guess'):
    ip=ip[0]
    if (ip=='1'):
      write_sess_gender('f',sessid)
      sess_flow_id('dd_start',sessid)
    else:
      sess_input('m',sessid)
      sess_flow_id('gender_wrong',sessid)     
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_gender'):
    if (read_sess_gender(sessid)=='404'):
      g=name_gender(read_sess_name(sessid))
      if (g[0]=='404'):
        options=['m','f']
        text='Please select your gender\n'
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_dd_gender',sessid)
        return (op_json) 
      elif (g[0]=='m'):
        text='Based on your name...I am guessing your are a Male\nShall I proceed with this assumption?\n'
        options=['y','n']
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_gender_male_guess',sessid)
        return (op_json)
      elif (g[0]=='f'):
        text='Based on your name...I am guessing your are a Female\nShall I proceed with this assumption?\n'
        options=['y','n']
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_gender_female_guess',sessid)
        return (op_json)
    else:
      sess_flow_id('dd_start',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='gender_wrong'):
    text='Oops that was embarrasing..I will keep that in mind!!\n'
    write_sess_gender(read_sess_input(sessid),sessid) 
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/indian_names.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1]
    data[read_sess_name(sessid)]=read_sess_input(sessid)        
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      new_data.append(j)
    new_data=np.array(new_data).reshape((len(new_data)/2),2)
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/indian_names.csv',new_data,delimiter=',',fmt="%s")
    flow_id='dd_start'
    options=[]
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_start'):
    ip=ip[0]
    if (ip=='1'):
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
      sess_flow_id('dd_me',sessid)
    if (ip=='2'):
      sess_flow_id('dd_someone_else',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_start'):
    text='Is this for you or for someone else?\n'
    options=['Me','Someone else']
    sess_flow_id('input_dd_start',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_someone_else'):
    ip=ip 
    ip=re.sub('[^0-9]','',ip)
    if ((int(ip)>=0) and (int(ip)<=100)):
      write_sess_age(ip,sessid)
      sess_flow_id('dd_someone_else_gender',sessid)
    else:
      sess_flow_id('dd_age_wrong',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)  
  if (str(read_sess_flow_id(sessid))=='dd_someone_else'):
    text='Please enter the persons age (for ex 33,45 etc)\n'
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_dd_someone_else',sessid)
    return (op_json)    
  if (str(read_sess_flow_id(sessid))=='input_dd_someone_else_gender'):
    ip=ip[0]
    res=['m','f']
    write_sess_gender(res[int(ip)-1],sessid)
    sess_flow_id('dd_me',sessid)
    op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='dd_someone_else_gender'):
    options=['m','f']
    text='Please select the persons gender\n'
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_dd_someone_else_gender',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_sym_anti'):
      ip=ip
      sess_input(ip,sessid)
      sess_flow_id('sym_anti',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_me'):
    data={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv')
    f=csv.reader(f)
    for i in f:
      if (str(i[0])==str(sessid)): 
        data[i[0]]=''
      else:
        data[i[0]]=i[1]
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      new_data.append(j)
    new_data=np.array(new_data).reshape((len(new_data)/2),2)
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv',new_data,delimiter=',',fmt="%s")
    dd_status_log_counter('0',sessid)   
    if (read_dd_status_log_counter(sessid)==None):
      dd_status_log_counter('0',sessid)
    if ((int(read_dd_status_log_counter(sessid)[0])<5) and (int(read_dd_status_log_counter(sessid)[1])<=3)):
      text=str('Please enter the symptoms (like cold, fever etc)\nTry to be as specific as possible so that I can diagnose accurately\n')
      op_json=text_response_json(text,sessid)
      sess_flow_id('input_sym_anti',sessid)
      return (op_json)              
    elif (int(read_dd_status_log_counter(sessid)[1])>=3):
      text='Oops sorry!! I am still learning..I will be able to help you better the next time\n'
      options=[]
      flow_id='dd_end' 
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)  
  if (str(read_sess_flow_id(sessid))=='sym_anti'):
    ip=read_sess_input(sessid)
    s_temp=sym_anti(read_sess_gender(sessid),ip)
    if (s_temp!='404'):
      sess_input(s_temp,sessid)
      sess_flow_id('sym_correct_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      text='Sorry I did not understand your symptoms\n'
      dd_status_log_counter('n',sessid)
      flow_id='dd_me'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_sym_correct_wrong'):
    ip=ip[0]
    res=['y','n'] 
    if (ip=='1'):
      s_temp=read_sess_input(sessid)
      write_symps_log(s_temp.upper(),sessid)
      sess_flow_id('next_sym',sessid)	
    else:
      sess_flow_id('dd_me',sessid)
    dd_status_log_counter(res[int(ip)-1],sessid)
    op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='sym_correct_wrong'):
    if ((int(read_dd_status_log_counter(sessid)[0])<5) or (int(read_dd_status_log_counter(sessid)[1])<=3)):
      s_temp=read_sess_input(sessid)
      text=str('Based on the description I identified "')+str(s_temp)+str('" as the symptom\nShall I proceed further?\n')
      options=['y','n']
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('input_sym_correct_wrong',sessid)
      return (op_json)
    elif ((int(read_dd_status_log_counter(sessid)[0])==5)):
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    elif (int(read_dd_status_log_counter(sessid)[1])==3):
      text='Oops sorry!! I am still learning..I will be able to help you better the next time\n'
      flow_id='dd_end'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
    else:
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_next_sym'):
    temp=read_symps_log(sessid)
    s=[]
    for i in temp:
      s.append(i.lower())
    res=co_sym_suggest(read_sess_gender(sessid),s)    
    res.append('Other symptom')
    res.append('No other symptom')
    ip=ip[0]
    sess_input(ip,sessid)      
    sess_flow_id('dd_decision',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)  
  if (str(read_sess_flow_id(sessid))=='next_sym'):
    temp=read_symps_log(sessid)
    s=[]
    for i in temp:
      s.append(i.lower())
    res=co_sym_suggest(read_sess_gender(sessid),s)    
    res.append('Other symptom')
    res.append('No other symptom')
    options=res
    text='Please choose from the list of co-symptoms or a revelant option\n'
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_next_sym',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_other_symptom'):
    ip=ip
    sess_input(ip,sessid)
    sess_flow_id('sym_anti',sessid)
    op_json=blank_response_json(sessid)
  if (str(read_sess_flow_id(sessid))=='dd_decision'):
    ip=read_sess_input(sessid)
    temp=read_symps_log(sessid)    
    s=[]
    for i in temp:
      s.append(i.lower())
    res=co_sym_suggest(read_sess_gender(sessid),s)    
    res.append('Other symptom')
    res.append('No other symptom')
    choice=res[int(ip)-1]
    if (choice=='Other symptom'):
      text='Please enter your symptoms (like cold, fever etc)\nTry to be as specific as possible so that I can diagnose accurately\n'
      op_json=text_response_json(text,sessid)
      sess_flow_id('input_other_symptom',sessid)
      return (op_json)   
    elif (choice=='No other symptom'):
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
    else:
      write_symps_log(choice.upper(),sessid)
      sess_flow_id('next_sym',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='get_dd'):
    s=read_symps_log(sessid)
    s=np.unique(s)
    symps=[]
    for i in s:
      symps.append(i.upper())
    d=diff_diag(int(read_sess_age(sessid)),read_sess_gender(sessid).upper(),symps)
    options=[]
    for i in d:
      options.append(i[0]+' '+i[1])
    s=(' '.join(np.unique(read_symps_log(sessid))))
    s=s.lower()
    sess_input(s,sessid)
    text='Based on your symptoms, You are likely to be diagnosed with: \n'
    flow_id='sym_to_speciality'
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='sym_to_speciality'):
    s=read_sess_input(sessid)
    if (sym_speciality(int(read_sess_age(sessid)),read_sess_gender(sessid),s)[0]!='404'):
      text=('Based on your condition I recommend you consult '+sym_speciality(int(read_sess_age(sessid)),read_sess_gender(sessid),(s))+'\nYou can call us on 33557799\n')
      options=[]
      flow_id='sym_to_mayo' 
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
    else:
      op_json=blank_response_json(sessid)
      sess_flow_id('sym_to_mayo',sessid)
      sess_input(s,sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='sym_to_mayo'):
    s=read_sess_input(sessid)
    if (len(mayo_articles_url((s).lower()))!=0):
      if ((mayo_articles_url((s).lower())[0]!='404')):
        text = ('You can read up more on the related articles here...\n')
        u=[]
        for i in (mayo_articles_url((s).lower())):
          u.append([i,'url'])
        options=u
        op_json=url_list_response_json(text,options,sessid)
        sess_flow_id('dd_end',sessid)
        return (op_json)
      else:
        op_json=blank_response_json(sessid)
        sess_flow_id('dd_end',sessid)
        return (op_json) 
    else:
      op_json=blank_response_json(sessid)
      sess_flow_id('dd_end',sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='dd_end'):
    sess_flow_id('main_menu',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_mayo_articles_flow'):
    ip=ip
    a=mayo_articles_url(ip)
    options=[]
    if (a[0]!='404'):
      for i in a:
        options.append([i,'url'])
      sess_flow_id('main_menu',sessid)
      text='Here is what I found..\n'
      op_json=url_list_response_json(text,options,sessid)
      return (op_json) 
    else:
      text=('I could not find any relevant articles based on your query\n')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='mayo_articles_flow'):
    text=('Please type in your query for which I can fetch you the relevant health articles\n') 
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_mayo_articles_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_drugs_flow'):
    ip=ip
    sess_input(ip,sessid)
    op_json=blank_response_json(sessid)
    sess_flow_id('drugs_flow_continue',sessid)
    return (op_json)   
  if (str(read_sess_flow_id(sessid))=='drugs_flow'):
    text=('Please enter the drug by its brand name for which you wish to know some information\n')
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_drugs_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='drugs_flow_continue'):
    q=read_sess_input(sessid) 
    q=drugs_clean(q)
    if (q!='404'):
      vote=[]
      name=[]
      cat=[]
      temp=[]
      for i in nltk.word_tokenize(q):
        if (i not in words):
          if (len(i)>=3):
            temp.append(i)
      q=(' '.join(temp))
      for i,j in brand_molecule.items():
        count=0
        name.append(i)
        cat.append(j[1])
        for k in q.split():
          if (k==i.split()[0]):
            count=count+1
          try:
            if (k==i.split()[1]):
              count=count+0.5
          except:
            pass 
        vote.append(count)
    if (np.sum(vote)>0):
      v=np.array(vote)[np.where(np.array(vote)>0)]
      c_uniq=np.unique(np.array(cat)[np.where(np.array(vote)>0)])
      c=np.array(cat)[np.where(np.array(vote)>0)]
      n=np.array(name)[np.where(np.array(vote)>0)]
      v=v[np.argsort(v)[::-1]]
      n=n[np.argsort(v)[::-1]]
      c=c[np.argsort(v)[::-1]]
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_name_log.csv')
      f=csv.reader(f)
      name_log={}
      for i in f:
        name_log[i[0]]=i[1]
      name_log[sessid]=str('XXXXX'.join(n))
      new_data=[]
      for i,j in name_log.items():
        new_data.append(i)
        new_data.append(j)
      new_data=np.array(new_data).reshape((len(new_data)/2),2)
      np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_name_log.csv',new_data,delimiter=',',fmt="%s")
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_cat_log.csv')
      f=csv.reader(f)
      cat_log={}
      for i in f:
        cat_log[i[0]]=i[1]
      x=[]
      for i in c:
        x.append(i[0])
      cat_log[sessid]=str('XXXXX'.join(x))
      new_data=[]
      for i,j in cat_log.items():
        new_data.append(i)
        new_data.append(j)
      new_data=np.array(new_data).reshape((len(new_data)/2),2)
      np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_cat_log.csv',new_data,delimiter=',',fmt="%s")
      options=list(c_uniq)
      text=('Please select from the following Dose Form\n')
      sess_flow_id('input_dose_form',sessid)
      op_json=text_ss_response_json(text,options,sessid)
    else:
      sess_flow_id('no_drug_match',sessid)
      op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dose_form'):
    ip=ip[0]
    sess_input(ip,sessid)
    sess_flow_id('drug_brand_names',sessid) 
    op_json=blank_response_json(sessid)
    return (op_json)     
  if (str(read_sess_flow_id(sessid))=='input_drug_brand_names'):
    ip=ip[0]
    temp=read_sess_input(sessid)
    ip='XXXXX'.join([ip,temp])
    sess_input(ip,sessid)
    sess_flow_id('drug_brand_names_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='drug_brand_names'):
    ip=read_sess_input(sessid)
    flag1=0
    flag2=0
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_name_log.csv')
    f=csv.reader(f)
    name_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag1=1
        n=i[1].split('XXXXX')
        break
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_cat_log.csv')
    f=csv.reader(f)
    cat_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag2=1
        c=i[1].split('XXXXX')
        break
    if ((flag1!=0) and (flag2!=0)):
      ip=read_sess_input(sessid)
      c_uniq=np.unique(c) 
      n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip)-1]==np.array(c))[0]]
      c_selected=np.array(c_uniq)[int(ip)-1]
      options=[]
      for i in n_final:
        options.append(i)  
      text=('Please select from the following brand names\n')
      sess_flow_id('input_drug_brand_names',sessid)
      sess_input(ip,sessid)
      op_json=text_ss_response_json(text,options,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='drug_brand_names_continue'):
    ip=read_sess_input(sessid).split('XXXXX')[0]
    ip1=read_sess_input(sessid).split('XXXXX')[1] 
    flag1=0
    flag2=0
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_name_log.csv')
    f=csv.reader(f)
    name_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag1=1
        n=i[1].split('XXXXX')
        break
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_cat_log.csv')
    f=csv.reader(f)
    cat_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag2=1
        c=i[1].split('XXXXX')
        break
    if ((flag1!=0) and (flag2!=0)):
      c_uniq=np.unique(c) 
      n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip1)-1]==np.array(c))[0]]
      c_selected=np.array(c_uniq)[int(ip1)-1]
      for i,j in brand_molecule.items():
        if (i==n_final[int(ip)-1]):
          break
      comp=('YYYYY'.join(j[0]))
      brand_name=n_final[int(ip)-1]
      cat_selected=c_selected
      sess_input(('XXXXX'.join([brand_name,comp,cat_selected])),sessid)
      sess_flow_id('mole_rx',sessid)
      op_json=blank_response_json(sessid)
    else:
      sess_flow_id('no_drug_match',sessid)
      op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='no_drug_match'):    
    text=('Sorry! I did not find any drugs matching the given description\n')
    flow_id='main_menu'
    options=[]
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='mole_rx'):    
    rx_mole_list=[]
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_rx_mole_master.csv')
    f=csv.reader(f)
    for i in f:
      rx_mole_list.append(i[0])
    ip=read_sess_input(sessid)
    ip=ip.split('XXXXX')
    c_selected=[ip[2]]
    mole=ip[1].split('YYYYY')
    vote=[]
    name=[]
    for i in rx_mole_list:
      count=0
      name.append(i) 
      for j in mole:
        for k in nltk.word_tokenize(j):
          if (i==k):
            count=count+1
      vote.append(count)
    if (np.sum(vote)>0):
      n=np.array(name)[np.where(np.max(vote)==np.array(vote))]	
      v=np.array(vote)[np.where(np.max(vote)==np.array(vote))]
      a='YYYYY'.join(n)
      b=c_selected[0]
      a='XXXXX'.join([a,b])
      sess_input(a,sessid)
      sess_flow_id('drugs_info_final',sessid)
      op_json=blank_response_json(sessid)
    else:
      text=('Sorry!! I could not find any drug information based on your query\n')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='drugs_info_final'):
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_dis_contra.csv')
    f=csv.reader(f)
    dis_contra={}
    for i in f:
      dis_contra[i[0]]=i[1:]
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_moa.csv')
    f=csv.reader(f)
    drug_moa={}
    for i in f:
      drug_moa[i[0]]=i[1:]
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_pe_induces.csv')
    f=csv.reader(f)
    drug_pe={}
    for i in f:
      drug_pe[i[0]]=i[1:]
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_uses.csv')
    f=csv.reader(f)
    drug_uses={}
    for i in f:
      drug_uses[i[0]]=[' '.join((', '.join(i[1:]).split('\n')))]
    ip=read_sess_input(sessid)
    ip=ip.split('XXXXX') 
    mole=ip[0].split('YYYYY')
    if (mole[0]!='404'):
      c_selected=ip[1]
      drug_info=[]
      for i in mole:
        try:
          drug_info.append('     The uses of the drug are:')
          drug_info.append(drug_uses[i][0])
        except:
          pass
        try:
          drug_info.append('     The following is the Mechanism of Action:')
          drug_info.append(str(i)+' '+(' '.join(drug_moa[i])))
        except:
          pass
        try:
          drug_info.append('     The following is the drug contra indication:')
          drug_info.append(str(i)+' '+(' '.join(dis_contra[i])))
        except:
          pass
        try:
          drug_info.append('     The following is the drug physiologic affects:')
          drug_info.append(str(i)+' '+(' '.join(drug_pe[i])))
        except:
          pass
      subs=[]
      for i,j in brand_molecule.items():
        if (set(j[0])==set(mole)):
          if (j[1][0]==c_selected):
            subs.append(i)
      if (len(subs)>0):
        drug_info.append('    The following are the substitutes for the drug')
        count=0
        for i in subs:
          if (count<=5): 
            drug_info.append(i)
            count=count+1
      options=drug_info
      text='Drug Info:'
      op_json=text_list_response_json(text,options,sessid) 
      sess_flow_id('main_menu',sessid)
    else:
      text=('Sorry!! I could not find any drug information relevant to your query\n')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_diag_flow'):
    ip=ip
    sess_input(ip,sessid)
    sess_flow_id('diag_flow_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='diag_flow'):
    text=('Please enter the name of the Diagnostic test to get its information\n')
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_diag_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='diag_flow_continue'):
    q=read_sess_input(sessid)
    res=diag_names_match(q)
    if (res[0][0]!='404'):
      names=res[0]
      codes=res[1]
      n=str('YYYYY'.join(list(names)))
      c=str('YYYYY'.join(list(codes)))
      n=str('XXXXX'.join([n,c])) 
      sess_input(n,sessid)
      sess_flow_id('select_diag_name',sessid)
      op_json=blank_response_json(sessid)
    else:
      text=('Sorry!! I could not find any diagnostic test relevant to your query..\n')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_select_diag_name'):
      ip=ip[0]
      temp=read_sess_input(sessid)
      ip=('XXXXX'.join([temp,ip]))
      sess_input(ip,sessid)
      sess_flow_id('select_diag_name_continue',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='select_diag_name'):
      ip=read_sess_input(sessid).split('XXXXX')
      names=ip[0].split('YYYYY')
      codes=ip[1].split('YYYYY')
      options=names
      names=np.array(names) 
      text='Please select the Diagnosic test based on the query\n'
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('input_select_diag_name',sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='select_diag_name_continue'):
      ip=read_sess_input(sessid).split('XXXXX')
      names=ip[0].split('YYYYY')
      codes=ip[1].split('YYYYY')
      ip=ip[2]
      names=np.array(names) 
      name=names[int(ip)-1]
      code=codes[int(ip)-1]
      diag_price={}
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_price.csv')
      f=csv.reader(f)
      for i in f:
        diag_price[i[0]]=[i[1],i[2]]
      diag_info={}
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_info.csv')
      f=csv.reader(f)
      for i in f:
        diag_info[i[0]]=[i[1]]
      diag_package={}
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_package.csv')
      f=csv.reader(f)
      for i in f:
        diag_package[i[0]]=[i[1:]]
      packages=[]
      for i,j in diag_package.items():
        if (code in j[0]):
          packages.append(i)
      if (len(packages)<=0):
        text='The test '+str(name)+' is usually priced between Rs '+str(diag_price[code][0])+' and Rs '+str(diag_price[code][1])+' and has the following purpose \n'+str(diag_info[code][0])
        options=[]
        flow_id='main_menu'
        op_json=text_blank_response_json(text,options,flow_id,sessid)
      else:
        text='The test '+str(name)+' is usually priced between Rs '+str(diag_price[code][0])+' and Rs '+str(diag_price[code][1])+' and has the following purpose \n'+str(diag_info[code][0])+'\nThis test is available in the following packages\n'
        options=packages
        flow_id='main_menu'
        op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json) 



