from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from wish_date_time import *
import numpy as np
import csv
import nltk


words=stopwords.words('english')

f=open('/home/buildadmin/yash/call-health-server/medibot/source/symptoms filter.csv')
f=csv.reader(f)
sym_male=[]
sym_female=[]
for i in f:
  if (i[1]=='Yes'):
    sym_male.append(i[0])
  if (i[2]=='Yes'):
    sym_female.append(i[0])



f=open('/home/buildadmin/yash/call-health-server/medibot/source/all_mdp_symp_crawl.csv')
f=csv.reader(f)

sym_crawl={}
sym_list_final=[]
for i in f:
  sym_crawl[i[0]]=[re.sub(' +',' ',re.sub('[0-9]','',i[1])).lower()]  
  sym_list_final.append(i[0].lower())



sym_mdp_map={}
f=open('/home/buildadmin/yash/call-health-server/medibot/source/matching syn sym.csv')
f=csv.reader(f)
for i in f:
  key=i[0]
  t=[]
  for j in i[1:]:
    if (j!=''):
      t.append(j)
  value=t
  sym_mdp_map[key]=value




embeddings_index = {}
f = open('/home/buildadmin/yash/call-health-server/medibot/source/glove.6B.300d.txt')
for line in f:
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    embeddings_index[word] = coefs


f.close()   



pubmed_index={}
f = open('/home/buildadmin/yash/call-health-server/medibot/source/pubmet categories.csv')
f=csv.reader(f)
for i in f:
  pubmed_index[i[0]]=i[1:3]




f=open('/home/buildadmin/yash/call-health-server/medibot/source/medical bayes test.csv')
f=csv.reader(f)
dis=[]
sym=[]
for i in f:
  dis.append(i[0].lower())
  sym.append(i[2].lower())



dis=dis[1:]
sym=sym[1:]
dis_final=np.unique(dis)
sym_final=np.unique(sym)



def cleaned_query(q):
  stop_words=stopwords.words('english')
  q_clean=[]
  for i in q.split():
    if (i not in stop_words):
      if (i not in q_clean):
        q_clean.append(i)
  return (' '.join(q_clean))



def exact_match(gender,q):
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=0
      if (i.upper() in sym_male):
        if (cleaned_query(q)==i):
          t=t+1
      sym_list[i]=t
  else:
    for i,j in sym_crawl.items():
      t=0
      if (i.upper() in sym_female):
        if (cleaned_query(q)==i):
          t=t+1
      sym_list[i]=t
  return (sym_list)



def part_match1(q):
  sym_list={}
  nouns=[]
  adj=[]
  vbz=[]
  for i in nltk.pos_tag(cleaned_query(q).split()):
    if ('NN' in i[1]):
      nouns.append(i[0])
    if ('JJ' in i[1]):
      adj.append(i[0])
    if ('VB' in i[1]):
      vbz.append(i[0])
  flag=0
  for i,j in sym_crawl.items():
    if (q in j[0]):
      flag=1      
  if (flag==0):
    sent1=[]
    for i in q.lower().split():
      if (i not in words):
        sent1.append(i)
        nouns=[]
        adj=[]
        verbs=[]
        for i in pos_tag(sent1):
          if ('NN' in i[1]):
            nouns.append(i[0])
          elif ('JJ' in i[1]):
            adj.append(i[0])
          elif ('VB' in i[1]):
            vbz.append(i[0])
          else:
            pass
    vote=np.zeros(len(sym_list_final),)
    for i,j in sym_crawl.items():
      for k in nouns:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(10*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]]) 
      for k in adj:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(1*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]]) 
      for k in vbz:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(1*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]])  
    if (np.sum(vote)>0):
      for i in np.arange(len(sym_list_final)):
        sym_list[sym_list_final[i]]=vote[i]
    else:
      print ('Sorry I did not understand your query')
  else:
    vote=np.zeros(len(sym_list_final),)
    for i,j in sym_crawl.items():
      vote[np.where(i==np.array(sym_list_final))[0][0]]=len(j[0].split(q))-1
  for i in np.arange(len(sym_list_final)):
    sym_list[sym_list_final[i]]=vote[i]
  return (sym_list)



def phrase_match(gender,q):  
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=0
      if (cleaned_query(q) in j[0]):
        if (i.upper() in sym_male): 
          t=t+1 
      sym_list[i]=t
  else:
    for i,j in sym_crawl.items():
      t=0
      if (cleaned_query(q) in j[0]):
        if (i.upper() in sym_female): 
          t=t+1 
      sym_list[i]=t
  return (sym_list)



def syn_phrase_match(gender,q):
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_mdp_map.items():
      t=0
      if (cleaned_query(q) in j):
        if (i.upper() in sym_male):
          t=t+1
      for k in j:
        if (k in cleaned_query(q)):
          if (i.upper() in sym_male):
            t=t+1
      sym_list[i]=t
  if (gender=='f' or gender=='F'):
    for i,j in sym_mdp_map.items():
      t=0
      if (cleaned_query(q) in j):
        if (i.upper() in sym_female):
          t=t+1
      for k in j:
        if (k in cleaned_query(q)):
          if (i.upper() in sym_female):
            t=t+1
      sym_list[i]=t
  return (sym_list)




def syn_match(gender,q):
  q=cleaned_query(q).lower() 
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_mdp_map.items():
        t=0
        if (i.upper() in sym_male): 
          for k in j:
            if (k==q):
              t=t+50
            if ((k in q) or (q in k)):
              t=t+len(list(set(nltk.word_tokenize(cleaned_query(q))).intersection(nltk.word_tokenize(k))))
        sym_list[i]=t
  else:
    for i,j in sym_mdp_map.items():
        t=0
        for k in j:
          if (k==q):
            t=t+50
          if ((k in q) or (q in k)):
            t=t+len(list(set(nltk.word_tokenize(cleaned_query(q))).intersection(nltk.word_tokenize(k))))
        sym_list[i]=t
  return (sym_list)


def part_match(gender,q):
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=[]
      for k in re.sub('[^a-zA-Z  ]','',i.lower()).split():
        for l in cleaned_query(q).split():
          try:
            if (i.upper() in sym_male):
              t.append((1-dist(embeddings_index[k],embeddings_index[l])))
          except:
            t.append(0)
      if (len(t)>0): 
        sym_list[i]=np.mean(t)
      else:
        sym_list[i]=0
  else:
    for i,j in sym_crawl.items():
      t=[]
      for k in re.sub('[^a-zA-Z  ]','',i.lower()).split():
        for l in cleaned_query(q).split():
          try:
            if (i.upper() in sym_female):
              t.append((1-dist(embeddings_index[k],embeddings_index[l])))
          except:
            t.append(0)
      if (len(t)>0): 
        sym_list[i]=np.mean(t)
      else:
        sym_list[i]=0
  return (sym_list)  




def wn_match(q):
  sym_list={}
  for i,j in sym_crawl.items():
    list=[]
    for word1 in re.sub('[^a-zA-Z  ]','',i).split():
      for word2 in re.sub('[^a-zA-Z  ]','',cleaned_query(q)).split():
        wordFromList1 = wordnet.synsets(word1)
        wordFromList2 = wordnet.synsets(word2)
        if wordFromList1 and wordFromList2: 
          s = wordFromList1[0].wup_similarity(wordFromList2[0])
          list.append(s)
    sym_list[i]=np.max(list)
  return (sym_list)



##############################################################################


def sym_anti(gender,q):
  sym_list_scores0=np.zeros((len(sym_list_final),))
  for key,value in exact_match(gender,q).items():
    sym_list_scores0[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores0)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores0)])
  sym_list_scores1=np.zeros((len(sym_list_final),))
  for key,value in syn_match(gender,q).items():
    sym_list_scores1[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores1)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores1)])
  sym_list_scores4=np.zeros((len(sym_list_final),))
  for key,value in part_match(gender,q).items():
    sym_list_scores4[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores4)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores4)])
  else:
    return ('404') 


