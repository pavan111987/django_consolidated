import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *


words=stopwords.words('english')


def name_gender(q):
 try: 
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/indian_names.csv')
  f=csv.reader(f)
  m_names=[]
  f_names=[]
  for i in f:
    if (i[1]=='m'):
      m_names.append(i[0])
    else:
      f_names.append(i[0])
  first_name=nltk.word_tokenize(q)[0].capitalize()
  m=0
  f=0
  for i in nltk.word_tokenize(q):
    for j in m_names:
      if (i==j):
        m=m+1
    for j in f_names:
      if (i==j):
        f=f+1
  if (m>f):
    return ('m',first_name)
  elif (f>m):
    return ('f',first_name)
  else:
    return ('404',first_name)
 except:
  return (['404'])


