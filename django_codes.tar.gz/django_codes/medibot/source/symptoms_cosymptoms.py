import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random


f=open('/home/buildadmin/yash/call-health-server/medibot/source/symptoms filter.csv')
f=csv.reader(f)
sym_male=[]
sym_female=[]
for i in f:
  if (i[1]=='Yes'):
    sym_male.append(i[0])
  if (i[2]=='Yes'):
    sym_female.append(i[0])




f=open('/home/buildadmin/yash/call-health-server/medibot/source/medical bayes test.csv')
f=csv.reader(f)
dis=[]
sym=[]
for i in f:
  dis.append(i[0].lower())
  sym.append(i[2].lower())



dis=dis[1:]
sym=sym[1:]
dis_final=np.unique(dis)
sym_final=np.unique(sym)

co=[]
f=open('/home/buildadmin/yash/call-health-server/medibot/source/co.csv')
f=csv.reader(f)
for i in f:
  for j in i:
    co.append(float(j))


co=np.array(co).reshape(len(sym_final),len(sym_final))




def gen_co_sym():
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/medical bayes test.csv')
  f=csv.reader(f)
  dis=[]
  sym=[]
  for i in f:
    dis.append(i[0].lower())
    sym.append(i[2].lower())
  dis=dis[1:]
  sym=sym[1:]
  dis_final=np.unique(dis)
  sym_final=np.unique(sym)
  co=np.zeros((len(sym_final),len(sym_final)))
  for k in dis_final:
    for i in np.array(sym)[k==np.array(dis)]:
      for j in np.array(sym)[k==np.array(dis)]:
        co[np.where(i==sym_final)[0][0],np.where(j==sym_final)[0][0]]=co[np.where(i==sym_final)[0][0],np.where(j==sym_final)[0][0]]+1
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/co.csv',co,delimiter=',',fmt="%d")






#s=['fever','headache','sore throat']
def co_sym_suggest(gender,s):
  if (gender=='m' or gender=='M'):
    temp=np.zeros((len(sym_final),))
    for i in s:
      if (i.upper() in sym_male): 
        temp=temp+co[np.where(i==sym_final)[0][0]]
    co_sym=[]
    for i in np.array(sym_final)[np.argsort(temp)[::-1][0:20]]:
      if (i not in s):
        if (i.upper() in sym_male): 
          co_sym.append(i)
  else:
    temp=np.zeros((len(sym_final),))
    for i in s:
      if (i.upper() in sym_female): 
        temp=temp+co[np.where(i==sym_final)[0][0]]
    co_sym=[]
    for i in np.array(sym_final)[np.argsort(temp)[::-1][0:20]]:
      if (i not in s):
        if (i.upper() in sym_female):
          co_sym.append(i)
  return (co_sym[0:3])




