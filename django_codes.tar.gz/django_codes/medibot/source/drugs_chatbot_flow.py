import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *
from symptoms_cosymptoms import *
from dd_functions import *
from weather_and_location import *
from symptom_to_speciality import *
from mayo_articles_code import *
from name_to_gender import *
from drugs_code import *
from diagnostics_code import *
from chatbot_datafiles_code import *
from json_response_code import *
from symptom_checker_flow import *


words=stopwords.words('english')

def drugs_bot_flow(mob,sessid,ip,request_type):
  if (str(read_sess_flow_id(sessid))=='drugs_flow'):
    text=('Tell me the name of the medicine you wish to know about')
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_drugs_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_drugs_flow'):
    ip=ip
    ip=ip.lower()
    sess_input(ip,sessid)
    op_json=blank_response_json(sessid)
    sess_flow_id('drugs_flow_continue',sessid)
    return (op_json)   
  if (str(read_sess_flow_id(sessid))=='drugs_flow_continue'):
    q=read_sess_input(sessid) 
    q=drugs_clean(q)
    q_name=read_sess_input(sessid)
    q_name=nltk.word_tokenize(drugs_clean(q_name))[0]
    vote=[]
    if (q!='404'):
      vote=[]
      name=[]
      cat=[]
      temp=[]
      for i in nltk.word_tokenize(q):
        if (i not in words):
          if (len(i)>=3):
            temp.append(i)
      q=(' '.join(temp))
      for i,j in brand_molecule.items():
        count=0
        name.append(i)
        cat.append(j[1])
        for k in q.split():
          if (k==i.split()[0]):
            count=count+1
          try:
            if (k==i.split()[1]):
              count=count+0.5
          except:
            pass 
        vote.append(count)
    if (np.sum(vote)>0):
      v=np.array(vote)[np.where(np.array(vote)>0)]
      c_uniq=np.unique(np.array(cat)[np.where(np.array(vote)>0)])
      c=np.array(cat)[np.where(np.array(vote)>0)]
      n=np.array(name)[np.where(np.array(vote)>0)]
      v=v[np.argsort(v)[::-1]]
      n=n[np.argsort(v)[::-1]]
      c=c[np.argsort(v)[::-1]]
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_name_log.csv')
      f=csv.reader(f)
      name_log={}
      for i in f:
        name_log[i[0]]=i[1]
      name_log[sessid]=str('XXXXX'.join(n))
      new_data=[]
      for i,j in name_log.items():
        new_data.append(i)
        new_data.append(j)
      new_data=np.array(new_data).reshape((len(new_data)/2),2)
      np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_name_log.csv',new_data,delimiter=',',fmt="%s")
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_cat_log.csv')
      f=csv.reader(f)
      cat_log={}
      for i in f:
        cat_log[i[0]]=i[1]
      x=[]
      for i in c:
        x.append(i[0])
      cat_log[sessid]=str('XXXXX'.join(x))
      new_data=[]
      for i,j in cat_log.items():
        new_data.append(i)
        new_data.append(j)
      new_data=np.array(new_data).reshape((len(new_data)/2),2)
      np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_cat_log.csv',new_data,delimiter=',',fmt="%s")
      options=list(c_uniq)
      if (len(options)>1):
       if (read_sess_name(sessid)!=''): 
         text=nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+' the medicine comes in the following forms. Please choose one to know the details'
       else:
         text='The medicine comes in the following forms. Please choose one to know the details' 
       sess_flow_id('input_dose_form',sessid)
       x=[]
       for i in options:
         x.append(i.capitalize())
       options=x
       op_json=text_ss_response_json(text,options,sessid)
       return (op_json)
      else:
        ip='1'
        sess_input(ip,sessid)
        sess_flow_id('drug_brand_names',sessid) 
        op_json=blank_response_json(sessid)
        return (op_json)     
    else:
      sess_flow_id('no_drug_match',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dose_form'):
    ip=ip[0]
    sess_input(ip,sessid)
    sess_flow_id('drug_brand_names',sessid) 
    op_json=blank_response_json(sessid)
    return (op_json)     
  if (str(read_sess_flow_id(sessid))=='input_drug_brand_names'):
    ip=ip[0]
    temp=read_sess_input(sessid)
    ip='XXXXX'.join([ip,temp])
    sess_input(ip,sessid)
    sess_flow_id('drug_brand_names_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='drug_brand_names'):
    ip=read_sess_input(sessid)
    flag1=0
    flag2=0
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_name_log.csv')
    f=csv.reader(f)
    name_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag1=1
        n=i[1].split('XXXXX')
        break
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_cat_log.csv')
    f=csv.reader(f)
    cat_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag2=1
        c=i[1].split('XXXXX')
        break
    if ((flag1!=0) and (flag2!=0)):
      ip=read_sess_input(sessid)
      c_uniq=np.unique(c) 
      n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip)-1]==np.array(c))[0]]
      c_selected=np.array(c_uniq)[int(ip)-1]
      options=[]
      for i in n_final:
        options.append(i)
      if (len(options)>1):  
        text=('Please select the dosage')
        sess_flow_id('input_drug_brand_names',sessid)
        sess_input(ip,sessid)
        x=[]
        for i in options:
          x.append(i.capitalize())
        options=x 
        op_json=text_ss_response_json(text,options,sessid)
        return (op_json)
      else:
        ip='1'
        temp=read_sess_input(sessid)
        ip='XXXXX'.join([ip,temp])
        sess_input(ip,sessid)
        sess_flow_id('drug_brand_names_continue',sessid)
        op_json=blank_response_json(sessid)
        return (op_json)
  if (str(read_sess_flow_id(sessid))=='drug_brand_names_continue'):
    ip=read_sess_input(sessid).split('XXXXX')[0]
    ip1=read_sess_input(sessid).split('XXXXX')[1] 
    flag1=0
    flag2=0
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_name_log.csv')
    f=csv.reader(f)
    name_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag1=1
        n=i[1].split('XXXXX')
        break
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/drug_cat_log.csv')
    f=csv.reader(f)
    cat_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag2=1
        c=i[1].split('XXXXX')
        break
    if ((flag1!=0) and (flag2!=0)):
      c_uniq=np.unique(c) 
      n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip1)-1]==np.array(c))[0]]
      c_selected=np.array(c_uniq)[int(ip1)-1]
      for i,j in brand_molecule.items():
        if (i==n_final[int(ip)-1]):
          break
      comp=('YYYYY'.join(j[0]))
      brand_name=n_final[int(ip)-1]
      write_sess_brand(brand_name,sessid)
      cat_selected=c_selected
      sess_input(('XXXXX'.join([brand_name,comp,cat_selected])),sessid)
      sess_flow_id('mole_rx',sessid)
      op_json=blank_response_json(sessid)
    else:
      sess_flow_id('no_drug_match',sessid)
      op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='no_drug_match'):    
    text="Sorry! I don't understand"
    flow_id='main_menu'
    options=[]
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='mole_rx'):    
    rx_mole_list=[]
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_rx_mole_master.csv')
    f=csv.reader(f)
    for i in f:
      rx_mole_list.append(i[0])
    ip=read_sess_input(sessid)
    ip=ip.split('XXXXX')
    c_selected=[ip[2]]
    mole=ip[1].split('YYYYY')
    vote=[]
    name=[]
    for i in rx_mole_list:
      count=0
      name.append(i) 
      for j in mole:
        for k in nltk.word_tokenize(j):
          if (i==k):
            count=count+1
      vote.append(count)
    if (np.sum(vote)>0):
      n=np.array(name)[np.where(np.max(vote)==np.array(vote))]	
      v=np.array(vote)[np.where(np.max(vote)==np.array(vote))]
      a='YYYYY'.join(n)
      b=c_selected[0]
      a='XXXXX'.join([a,b])
      sess_input(a,sessid)
      sess_flow_id('drugs_info_final',sessid)
      op_json=blank_response_json(sessid)
    else:
      text="Sorry! I did not find any information for the medicine"
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='drugs_info_final'):
    text='What do you want to know?'
    options=['Drug Use Information','Drug Mechanism of Action','Drug Contra-indications','Drug Physiologic effects','Drug Substitutes']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_drugs_info_final',sessid) 
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_drugs_info_final'):
    ip=ip[0]
    past=read_sess_input(sessid).split('XXXXX')
    temp=('XXXXX'.join([past[0],past[1],ip]))
    sess_input(temp,sessid)
    sess_flow_id('drugs_info_final_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='drugs_info_final_continue'):
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_dis_contra.csv')
    f=csv.reader(f)
    dis_contra={}
    for i in f:
      dis_contra[i[0]]=i[1:]
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_moa.csv')
    f=csv.reader(f)
    drug_moa={}
    for i in f:
      drug_moa[i[0]]=i[1:]
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_pe_induces.csv')
    f=csv.reader(f)
    drug_pe={}
    for i in f:
      drug_pe[i[0]]=i[1:]
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_uses.csv')
    f=csv.reader(f)
    drug_uses={}
    for i in f:
      drug_uses[i[0]]=[' '.join((', '.join(i[1:]).split('\n')))]
    ip=read_sess_input(sessid)
    ip=ip.split('XXXXX')
    choice=ip[2] 
    mole=ip[0].split('YYYYY')
    if (mole[0]!='404'):
      c_selected=ip[1]
      drug_info_uses=[]
      drug_info_uses.append('     The uses of the drug are:')
      drug_info_moa=[]
      drug_info_moa.append('     The following is the Mechanism of Action:')
      drug_info_contra=[]
      drug_info_contra.append('     The following is the drug contra indication:')
      drug_info_physio=[]
      drug_info_physio.append('     The following is the drug physiologic effects:')
      drug_info_subs=[]
      drug_info_subs.append('    The following are the substitutes for the drug:') 
      for i in mole:
        try:
          drug_info_uses.append(drug_uses[i][0].capitalize())
        except:
          pass
        try:
          drug_info_moa.append(str(i).capitalize()+' '+(' '.join(drug_moa[i])).capitalize())
        except:
          pass
        try:
          drug_info_contra.append(str(i).capitalize()+' '+(' '.join(dis_contra[i])).capitalize())
        except:
          pass
        try:         
          drug_info_physio.append(str(i).capitalize()+' '+(' '.join(drug_pe[i])).capitalize())
        except:
          pass
      subs=[]
      for i,j in brand_molecule.items():
        if (set(j[0])==set(mole)):
          if (j[1][0]==c_selected):
            subs.append(i)
      if (len(subs)>0):
        count=0
        for i in subs:
          if (count<=5): 
            drug_info_subs.append(i.title())
            count=count+1
      if (str(choice)=='1'):
        if (len(drug_info_uses)>1):
          options=drug_info_uses
        else:
          options=['Sorry!! No usage information is available for the medicine']
      if (str(choice)=='2'):
        if (len(drug_info_moa)>1):
          options=drug_info_moa
        else:
          options=['Sorry!! No mechanism of action information is available for the medicine']
      if (str(choice)=='3'):
        if (len(drug_info_contra)>1):
          options=drug_info_contra
        else:
          options=['Sorry!! No contra-indication information is available for the medicine']
      if (str(choice)=='4'):
        if (len(drug_info_physio)>1):
          options=drug_info_physio
        else:
          options=['Sorry!! No drug physiologic effects information is available for the medicine']
      if (str(choice)=='5'):
        if (len(drug_info_subs)>1):
          options=drug_info_subs
        else:
          options=['Sorry!! No substitute information is available for the medicine']
      text='Drugs Information: '+str(read_sess_brand(sessid).title())
      flow_id='more_drugs_info'
      op_json=text_blank_response_json(text,options,flow_id,sessid) 
    else:
      text=('Sorry!! I could not find any information relevant to your query\n')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='more_drugs_info'):
    text=('Do you want to know more about it?')
    options=['Yes','No']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_more_drugs_info',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_more_drugs_info'):
    ip=ip[0]
    if (str(ip)=='1'):
      sess_flow_id('drugs_info_final',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      text='Does this information help?'
      options=['Yes','No']
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('input_feedback_response',sessid)
      return (op_json)

