import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *


words=stopwords.words('english')




def diag_names_match(q):
 try:
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_name.csv')
  f=csv.reader(f)
  dic=[]
  diag_name={}
  for i in f:
    temp=[]
    for j in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',i[0].lower())):
      if (j not in words):
        if (j!=''):
          temp.append(j)
    for j in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',i[1].lower())):
      if (j not in words):
        if (j!=''):
          temp.append(j) 
    for j in temp:
      if (j!='done'):
        if (len(j)>=3):
          dic.append(j)
    diag_name[i[0]]=[temp,i[2]]
  dic=np.unique(dic)
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/diag_name_list.csv',dic,delimiter=',',fmt="%s") 
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/diag_name_list.csv')
  f=csv.reader(f)
  diag_names=[]
  for i in f:
    diag_names.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',q.lower())):
    if (i not in words):
      if (i in diag_names):
        if (i!=''):
          temp.append(i)
  q=(' '.join(temp))
  pop=[]
  pop_code=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/diag_test_popularity.csv')
  f=csv.reader(f)
  for i in f:
    pop_code.append(i[0])
    pop.append(float(i[1]))
  names=[]
  vote=[]
  codes=[]  
  for i,j in diag_name.items():
    names.append(i)
    codes.append(j[1])
    t=0
    for k in nltk.word_tokenize(q):
      t=t+(j[0].count(k))
    if (len(np.where(np.array(pop_code)==j[1])[0])>0):
      vote.append(t*10*pop[np.where(np.array(pop_code)==j[1])[0][0]])
    else:
      vote.append(t)
  if (np.sum(vote)>0):
    names_final=np.array(names)[np.argsort(vote)[::-1]]
    codes_final=np.array(codes)[np.argsort(vote)[::-1]]
    vote_final=np.array(vote)[np.argsort(vote)[::-1]]
    n=[]
    c=[]
    for i in np.arange(len(vote_final)):
      if (vote_final[i]>0):
        n.append(names_final[i])
        c.append(codes_final[i])
    if (len(n)>5):
      return (n[0:5],c[0:5])
    else:
      return (n,c)
  else:
    return ([['404']])
 except:
  return ([['404']])






def diag_full_info(q):
  res=diag_names_match(q)
  if (res[0][0]!='404'):
    names=res[0]
    codes=res[1]
    print (names.reshape(len(names),1))
    ip=raw_input('Please select the Diagnosic test based on the query\n')
    name=names[int(ip)-1]
    code=codes[int(ip)-1]
    diag_price={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_price.csv')
    f=csv.reader(f)
    for i in f:
      diag_price[i[0]]=[i[1],i[2]]
    diag_info={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_info.csv')
    f=csv.reader(f)
    for i in f:
      diag_info[i[0]]=[i[1]]
    diag_package={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_package.csv')
    f=csv.reader(f)
    for i in f:
      diag_package[i[0]]=[i[1:]]
    packages=[]
    for i,j in diag_package.items():
      if (code in j[0]):
        packages.append(i)
    if (len(packages)<=0):
      return ('The test '+str(name)+' is usually priced between Rs '+str(diag_price[code][0])+' and Rs '+str(diag_price[code][1])+' and has the following purpose \n'+str(diag_info[code][0]))     
    else:
      return ([['The test '+str(name)+' is usually priced between Rs '+str(diag_price[code][0])+' and Rs '+str(diag_price[code][1])+' and has the following purpose \n'+str(diag_info[code][0])+'\nThis test is available in the following packages\n'],[np.array(packages).reshape(len(packages),1)]])
  else:
    return ('404')






