import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *


words=stopwords.words('english')


def mayo_articles_url(q):
  urls=[]
  q=cleaned_query(q)
  q=q.lower()
  ques=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      ques.append(i)
  q=(' '.join(ques)) 	  
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/mayo_articles.csv')
  f=csv.reader(f)
  data=[]
  for i in f:
    data.append(' '.join(i[1].split()))
    urls.append(i[0])
  vote=np.zeros((len(data),1))
  for i in nltk.word_tokenize(q):
    for j in np.arange(len(data)):
      vote[j,0]=vote[j,0]+len(data[j].lower().split(i))-1
  temp=[]
  for i in vote:
    temp.append(i[0])
  vote=temp
  if (np.sum(vote)>0):
    return (np.array(urls)[np.argsort(vote)[::-1]][0:10])
  else:
    return (['404'])



