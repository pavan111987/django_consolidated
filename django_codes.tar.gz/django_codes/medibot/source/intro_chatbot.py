import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *
from symptoms_cosymptoms import *
from dd_functions import *
from weather_and_location import *
from symptom_to_speciality import *
from mayo_articles_code import *
from name_to_gender import *
from drugs_code import *
from diagnostics_code import *
from chatbot_datafiles_code import *
from json_response_code import *
from symptom_checker_flow import *


words=stopwords.words('english')


def intro_bot_flow(mob,sessid,ip,request_type):
  if (str(read_sess_flow_id(sessid))=='check_user'):
    if (read_user_profile(mob)!='404'):
      write_sess_name(read_user_profile(mob)[0],sessid)
      write_sess_age(read_user_profile(mob)[1],sessid)
      write_sess_gender(read_user_profile(mob)[2],sessid)
      write_sess_location(read_user_profile(mob)[3],sessid)
      sess_flow_id('get_weather',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    elif (mob=='404'):
      write_sess_name('',sessid)
      write_sess_location('Hyderabad, India',sessid) 
      sess_flow_id('get_weather',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
    else:
      try: 
        weather = weather_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        #location = location_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        location='Hyderabad, India'   
        write_sess_location(location,sessid) 
      except:
        location='Hyderabad, India'   
        weather = weather_by_latlon(float(17.5),float(78.5))
        write_sess_location(location,sessid)
      temperature = weather[1]
      weather_cond = weather[0]
      min_temp = weather[2]
      max_temp = weather[3] 
      text=str(wish_on_time(sessid))+" It's now "+str(temperature)+" Deg C, "+weather_cond.capitalize()+str(" outside with a max of ")+str(max_temp)+str(" Deg C and a min of ")+str(min_temp)+' Deg C'
      options=[]
      flow_id='check_user_continue'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='check_user_continue'):
    text="Lets introduce ourselves to begin with. I am your Personal Health Assistant. What's your name?"
    op_json=text_response_json(text,sessid)
    sess_flow_id('new_user_name',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='new_user_name'):
    ip=ip
    write_sess_name(ip,sessid)
    sess_flow_id('new_user_age',sessid)
    op_json=blank_response_json(sessid)
    sess_input('newuser',sessid) 
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='new_user_age'):
    text='What is your age?'
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_new_user_age',sessid)       
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_new_user_age'):
    ip=ip
    clean_ip=re.sub('[^0-9]','',ip)
    if ((clean_ip=='') or (int(clean_ip)>110)):      
      text='Sorry! I could not understand. Please try again'
      options=[]
      flow_id='new_user_age'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json) 
    else:
      write_sess_age(int(clean_ip),sessid)
      sess_flow_id('new_user_gender',sessid)
      op_json=blank_response_json(sessid)  
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='new_user_gender'):
    g=name_gender(read_sess_name(sessid))
    if (g[0]=='404'):
      options=['Male','Female']
      text='And your gender?'
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('new_user_gender_input_dd_gender',sessid)
      return (op_json) 
    elif (g[0]=='m'):
      text="'"+str(read_sess_name(sessid)).capitalize()+"' seems a male name. Am I right?"
      options=['Yes','No']
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('new_user_input_gender_male_guess',sessid)
      return (op_json)
    elif (g[0]=='f'):
      text="'"+str(read_sess_name(sessid)).capitalize()+"' seems a female name. Am I right?"
      options=['Yes','No']
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('new_user_input_gender_female_guess',sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='new_user_gender_input_dd_gender'):
    ip=str(ip[0])
    if (ip=='1'):
      write_sess_gender('m',sessid)
      sess_flow_id('get_weather',sessid)
      sess_input('newuser',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      write_sess_gender('f',sessid)
      sess_flow_id('get_weather',sessid)
      sess_input('newuser',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='new_user_input_gender_male_guess'):
    ip=ip[0]
    if (ip=='1'):
      write_sess_gender('m',sessid)
      sess_flow_id('get_weather',sessid)
      sess_input('newuser',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)         
    else:
      flow_id='new_user_gender_wrong'
      write_sess_gender('f',sessid)
      options=[]
      text='Oops!'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)         
  if (str(read_sess_flow_id(sessid))=='new_user_input_gender_female_guess'):
    ip=ip[0]
    if (ip=='1'):
      write_sess_gender('f',sessid)
      sess_flow_id('get_weather',sessid)
      op_json=blank_response_json(sessid)
      sess_input('newuser',sessid)
      return (op_json)         
    else:
      flow_id='new_user_gender_wrong'
      write_sess_gender('m',sessid)
      options=[]
      text='Oops!'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)         
  if (str(read_sess_flow_id(sessid))=='new_user_gender_wrong'):
    text='Oops! :('
#    write_sess_gender(read_sess_input(sessid),sessid)
    write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid)) 
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/indian_names.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1]
    data[read_sess_name(sessid)]=read_sess_gender(sessid)        
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      new_data.append(j)
    new_data=np.array(new_data).reshape((len(new_data)/2),2)
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/indian_names.csv',new_data,delimiter=',',fmt="%s")
    flow_id='get_weather'
    options=[]
    sess_input('newuser',sessid)
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='get_location'):
    if (read_sess_latlon(sessid)[0]=='404'):
      text='Where are you from?\n'
      op_json=text_response_json(text,sessid)
      sess_flow_id('input_get_location',sessid)
      return (op_json)
    else:
      try:
        location = location_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        write_sess_location(location,sessid)
        sess_flow_id('get_weather',sessid)
        op_json=blank_response_json(sessid)
        return (op_json) 
      except:
        location='Hyderabad, India'   
        write_sess_location(location,sessid)
        sess_flow_id('get_weather',sessid)
        sess_input('newuser',sessid)
        op_json=blank_response_json(sessid)
        return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_get_location'):
    ip=ip
    location=geo_loc(ip)
    write_sess_location(re.sub('[^a-zA-Z0-9 ]','',location),sessid)
    sess_flow_id('get_weather',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='get_weather'):
    if (mob=='404'):
      try:
        if (read_sess_name(sessid)!=''):
          text=wish_on_time(sessid)+" "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
        else:
          text=wish_on_time(sessid)+"!"+" How can I help you?"
      except:
        if (read_sess_name(sessid)!=''):
          text=wish()+" "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
        else:
          text=wish()+"!"+" How can I help you?"
      flow_id='main_menu'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
    elif (read_sess_latlon(sessid)[0]=='404'):
      try:
        if (read_sess_input(sessid)=='newuser'):
          text="So "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
        else:
          text=wish_on_time(sessid)+" "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
      except:
        if (read_sess_input(sessid)=='newuser'):
          text="So "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
        else:
          text=wish_on_time(sessid)+" "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
      flow_id='main_menu'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
    else:
      try: 
        weather = weather_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        #location = location_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        location='Hyderabad, India'   
        write_sess_location(location,sessid) 
      except:
        location='Hyderabad, India'   
        weather = weatherapi(location)
        write_sess_location(location,sessid)
      temperature = weather[1]
      weather_cond = weather[0]
      min_temp=weather[2]
      max_temp=weather[3]
      if (read_sess_input(sessid)=='newuser'):
        text = "Hello "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+", How can I help you ?"      
      else: 
        text="It's now "+str(temperature)+" Deg C, "+weather_cond.capitalize()+str(" outside with a max of ")+str(max_temp)+str(" Deg C and a min of ")+str(min_temp)+' Deg C'+", How can I help you "+read_sess_name(sessid).capitalize()+"?" 
        #text="Hello, How can I help you "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"?" 
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)


