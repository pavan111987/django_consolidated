import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random




def diff_diag(age,gender,symps):
  object={}
  object['age']=age
  object['gender']=gender
  object['symptoms']=symps
  object['Medical History']=['NONE']
  object['Clinical Finding']=['NONE']
  ip_json=json.dumps(object)
  ip_json=str(ip_json)
  enc_ip_json=str('XXX'.join(ip_json.split('"')))
  command=str('Rscript /home/buildadmin/yash/call-health-server/medibot/source/dd/diff_diag.R "'+enc_ip_json+'"')
  os.system(command)
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/dd result.txt')
  lines = f.readlines()  
  f.close()
  op=json.loads(''.join(lines))
  dd=[]
  for i in np.arange(5):
    if (op[str(i+1)]['Score']>0):
      dd.append(str(op[str(i+1)]['Disease']))
      dd.append(str(round(op[str(i+1)]['Score']))) 
  dd=np.array(dd).reshape(int(len(dd)/2),2)
  return (dd)


def correct(s_new,sym,c,f):   
  sym.append(s_new)
  c=c+1 
  return (sym,c,f)


def incorrect(sym,c,f):
  print ('I am sorry, I could not understand you. Please reword/rephrase your medical problem\n\n')
  f=f+1
  return (sym,c,f)


def no_match(sym,c,f):
  print ('I am sorry, I could not understand you. Please reword/rephrase your medical problem\n\n')
  f=f+1
  return (sym,c,f)
     

s=[]
count=0
flag=0

def symps_input():
  ip=raw_input('Please be very specific in your description\nI need to know some symptoms, like cold, fever etc. The more precise you are, the more relevant diagnosis I will be able to do \n\n')
  return (ip)




def diff_diag_converse(gender):
  s=[]
  flag=0
  count=0
  temp_q=[] 
  while ((flag<=3) and (count<5)):
    if (count==0):
      cls_screen()  
      ip=symps_input()
      temp_q.append(ip)
      s_temp=sym_anti(gender,ip)
      if (s_temp!='404'):
        print (str('Based on the description of your medical problem, I have identified "')+s_temp+str('" as the symptom\n'))
        d=raw_input('Do you want to proceed further (y/n)\n')     
      else:
        s,count,flag=no_match(s,count,flag)
      if ((d=='y') or (d=='Y')):
        f=open('/home/buildadmin/yash/call-health-server/medibot/source/correct.csv')
        f=csv.reader(f)
        data=[]
        for row in f:
          data.append(row[0])
          data.append(row[1])
        data.append(cleaned_query(ip))
        data.append(s_temp)
        data=np.array(data).reshape(int(len(data)/2),2)
        np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/correct.csv',data,delimiter=',',fmt="%s") 
        s,count,flag=correct(s_temp,s,count,flag) 
      else:
        f=open('/home/buildadmin/yash/call-health-server/medibot/source/incorrect.csv')
        f=csv.reader(f)
        data=[]
        for row in f:
          data.append(row[0])
          data.append(row[1])
        data.append(cleaned_query(ip))
        data.append(s_temp)
        data=np.array(data).reshape(int(len(data)/2),2)
        np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/incorrect.csv',data,delimiter=',',fmt="%s") 
        s,count,flag=incorrect(s,count,flag)
    else:
      cls_screen()
      print (np.array(co_sym_suggest(gender,s)).reshape(3,1))   
      print (np.array(['a. Enter another symptom','b. If you do not have any other symptom']).reshape(1,2)) 
      ip=raw_input('Please select the one of the co-symptoms suggested or select the relevant option\n\n')
      if (ip=='a'):
        cls_screen()
        ip=raw_input('Please enter your symptoms to be evaluated\n\n')
        temp_q.append(ip) 
        s_temp=sym_anti(gender,ip)
        if (s_temp!='404'):
          cls_screen()
          print (str('Based on the description of your medical problem, I have identified "')+s_temp+str('" as the symptom\n'))
          d=raw_input('Do you want to proceed further (y/n)\n')     
        else:
          s,count,flag=no_match(s,count,flag)
        if ((d=='y') or (d=='Y')):
          f=open('/home/buildadmin/yash/call-health-server/medibot/source/correct.csv')
          f=csv.reader(f)
          data=[]
          for row in f:
            data.append(row[0])
            data.append(row[1])
          data.append(cleaned_query(ip))
          data.append(s_temp)
          data=np.array(data).reshape(int(len(data)/2),2)
          np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/correct.csv',data,delimiter=',',fmt="%s") 
          s,count,flag=correct(s_temp,s,count,flag)
        else:
          f=open('/home/buildadmin/yash/call-health-server/medibot/source/incorrect.csv')
          f=csv.reader(f)
          data=[]
          for row in f:
            data.append(row[0])
            data.append(row[1])
          data.append(cleaned_query(ip))
          data.append(s_temp)
          data=np.array(data).reshape(int(len(data)/2),2)
          np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/incorrect.csv',data,delimiter=',',fmt="%s") 
          s,count,flag=incorrect(s,count,flag) 
      elif (ip=='1'):
        s.append(co_sym_suggest(gender,s)[0])
        temp_q.append(co_sym_suggest(gender,s)[0])
        count=count+1
      elif (ip=='2'):
        s.append(co_sym_suggest(gender,s)[1])
        temp_q.append(co_sym_suggest(gender,s)[1])
        count=count+1
      elif (ip=='3'):
        s.append(co_sym_suggest(gender,s)[2])
        temp_q.append(co_sym_suggest(gender,s)[2]) 
        count=count+1
      else:
        flag=0
        count=5
  np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/inputs_instance.csv',np.array(temp_q),delimiter=',',fmt="%s")
  return (s,flag,count)








def chat_diff_diag(age,gender):
  s,f,c=diff_diag_converse(gender)
  if (f>=3):
    print ('I am sorry that I could not help you..But I am a learning bot and will soon become smarter\n')
    return ('404') 
  if (c>=5):
    symps=[]
    for i in s:
      symps.append(i.upper())
    cls_screen()
    print ('Based on your profile and medical complaints, your are likely to be suffering from:\n')
    print (diff_diag(age,gender.upper(),symps))
    print ('\n\n***Please note that the suggested Diseases/Conditions are just likelihood estimates\n')
    print ('Please consult our specialist to evaluate your medical problems\n')  
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/symps_instance.csv',np.array(symps),delimiter=',',fmt="%s")
    return (diff_diag(age,gender.upper(),symps))




