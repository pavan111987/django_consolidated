import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *


words=stopwords.words('english')



def get_brand_mole_mapping():
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/brand_to_molecule.csv')
  f=csv.reader(f)
  brand_molecule={}
  for i in f:
    temp=[]
    for j in i[1].split('+'):
      temp.append(re.sub('[(]',' ',j))
    brand_molecule[i[0]]=[temp]
  cats=[]
  subcats=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/cat_subcat.csv')
  f=csv.reader(f)
  for i in f:
    subcats.append(i[0])
    cats.append(i[1])
  for i,j in brand_molecule.items():
     flag=0 
     for k in i.split():
       if (k in subcats):
         flag=1
         brand_molecule[i].append([subcats[np.where(k==np.array(subcats))[0][0]]]) 
         break
     if (flag==0):
       brand_molecule[i].append(['others'])
     flag=0
     for k in i.split():
       if (k in cats):
         flag=1
         brand_molecule[i].append([cats[np.where(k==np.array(cats))[0][0]]]) 
         break
     if (flag==0):
       brand_molecule[i].append(['others'])
  return (brand_molecule)



brand_molecule=get_brand_mole_mapping()



def get_brand_mole(q):
  vote=[]
  name=[]
  cat=[]
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      if (len(i)>=3):
        temp.append(i)
  q=(' '.join(temp))
  for i,j in brand_molecule.items():
    count=0
    name.append(i)
    cat.append(j[1])
    for k in q.split():
      if (k==i.split()[0]):
        count=count+1
      try:
        if (k==i.split()[1]):
          count=count+0.5
      except:
        pass 
    vote.append(count)
  if (np.sum(vote)>0):
    v=np.array(vote)[np.where(np.array(vote)>0)]
    c_uniq=np.unique(np.array(cat)[np.where(np.array(vote)>0)])
    c=np.array(cat)[np.where(np.array(vote)>0)]
    n=np.array(name)[np.where(np.array(vote)>0)]
    v=v[np.argsort(v)[::-1]]
    n=n[np.argsort(v)[::-1]]
    c=c[np.argsort(v)[::-1]]
    print (np.array(c_uniq).reshape(len(c_uniq),1))
    ip=raw_input('Please select from the following Dose Form\n')
    n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip)-1]==c)[0]]
    c_selected=np.array(c_uniq)[int(ip)-1]  
    n_final=n_final.reshape(len(n_final),1)
    print (n_final)
    ip=raw_input('Please select from the following brand names\n')
    for i,j in brand_molecule.items():
      if (i==n_final[int(ip)-1]):
        break
    return (n_final[int(ip)-1],j[0],c_selected) 
  else:
    return ('404')






def drugs_clean(q):
  q=q.lower()
  q1=q  
  rx_mole_list=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_rx_mole_master.csv')
  f=csv.reader(f)
  for i in f:
    rx_mole_list.append(i[0])
  drug_master_words=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_master_words.csv')
  f=csv.reader(f)
  for i in f:
    drug_master_words.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i in drug_master_words):
      temp.append(i)
  q=(' '.join(temp))
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      temp.append(i)
  q=(' '.join(temp))
  if (len(temp)>0):
    return (q)
  else:
    temp=[]
    e_dist=[]
    for i in nltk.word_tokenize(q1):
      if (i not in words):
        temp.append(i)
    q1=(' '.join(temp))
    uniq_master=np.unique(drug_master_words)
    temp=[] 
    for i in uniq_master:
      for j in nltk.word_tokenize(q1):
        if ((len(i)>=3) and (len(j)>=3)): 
          d=edit_distance(i,j)
          if (d<=1):
            if (i[0]==j[0]):  
              temp.append(i)
    if (len(temp)>0):
      q=(' '.join(temp))
      return (q)
    else:
      return ('404')



def mole_rx_mole(q):
  rx_mole_list=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_rx_mole_master.csv')
  f=csv.reader(f)
  for i in f:
    rx_mole_list.append(i[0])
  drug_master_words=[]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_master_words.csv')
  f=csv.reader(f)
  for i in f:
    drug_master_words.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i in drug_master_words):
      temp.append(i)
  q=(' '.join(temp))
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      temp.append(i)
  q=(' '.join(temp))
  mole=get_brand_mole(q)  
  c_selected=[mole[2]]
  mole=mole[1]
  vote=[]
  name=[]
  for i in rx_mole_list:
    count=0
    name.append(i) 
    for j in mole:
      for k in nltk.word_tokenize(j):
        if (i==k):
          count=count+1
    vote.append(count)
  if (np.sum(vote)>0):
    n=np.array(name)[np.where(np.max(vote)==np.array(vote))]	
    v=np.array(vote)[np.where(np.max(vote)==np.array(vote))]
    return (n,np.array(c_selected))
  else:
    return ([['404']])



def drugs_info_final(q):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_dis_contra.csv')
  f=csv.reader(f)
  dis_contra={}
  for i in f:
    dis_contra[i[0]]=i[1:]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_moa.csv')
  f=csv.reader(f)
  drug_moa={}
  for i in f:
    drug_moa[i[0]]=i[1:]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_pe_induces.csv')
  f=csv.reader(f)
  drug_pe={}
  for i in f:
    drug_pe[i[0]]=i[1:]
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/drug_uses.csv')
  f=csv.reader(f)
  drug_uses={}
  for i in f:
    drug_uses[i[0]]=[' '.join((', '.join(i[1:]).split('\n')))]
  mole=mole_rx_mole(q)
  if (mole[0][0]!='404'):
    c_selected=mole[1]
    mole=mole[0]
    drug_info=[]
    for i in mole:
      try:
        drug_info.append(drug_uses[i][0])
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(drug_moa[i])))
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(dis_contra[i])))
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(drug_pe[i])))
      except:
        pass
    subs=[]
    for i,j in brand_molecule.items():
      if (set(j[0])==set(mole)):
        if (j[1][0]==c_selected[0]):
          subs.append(i)
    return (np.array(subs)[0:5],np.array(mole),(np.array(drug_info).reshape(len(drug_info),1)))
  else:
    return ('404')



