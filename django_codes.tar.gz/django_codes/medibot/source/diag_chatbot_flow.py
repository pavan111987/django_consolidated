import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *
from symptoms_cosymptoms import *
from dd_functions import *
from weather_and_location import *
from symptom_to_speciality import *
from mayo_articles_code import *
from name_to_gender import *
from drugs_code import *
from diagnostics_code import *
from chatbot_datafiles_code import *
from json_response_code import *
from symptom_checker_flow import *


words=stopwords.words('english')


def diag_bot_flow(mob,sessid,ip,request_type):
  if (str(read_sess_flow_id(sessid))=='input_diag_flow'):
    ip=ip
    sess_input(ip,sessid)
    sess_flow_id('diag_flow_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='diag_flow'):
    text=('Tell me the name of the test you wish to know the details about')
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_diag_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='diag_flow_continue'):
    q=read_sess_input(sessid)
    res=diag_names_match(q)
    if (res[0][0]!='404'):
      names=res[0]
      codes=res[1]
      n=str('YYYYY'.join(list(names)))
      c=str('YYYYY'.join(list(codes)))
      n=str('XXXXX'.join([n,c])) 
      sess_input(n,sessid)
      sess_flow_id('select_diag_name',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      text=('Sorry!! I could not find any diagnostic test relevant to your query..\n')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_select_diag_name'):
      ip=ip[0]
      temp=read_sess_input(sessid)
      ip=('XXXXX'.join([temp,ip]))
      sess_input(ip,sessid)
      sess_flow_id('select_diag_name_continue',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='select_diag_name'):
      ip=read_sess_input(sessid).split('XXXXX')
      names=ip[0].split('YYYYY')
      codes=ip[1].split('YYYYY')
      options=names
      names=np.array(names)
      if (len(options)>1): 
        text='Did you mean:'
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_select_diag_name',sessid)
        return (op_json)
      else:
        ip='1'
        temp=read_sess_input(sessid)
        ip=('XXXXX'.join([temp,ip]))
        sess_input(ip,sessid)
        sess_flow_id('select_diag_name_continue',sessid)
        op_json=blank_response_json(sessid)
        return (op_json)
  if (str(read_sess_flow_id(sessid))=='select_diag_name_continue'):
      ip=read_sess_input(sessid).split('XXXXX')
      names=ip[0].split('YYYYY')
      codes=ip[1].split('YYYYY')
      ip=ip[2]
      names=np.array(names) 
      name=names[int(ip)-1]
      code=codes[int(ip)-1]
      diag_price={}
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_price.csv')
      f=csv.reader(f)
      for i in f:
        diag_price[i[0]]=[i[1],i[2]]
      diag_info={}
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_info.csv')
      f=csv.reader(f)
      for i in f:
        diag_info[i[0]]=[i[1]]
      diag_package={}
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/diagnositic_test_package.csv')
      f=csv.reader(f)
      for i in f:
        diag_package[i[0]]=[i[1:]]
      diag_preq={}
      f=open('/home/buildadmin/yash/call-health-server/medibot/source/lab_instructions.csv')
      f=csv.reader(f)
      for i in f:
        diag_preq[i[0]]=[i[1]]
      packages=[]
      for i,j in diag_package.items():
        if (code in j[0]):
          packages.append(i)
      if (len(packages)<=0):
        if (str(diag_preq[code][0])!=''):
          text='The test '+str(name)+' and has the following purpose \n'+str(diag_info[code][0])+'. Before you take the test '+str(diag_preq[code][0])
        else:
          text='The test '+str(name)+' and has the following purpose \n'+str(diag_info[code][0])
        options=[]
        flow_id='diag_feedback'
        op_json=text_blank_response_json(text.decode('windows-1252').strip(),options,flow_id,sessid)
      else:
        if (str(diag_preq[code][0])!=''):
          text='The test '+str(name)+' and has the following purpose \n'+str(diag_info[code][0])+'. Before you take the test '+str(diag_preq[code][0])+'\nThis test is available in the following packages\n'
        else:
          text='The test '+str(name)+' and has the following purpose \n'+str(diag_info[code][0])+'\nThis test is available in the following packages\n'
        options=packages
        flow_id='diag_feedback'
        op_json=text_blank_response_json(text.decode('windows-1252').strip(),options,flow_id,sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='diag_feedback'):
    text='Does this information help?'
    options=['Yes','No']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_feedback_response',sessid)
    return (op_json)


