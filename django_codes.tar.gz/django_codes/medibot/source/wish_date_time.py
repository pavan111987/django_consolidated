import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random



def read_sess_time(sessid):
  f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/sess_time.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 




def wish(): 
  current_hour = time.strptime(time.ctime(time.time())).tm_hour
  if (current_hour < 12):
    return ("Good Morning!")
  elif (current_hour == 12):
    return ("Good Afternoon!")
  elif (current_hour > 12 and current_hour < 18):
    return ("Good Afternoon!")
  elif (current_hour >= 18):
    return ("Good Evening!")


def wish_on_time(sessid):
  current_hour=datetime.strptime(read_sess_time(sessid), '%Y-%m-%d %H:%M:%S')
  current_hour=current_hour.hour 
  if (current_hour < 12):
    return ("Good Morning")
  elif (current_hour == 12):
    return ("Good Afternoon")
  elif (current_hour > 12 and current_hour < 18):
    return ("Good Afternoon")
  elif (current_hour >= 18):
    return ("Good Evening")



def date_diff(date):
  date_format="%d-%m-%Y"
  d1=datetime.strptime(date,date_format).year
  d2=datetime.now().year
  return (d2-d1)





