import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random
from symptom_anticipation_nlp import *
from symptoms_cosymptoms import *
from dd_functions import *
from weather_and_location import *
from symptom_to_speciality import *
from mayo_articles_code import *
from name_to_gender import *
from drugs_code import *
from diagnostics_code import *
from chatbot_datafiles_code import *
from json_response_code import *
from symptom_checker_flow import *


words=stopwords.words('english')

dis_urls={}
f=open('/home/buildadmin/yash/call-health-server/medibot/source/dis_urls.csv')
f=csv.reader(f)
for i in f:
  dis_urls[i[0]]=str(i[1])



def dd_flow(mob,sessid,ip,request_type):
  if (str(read_sess_flow_id(sessid))=='dd_age'):
    dd_status_log_counter('0',sessid)
    if (read_sess_me_someone(sessid)=='someone'):
      write_sess_age('404',sessid)
      write_sess_gender('404',sessid) 
#    text='To give you the most accurate information, I need to ask a few questions'
#    options=[]
    flow_id='dd_start'
    sess_flow_id(flow_id,sessid) 
#    op_json=text_blank_response_json(text,options,flow_id,sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_age'):
    ip=ip
    ip=re.sub('[^0-9]','',ip)
    if (ip!=''):
      if ((int(ip)>=0) and (int(ip)<=100)):
        write_sess_age(ip,sessid)
        sess_flow_id('dd_gender',sessid)
        write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid)) 
      else:
        sess_flow_id('dd_age_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      sess_flow_id('dd_age_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='continue_dd'):
    if (read_sess_age(sessid)=='404'):
      try:
        text="What is your Age?"
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_dd_age',sessid)
      except:
        op_json=blank_response_json(sessid)
        sess_flow_id('dd_age_wrong',sessid)
    else:
      op_json=blank_response_json(sessid)  
      sess_flow_id('dd_gender',sessid)
    return (op_json)  
  if (str(read_sess_flow_id(sessid))=='dd_age_wrong'):
    text='Sorry! I could not understand. Please try again'
    options=[]
    flow_id='continue_dd'
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='input_dd_gender'):
    ip=ip[0]
    if (ip=='1'): 
      write_sess_gender('m',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid)) 
    else:
      write_sess_gender('f',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
    sess_flow_id('dd_me',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_gender_male_guess'):
    ip=ip[0]
    if (ip=='1'):
      write_sess_gender('m',sessid)
      sess_flow_id('dd_me',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
    else:
      sess_input('f',sessid)
      sess_flow_id('gender_wrong',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))     
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_gender_female_guess'):
    ip=ip[0]
    if (ip=='1'):
      write_sess_gender('f',sessid)
      sess_flow_id('dd_me',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
    else:
      sess_input('m',sessid)
      sess_flow_id('gender_wrong',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))     
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_gender'):
    if (read_sess_gender(sessid)=='404'):
      g=name_gender(read_sess_name(sessid))
      if (g[0]=='404'):
        options=['Male','Female']
        text='And your gender?'
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_dd_gender',sessid)
        return (op_json) 
      elif (g[0]=='m'):
        text="'"+str(read_sess_name(sessid)).capitalize()+"' seems a male name. Am I right?"
        options=['Yes','No']
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_gender_male_guess',sessid)
        return (op_json)
      elif (g[0]=='f'):
        text="'"+str(read_sess_name(sessid)).capitalize()+"' seems a female name. Am I right?"
        options=['Yes','No']
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_gender_female_guess',sessid)
        return (op_json)
    else:
      sess_flow_id('dd_me',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='gender_wrong'):
    text='Oops! :('
    write_sess_gender(read_sess_input(sessid),sessid)
    write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid)) 
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/indian_names.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1]
    data[read_sess_name(sessid)]=read_sess_input(sessid)        
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      new_data.append(j)
    new_data=np.array(new_data).reshape((len(new_data)/2),2)
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/indian_names.csv',new_data,delimiter=',',fmt="%s")
    flow_id='dd_me'
    options=[]
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_start'):
    ip=ip[0]
    if (ip=='1'):
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
      write_sess_me_someone('me',sessid)
      sess_flow_id('continue_dd',sessid)
    if (ip=='2'):
      sess_flow_id('dd_someone_else_gender',sessid)
      write_sess_me_someone('someone',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_start'):
    dd_status_log_counter('0',sessid)
    if (read_sess_name(sessid)!=''):
      text='Ok '+str(nltk.word_tokenize(read_sess_name(sessid))[0])+', before we proceed let me know who is this symptom check for?'
    else:
      text='First, Who is this symptom check for?'
    options=['Me','Someone else']
    sess_flow_id('input_dd_start',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_someone_else'):
    ip=ip
    ip=re.sub('[^0-9]','',ip)
    if (ip!=''):
      if ((int(ip)>=0) and (int(ip)<=100)):
        write_sess_age(ip,sessid)
        sess_flow_id('dd_me',sessid)
      else:
        sess_flow_id('someone_dd_age_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      sess_flow_id('someone_dd_age_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='someone_dd_age_wrong'):
    text='I did not understand. Please try again'
    flow_id='dd_someone_else'
    options=[]
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='dd_someone_else'):
    text='How old is that person?'
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_dd_someone_else',sessid)
    return (op_json)    
  if (str(read_sess_flow_id(sessid))=='input_dd_someone_else_gender'):
    ip=ip
    g=name_gender(ip)
    if (g[0]=='m'):
      text="'"+str(ip).capitalize()+"' seems a male name. Am I right?"
      options=['Yes','No']
      sess_input(g[0],sessid)
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('someone_gender_check',sessid)
      return (op_json)
    elif (g[0]=='f'):
      text="'"+str(ip).capitalize()+"' seems a female name. Am I right?"
      options=['Yes','No']
      sess_input(g[0],sessid)
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('someone_gender_check',sessid)
      return (op_json)
    else:
      options=['Male','Female']
      text='And the gender?'
      sess_input('after_gender_options',sessid)
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('someone_gender_check',sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='someone_gender_check'):
    if (read_sess_input(sessid)=='after_gender_options'):
      ip=ip[0]
      res=['m','f']
      write_sess_gender(res[int(ip)-1],sessid)
      sess_flow_id('dd_someone_else',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      ip=ip[0]
      if (str(ip)=='1'):
        write_sess_gender(read_sess_input(sessid),sessid)
        sess_flow_id('dd_someone_else',sessid)
        op_json=blank_response_json(sessid)
        return (op_json)
      else:
        if (read_sess_input(sessid)=='m'):
          write_sess_gender('f',sessid)
        else:
          write_sess_gender('m',sessid)
        text='Oops! :('
        options=[]
        flow_id='dd_someone_else'
        op_json=text_blank_response_json(text,options,flow_id,sessid)
        return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_someone_else_gender'):
    text="What is the person's name?"
    op_json=text_response_json(text,sessid)
#    options=['Male','Female']
#    text='And gender?'
#    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_dd_someone_else_gender',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_sym_anti'):
      ip=ip
      sess_input(ip,sessid)
      sess_flow_id('sym_anti',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_me'):
   if (read_sess_input(sessid)!='less_than_two_check'):
    data={}
    f=open('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv')
    f=csv.reader(f)
    for i in f:
      if (str(i[0])==str(sessid)): 
        data[i[0]]=''
      else:
        data[i[0]]=i[1]
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      new_data.append(j)
    new_data=np.array(new_data).reshape((len(new_data)/2),2)
    np.savetxt('/home/buildadmin/yash/call-health-server/medibot/source/log/symps_log.csv',new_data,delimiter=',',fmt="%s")
    dd_status_log_counter('0',sessid)    
    if (read_dd_status_log_counter(sessid)==None):
      dd_status_log_counter('0',sessid)
    if ((int(read_dd_status_log_counter(sessid)[0])<4) and (int(read_dd_status_log_counter(sessid)[1])<=3)):
      if ((int(read_dd_status_log_counter(sessid)[0])+int(read_dd_status_log_counter(sessid)[1]))>0):
        if (str(read_sess_me_someone(sessid))=='me'):
          text=str('Please describe your symptoms')
        else:
          text=str('Please describe their symptoms')
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_sym_anti',sessid)
        return (op_json)
      else:
        if (str(read_sess_me_someone(sessid))=='me'):
          text=str('Lets get started tell me about the symptoms you have today?')
        else:
          text='Thanks! :) we are set. What are symptoms?'
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_sym_anti',sessid)
        return (op_json)
    elif (int(read_dd_status_log_counter(sessid)[1])>=3):
      text='Sorry! I could not understand you'
      options=[]
      flow_id='dd_end' 
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
   else:
    if ((int(read_dd_status_log_counter(sessid)[0])<4) and (int(read_dd_status_log_counter(sessid)[1])<=3)):
      if ((int(read_dd_status_log_counter(sessid)[0])+int(read_dd_status_log_counter(sessid)[1]))>0):
        if (str(read_sess_me_someone(sessid))=='me'):
          text=str('Please describe your symptoms')
        else:
          text=str('Please describe their symptoms')  
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_sym_anti',sessid)
        return (op_json)
      else:
        if (str(read_sess_me_someone(sessid))=='me'):   
          text=str('Lets get started tell me about the symptoms you have today?')
        else:
          text='Thanks! :) we are set. What are symptoms?' 
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_sym_anti',sessid)
        return (op_json)
    elif (int(read_dd_status_log_counter(sessid)[1])>=3):
      text='Sorry! I could not understand you'
      options=[]
      flow_id='dd_end' 
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='sym_anti'):
    ip=read_sess_input(sessid)
    flag=0
    s_temp=sym_anti(read_sess_gender(sessid),ip) 
    sym_list=[]
    for i,j in sym_crawl.items():
      sym_list.append(i.lower()) 
      if (str(i.lower())==str(ip.lower())):
        flag=1
        break
    if (flag==1 and str(s_temp)!='404'):
      s_temp=sym_anti(read_sess_gender(sessid),ip)
      #s_temp=read_sess_input(sessid)
      sess_input(s_temp,sessid)
      write_symps_log(s_temp.upper(),sessid)
      sess_input(s_temp,sessid) 
      sess_flow_id('next_sym',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    elif (flag==0 and str(s_temp)!='404'):
      s_temp=sym_anti(read_sess_gender(sessid),ip) 
      #s_temp=read_sess_input(sessid)
      write_symps_log(s_temp.upper(),sessid)
      sess_input(s_temp,sessid)
      sess_flow_id('sym_correct_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      text='Sorry! I could not understand you'
      dd_status_log_counter('n',sessid)
      flow_id='dd_me'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_sym_correct_wrong'):
    ip=ip[0]
    res=['y','n'] 
    if (ip=='1'):
      s_temp=read_sess_input(sessid)
      write_symps_log(s_temp.upper(),sessid)
      sess_flow_id('next_sym',sessid)	
    else:
      sess_flow_id('dd_me',sessid)
    dd_status_log_counter(res[int(ip)-1],sessid)
    op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='sym_correct_wrong'):
    if ((int(read_dd_status_log_counter(sessid)[0])<4) or (int(read_dd_status_log_counter(sessid)[1])<=3)):
        s_temp=read_sess_input(sessid)
        text=str('Did you mean ')+str(s_temp).title()+str('?')
        options=['Yes','No']
        sess_input(s_temp,sessid) 
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_sym_correct_wrong',sessid)
        return (op_json)
    elif ((int(read_dd_status_log_counter(sessid)[0])==3)):
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    elif (int(read_dd_status_log_counter(sessid)[1])==3):
      text='My apologies! I could not understand you'
      flow_id='dd_end'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
    else:
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_next_sym'):
    res=[]
    temp=read_symps_log(sessid)
    s=[]
    for i in temp:
      s.append(i.lower())
    for i in co_sym_suggest(read_sess_gender(sessid),s):
      res.append(i.capitalize())    
    res.append('Other symptom')
    res.append('No other symptom')
    ip=ip[0]
    sess_input(ip,sessid)      
    sess_flow_id('dd_decision',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)  
  if (str(read_sess_flow_id(sessid))=='next_sym'):
    res=[]
    temp=read_symps_log(sessid)
    s=[]
    for i in temp:
      s.append(i.lower())
    for i in co_sym_suggest(read_sess_gender(sessid),s):
      res.append(i.capitalize())    
    res.append('None of these')
    res.append('No other symptom')
    options=res
    if (len(s)==1):
      text='Ok '+str(s[-1])+'. Any other symptoms?'
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('input_next_sym',sessid)
      return (op_json)
    elif (len(s)==2):
      if (str(read_sess_me_someone(sessid))=='me'):   
        text='Do you have any of these symptoms?'
      else:
        text='What are the symptoms?'  
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('input_next_sym',sessid)
      return (op_json)
    else:
      if (str(read_sess_me_someone(sessid))=='me'):
        text='How long you had these symptoms?'
      else:
        text='How long they had these symptoms?'
      options=['Few Hours','Few Days','Few Weeks','None Of These'] 
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('last_sym_input',sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='last_sym_input'):
      ip=ip
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='input_other_symptom'):
    ip=ip
    sess_input(ip,sessid)
    sess_flow_id('sym_anti',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_decision'):
    res=[]
    ip=read_sess_input(sessid)
    temp=read_symps_log(sessid)    
    s=[]
    for i in temp:
      s.append(i.lower())
    if (len(s)>=3):
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
    for i in co_sym_suggest(read_sess_gender(sessid),s):
      res.append(i.capitalize())    
    res.append('Other symptom')
    res.append('No other symptom')
    choice=res[int(ip)-1]
    if (choice=='Other symptom'):
      if (str(read_sess_me_someone(sessid))=='me'):
        text='Please describe your symptoms'
      else:
        text="Please describe the person's symptoms"
      op_json=text_response_json(text,sessid)
      sess_flow_id('input_other_symptom',sessid)
      return (op_json)   
    elif (choice=='No other symptom'):
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
    else:
      write_symps_log(choice.upper(),sessid)
      sess_flow_id('next_sym',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='less_than_two_symps'):
    ip=ip[0]
    if (ip=='1'):
      sess_flow_id('dd_me',sessid)
      op_json=blank_response_json(sessid)
      sess_input('less_than_two_check',sessid) 
      return (op_json)
    else:
      text='Do you want to readup on the possible conditions/symptoms?'
      options=['Yes','No']
      sess_flow_id('dd_yes_no',sessid)
      op_json=text_ss_response_json(text,options,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_yes_no'):
     ip=ip[0]
     if (ip=='1'):    
      s=read_symps_log(sessid)
      s=np.unique(s)
      symps=[]
      for i in s:
        symps.append(i.upper())
      d=diff_diag(int(read_sess_age(sessid)),read_sess_gender(sessid).upper(),symps)
      options=[]
      #for i in d:
      #  options.append(i[0].title())
      dis=[]
      urls=[]
      for i,j in dis_urls.items():
        dis.append(i)
        urls.append(j)
      for i in d:
         options.append([urls[np.where(np.array(dis)==i[0])[0][0]],'url'])
      s=' '.join(read_symps_log(sessid)).lower()
      if (len(mayo_articles_url((s).lower()))!=0):
        if ((mayo_articles_url((s).lower())[0]!='404')):
          g=read_sess_gender(sessid)
          a=read_sess_age(sessid)
          if (g=='m'):
            if (len(mayo_articles_url((s).lower()))>0):    
              for i in (mayo_articles_url((s).lower())):
                if ((i.split('/')[4]!='womens-health') and (i.split('/')[4]!='pregnancy')):
                  options.append([i,'url'])
            else:
              for i in (mayo_articles_url((s).lower())):
                  options.append([i,'url'])
      #temp=[]
      #if (len(options)>7):
      #  for i in np.arange(7):
      #    temp.append(options[i,0])
      #  options=temp
#      s=(' '.join(np.unique(read_symps_log(sessid))))
#      s=s.lower()
#      sess_input(s,sessid)
#      if (str(read_sess_me_someone(sessid))=='me'):
#        text='Based on your symptoms, you are likely to be diagnosed with:'
#      else:
#        text='Based on the symptoms, the likely diagnosis are:' 
      text='Here is what I found..'
#      flow_id='sym_to_speciality'
      flow_id='sym_to_speciality'
      sess_flow_id(flow_id,sessid)
      op_json=url_list_response_json(text,options,sessid)
      #op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
     else:
      flow_id='sym_to_speciality_continue'
      sess_flow_id(flow_id,sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='get_dd'):
    s=read_symps_log(sessid)
    s=np.unique(s)
    symps=[]
    for i in s:
      symps.append(i.upper())
    if (len(symps)<2):
      sess_flow_id('less_than_two_symps',sessid)
      text='Too few symptoms given, to give an accurate diagnosis. Enter more symptoms?'
      options=['Yes','No']
      op_json=text_ss_response_json(text,options,sessid)
      return (op_json)
    text='Do you want to readup on the possible conditions/symptoms?'
    options=['Yes','No']
    sess_flow_id('dd_yes_no_proper',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_yes_no_proper'):
    ip=ip[0]
    if (ip=='1'):
      s=read_symps_log(sessid)
      s=np.unique(s)
      symps=[]
      for i in s:
        symps.append(i.upper())
      d=diff_diag(int(read_sess_age(sessid)),read_sess_gender(sessid).upper(),symps)
#    options=[]
#    for i in d:
#      options.append(str(i[0]).title())
      options=[]
      dis=[]
      urls=[]
      for i,j in dis_urls.items():
        dis.append(i)
        urls.append(j)
      for i in d:
        options.append([str(urls[np.where(np.array(dis)==i[0])[0][0]]),'url'])
      s=(' '.join(np.unique(read_symps_log(sessid))))
      s=s.lower()
      sess_input(s,sessid)
#      if (str(read_sess_me_someone(sessid))=='me'):
#        text='Based on your symptoms, you are likely to be diagnosed with:'
#      else:
#        text='Based on the symptoms, the likely to be diagnosed with:'
      text='Here is what I found..'
      flow_id='sym_to_speciality_continue'
      sess_flow_id(flow_id,sessid)
#      #op_json=text_blank_response_json(text,options,flow_id,sessid)
      op_json=url_list_response_json(text,options,sessid)
      return (op_json)
    else:
      sess_flow_id('sym_to_speciality_continue',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='sym_to_speciality'):
#    s=read_sess_input(sessid)
#    if (sym_speciality(int(read_sess_age(sessid)),read_sess_gender(sessid),s)[0]!='404'):
#      text=('Based on your condition I recommend you consult '+sym_speciality(int(read_sess_age(sessid)),read_sess_gender(sessid),(s))+'\nYou can call us on 33557799\n')
#      text='** Please note that the above conditions are likely but not conclusive'
#      options=[]
#      flow_id='sym_to_speciality_continue'
#      op_json=text_blank_response_json(text,options,flow_id,sessid)
#      return (op_json)
    sess_flow_id('sym_to_speciality_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)   
  if (str(read_sess_flow_id(sessid))=='sym_to_speciality_continue'):
      text=('Please call 33557799 to schedule a consultation with our specialists') 
      options=[]
      flow_id='dd_end' 
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
#    else:
#      op_json=blank_response_json(sessid)
#      sess_flow_id('sym_to_mayo',sessid)
#      sess_input(s,sessid)
#      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='sym_to_mayo_message'):
    if (str(read_sess_me_someone(sessid))=='me'):
      text='Do you want to read up more about your symptoms?'
    else:
      text='Do you want to read up more about the symptoms?' 
    options=['Yes','No']
    sess_flow_id('sym_to_mayo',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='sym_to_mayo'):
    ip=ip[0]
    if (str(ip)=='1'):
      s=' '.join(read_symps_log(sessid)).lower()
      if (len(mayo_articles_url((s).lower()))!=0):
        if ((mayo_articles_url((s).lower())[0]!='404')):
          text = ('Here is what I found..')
          u=[]
          g=read_sess_gender(sessid)
          a=read_sess_age(sessid)
          options=[]
          if (g=='m'):
            if (len(mayo_articles_url((s).lower()))>0):    
              for i in (mayo_articles_url((s).lower())):
                if ((i.split('/')[4]!='womens-health') and (i.split('/')[4]!='pregnancy')):
                  u.append([i,'url'])
            else:
              for i in (mayo_articles_url((s).lower())):
                  u.append([i,'url'])
#          if (int(a)>14):
#            if (len(u)>0):
#              for i in u:
#                if ((i.split('/')[4]!='childrens-health')):
#                  options.append([i,'url'])
#          if (len(u)>8):
#            u=u[np.arange(8)] 
#            options=u
          options=u
          if (len(u)>0):   
            op_json=url_list_response_json(text,options,sessid)
            sess_flow_id('dd_end',sessid)
            return (op_json)
          else:
            text='Sorry! I could not find any articles related to your symptoms'
            options=[]
            flow_id='dd_end' 
            op_json=text_blank_response_json(text,options,flow_id,sessid)
            return (op_json) 
        else:
          op_json=blank_response_json(sessid)
          sess_flow_id('dd_end',sessid)
          return (op_json) 
      else:
        op_json=blank_response_json(sessid)
        sess_flow_id('dd_end',sessid)
        return (op_json)
    else:
      op_json=blank_response_json(sessid)
      sess_flow_id('dd_end',sessid)
      return (op_json) 



