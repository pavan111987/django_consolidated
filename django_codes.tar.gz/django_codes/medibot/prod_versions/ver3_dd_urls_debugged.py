import numpy as np
import csv
from scipy.spatial.distance import cosine as dist
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk import pos_tag
import json
import os
import re
import urllib, json
import pyowm
import urllib2
import json
import time
import numpy as np
from datetime import datetime
from itertools import groupby
import json
import smtplib
import random


words=stopwords.words('english')

f=open('/home/pavankumar/call-health-server/medibot/source/symptoms filter.csv')
f=csv.reader(f)
sym_male=[]
sym_female=[]
for i in f:
  if (i[1]=='Yes'):
    sym_male.append(i[0])
  if (i[2]=='Yes'):
    sym_female.append(i[0])



f=open('/home/pavankumar/call-health-server/medibot/source/all_mdp_symp_crawl.csv')
f=csv.reader(f)

sym_crawl={}
sym_list_final=[]
for i in f:
  sym_crawl[i[0]]=[re.sub(' +',' ',re.sub('[0-9]','',i[1])).lower()]  
  sym_list_final.append(i[0].lower())



sym_mdp_map={}
f=open('/home/pavankumar/call-health-server/medibot/source/matching syn sym.csv')
f=csv.reader(f)
for i in f:
  key=i[0]
  t=[]
  for j in i[1:]:
    if (j!=''):
      t.append(j)
  value=t
  sym_mdp_map[key]=value




def wish(): 
  current_hour = time.strptime(time.ctime(time.time())).tm_hour
  if (current_hour < 12):
    return ("Good Morning!")
  elif (current_hour == 12):
    return ("Good Afternoon!")
  elif (current_hour > 12 and current_hour < 18):
    return ("Good Afternoon!")
  elif (current_hour >= 18):
    return ("Good Evening!")


def wish_on_time(sessid):
  current_hour=datetime.strptime(read_sess_time(sessid), '%Y-%m-%d %H:%M:%S')
  current_hour=current_hour.hour 
  if (current_hour < 12):
    return ("Good Morning")
  elif (current_hour == 12):
    return ("Good Afternoon")
  elif (current_hour > 12 and current_hour < 18):
    return ("Good Afternoon")
  elif (current_hour >= 18):
    return ("Good Evening")



def date_diff(date):
  date_format="%d-%m-%Y"
  d1=datetime.strptime(date,date_format).year
  d2=datetime.now().year
  return (d2-d1)




def cleaned_query(q):
  stop_words=stopwords.words('english')
  q_clean=[]
  for i in q.split():
    if (i not in stop_words):
      if (i not in q_clean):
        q_clean.append(i)
  return (' '.join(q_clean))



def exact_match(gender,q):
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=0
      if (i.upper() in sym_male):
        if (cleaned_query(q)==i):
          t=t+1
      sym_list[i]=t
  else:
    for i,j in sym_crawl.items():
      t=0
      if (i.upper() in sym_female):
        if (cleaned_query(q)==i):
          t=t+1
      sym_list[i]=t
  return (sym_list)



def part_match1(q):
  sym_list={}
  nouns=[]
  adj=[]
  vbz=[]
  for i in nltk.pos_tag(cleaned_query(q).split()):
    if ('NN' in i[1]):
      nouns.append(i[0])
    if ('JJ' in i[1]):
      adj.append(i[0])
    if ('VB' in i[1]):
      vbz.append(i[0])
  flag=0
  for i,j in sym_crawl.items():
    if (q in j[0]):
      flag=1      
  if (flag==0):
    sent1=[]
    for i in q.lower().split():
      if (i not in words):
        sent1.append(i)
        nouns=[]
        adj=[]
        verbs=[]
        for i in pos_tag(sent1):
          if ('NN' in i[1]):
            nouns.append(i[0])
          elif ('JJ' in i[1]):
            adj.append(i[0])
          elif ('VB' in i[1]):
            vbz.append(i[0])
          else:
            pass
    vote=np.zeros(len(sym_list_final),)
    for i,j in sym_crawl.items():
      for k in nouns:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(10*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]]) 
      for k in adj:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(1*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]]) 
      for k in vbz:
        vote[np.where(i==np.array(sym_list_final))[0][0]]=(1*(len(j[0].split(k))-1)+vote[np.where(i==np.array(sym_list_final))[0][0]])  
    if (np.sum(vote)>0):
      for i in np.arange(len(sym_list_final)):
        sym_list[sym_list_final[i]]=vote[i]
    else:
      print ('Sorry I did not understand your query')
  else:
    vote=np.zeros(len(sym_list_final),)
    for i,j in sym_crawl.items():
      vote[np.where(i==np.array(sym_list_final))[0][0]]=len(j[0].split(q))-1
  for i in np.arange(len(sym_list_final)):
    sym_list[sym_list_final[i]]=vote[i]
  return (sym_list)



def phrase_match(gender,q):  
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=0
      if (cleaned_query(q) in j[0]):
        if (i.upper() in sym_male): 
          t=t+1 
      sym_list[i]=t
  else:
    for i,j in sym_crawl.items():
      t=0
      if (cleaned_query(q) in j[0]):
        if (i.upper() in sym_female): 
          t=t+1 
      sym_list[i]=t
  return (sym_list)



def syn_phrase_match(gender,q):
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_mdp_map.items():
      t=0
      if (cleaned_query(q) in j):
        if (i.upper() in sym_male):
          t=t+1
      for k in j:
        if (k in cleaned_query(q)):
          if (i.upper() in sym_male):
            t=t+1
      sym_list[i]=t
  if (gender=='f' or gender=='F'):
    for i,j in sym_mdp_map.items():
      t=0
      if (cleaned_query(q) in j):
        if (i.upper() in sym_female):
          t=t+1
      for k in j:
        if (k in cleaned_query(q)):
          if (i.upper() in sym_female):
            t=t+1
      sym_list[i]=t
  return (sym_list)




def syn_match(gender,q):
  q=cleaned_query(q).lower() 
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_mdp_map.items():
        t=0
        if (i.upper() in sym_male): 
          for k in j:
            if (k==q):
              t=t+50
            if ((k in q) or (q in k)):
              t=t+len(list(set(nltk.word_tokenize(cleaned_query(q))).intersection(nltk.word_tokenize(k))))
        sym_list[i]=t
  else:
    for i,j in sym_mdp_map.items():
        t=0
        for k in j:
          if (k==q):
            t=t+50
          if ((k in q) or (q in k)):
            t=t+len(list(set(nltk.word_tokenize(cleaned_query(q))).intersection(nltk.word_tokenize(k))))
        sym_list[i]=t
  return (sym_list)


embeddings_index = {}
f = open('/home/pavankumar/call-health-server/medibot/source/glove.6B.300d.txt')
for line in f:
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    embeddings_index[word] = coefs


f.close()   



pubmed_index={}
f = open('/home/pavankumar/call-health-server/medibot/source/pubmet categories.csv')
f=csv.reader(f)
for i in f:
  pubmed_index[i[0]]=i[1:3]



def part_match(gender,q):
  q=cleaned_query(q).lower()
  sym_list={}
  if (gender=='m' or gender=='M'):
    for i,j in sym_crawl.items():
      t=[]
      for k in re.sub('[^a-zA-Z  ]','',i.lower()).split():
        for l in cleaned_query(q).split():
          try:
            if (i.upper() in sym_male):
              t.append((1-dist(embeddings_index[k],embeddings_index[l])))
          except:
            t.append(0)
      if (len(t)>0): 
        sym_list[i]=np.mean(t)
      else:
        sym_list[i]=0
  else:
    for i,j in sym_crawl.items():
      t=[]
      for k in re.sub('[^a-zA-Z  ]','',i.lower()).split():
        for l in cleaned_query(q).split():
          try:
            if (i.upper() in sym_female):
              t.append((1-dist(embeddings_index[k],embeddings_index[l])))
          except:
            t.append(0)
      if (len(t)>0): 
        sym_list[i]=np.mean(t)
      else:
        sym_list[i]=0
  return (sym_list)  




def wn_match(q):
  sym_list={}
  for i,j in sym_crawl.items():
    list=[]
    for word1 in re.sub('[^a-zA-Z  ]','',i).split():
      for word2 in re.sub('[^a-zA-Z  ]','',cleaned_query(q)).split():
        wordFromList1 = wordnet.synsets(word1)
        wordFromList2 = wordnet.synsets(word2)
        if wordFromList1 and wordFromList2: 
          s = wordFromList1[0].wup_similarity(wordFromList2[0])
          list.append(s)
    sym_list[i]=np.max(list)
  return (sym_list)



##############################################################################


def sym_anti(gender,q):
  sym_list_scores0=np.zeros((len(sym_list_final),))
  for key,value in exact_match(gender,q).items():
    sym_list_scores0[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores0)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores0)])
  sym_list_scores1=np.zeros((len(sym_list_final),))
  for key,value in syn_match(gender,q).items():
    sym_list_scores1[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores1)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores1)])
  sym_list_scores4=np.zeros((len(sym_list_final),))
  for key,value in part_match(gender,q).items():
    sym_list_scores4[np.where(key==np.array(sym_list_final))[0][0]]=value
  if (np.sum(sym_list_scores4)>0):
    return (np.array(sym_list_final)[np.argmax(sym_list_scores4)])
  else:
    return ('404') 






f=open('/home/pavankumar/call-health-server/medibot/source/medical bayes test.csv')
f=csv.reader(f)
dis=[]
sym=[]
for i in f:
  dis.append(i[0].lower())
  sym.append(i[2].lower())



dis=dis[1:]
sym=sym[1:]
dis_final=np.unique(dis)
sym_final=np.unique(sym)


  
#################################################################################

def gen_co_sym():
  f=open('/home/pavankumar/call-health-server/medibot/source/medical bayes test.csv')
  f=csv.reader(f)
  dis=[]
  sym=[]
  for i in f:
    dis.append(i[0].lower())
    sym.append(i[2].lower())
  dis=dis[1:]
  sym=sym[1:]
  dis_final=np.unique(dis)
  sym_final=np.unique(sym)
  co=np.zeros((len(sym_final),len(sym_final)))
  for k in dis_final:
    for i in np.array(sym)[k==np.array(dis)]:
      for j in np.array(sym)[k==np.array(dis)]:
        co[np.where(i==sym_final)[0][0],np.where(j==sym_final)[0][0]]=co[np.where(i==sym_final)[0][0],np.where(j==sym_final)[0][0]]+1
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/co.csv',co,delimiter=',',fmt="%d")




f=open('/home/pavankumar/call-health-server/medibot/source/medical bayes test.csv')
f=csv.reader(f)
dis=[]
sym=[]
for i in f:
  dis.append(i[0].lower())
  sym.append(i[2].lower())



dis=dis[1:]
sym=sym[1:]
dis_final=np.unique(dis)
sym_final=np.unique(sym)

co=[]
f=open('/home/pavankumar/call-health-server/medibot/source/co.csv')
f=csv.reader(f)
for i in f:
  for j in i:
    co.append(float(j))


co=np.array(co).reshape(len(sym_final),len(sym_final))



#s=['fever','headache','sore throat']
def co_sym_suggest(gender,s):
  if (gender=='m' or gender=='M'):
    temp=np.zeros((len(sym_final),))
    for i in s:
      if (i.upper() in sym_male): 
        temp=temp+co[np.where(i==sym_final)[0][0]]
    co_sym=[]
    for i in np.array(sym_final)[np.argsort(temp)[::-1][0:20]]:
      if (i not in s):
        if (i.upper() in sym_male): 
          co_sym.append(i)
  else:
    temp=np.zeros((len(sym_final),))
    for i in s:
      if (i.upper() in sym_female): 
        temp=temp+co[np.where(i==sym_final)[0][0]]
    co_sym=[]
    for i in np.array(sym_final)[np.argsort(temp)[::-1][0:20]]:
      if (i not in s):
        if (i.upper() in sym_female):
          co_sym.append(i)
  return (co_sym[0:3])



def diff_diag(age,gender,symps):
  object={}
  object['age']=age
  object['gender']=gender
  object['symptoms']=symps
  object['Medical History']=['NONE']
  object['Clinical Finding']=['NONE']
  ip_json=json.dumps(object)
  ip_json=str(ip_json)
  enc_ip_json=str('XXX'.join(ip_json.split('"')))
  command=str('Rscript /home/pavankumar/call-health-server/medibot/source/dd/diff_diag.R "'+enc_ip_json+'"')
  os.system(command)
  f=open('/home/pavankumar/call-health-server/medibot/source/dd result.txt')
  lines = f.readlines()  
  f.close()
  op=json.loads(''.join(lines))
  dd=[]
  for i in np.arange(5):
    if (op[str(i+1)]['Score']>0):
      dd.append(str(op[str(i+1)]['Disease']))
      dd.append(str(round(op[str(i+1)]['Score']))) 
  dd=np.array(dd).reshape(int(len(dd)/2),2)
  return (dd)



def cls_screen():
  os.system('cls')




def correct(s_new,sym,c,f):   
  sym.append(s_new)
  c=c+1 
  return (sym,c,f)


def incorrect(sym,c,f):
  print ('I am sorry, I could not understand you. Please reword/rephrase your medical problem\n\n')
  f=f+1
  return (sym,c,f)


def no_match(sym,c,f):
  print ('I am sorry, I could not understand you. Please reword/rephrase your medical problem\n\n')
  f=f+1
  return (sym,c,f)
     

s=[]
count=0
flag=0

def symps_input():
  ip=raw_input('Please be very specific in your description\nI need to know some symptoms, like cold, fever etc. The more precise you are, the more relevant diagnosis I will be able to do \n\n')
  return (ip)




def diff_diag_converse(gender):
  s=[]
  flag=0
  count=0
  temp_q=[] 
  while ((flag<=3) and (count<5)):
    if (count==0):
      cls_screen()  
      ip=symps_input()
      temp_q.append(ip)
      s_temp=sym_anti(gender,ip)
      if (s_temp!='404'):
        print (str('Based on the description of your medical problem, I have identified "')+s_temp+str('" as the symptom\n'))
        d=raw_input('Do you want to proceed further (y/n)\n')     
      else:
        s,count,flag=no_match(s,count,flag)
      if ((d=='y') or (d=='Y')):
        f=open('/home/pavankumar/call-health-server/medibot/source/correct.csv')
        f=csv.reader(f)
        data=[]
        for row in f:
          data.append(row[0])
          data.append(row[1])
        data.append(cleaned_query(ip))
        data.append(s_temp)
        data=np.array(data).reshape(int(len(data)/2),2)
        np.savetxt('/home/pavankumar/call-health-server/medibot/source/correct.csv',data,delimiter=',',fmt="%s") 
        s,count,flag=correct(s_temp,s,count,flag) 
      else:
        f=open('/home/pavankumar/call-health-server/medibot/source/incorrect.csv')
        f=csv.reader(f)
        data=[]
        for row in f:
          data.append(row[0])
          data.append(row[1])
        data.append(cleaned_query(ip))
        data.append(s_temp)
        data=np.array(data).reshape(int(len(data)/2),2)
        np.savetxt('/home/pavankumar/call-health-server/medibot/source/incorrect.csv',data,delimiter=',',fmt="%s") 
        s,count,flag=incorrect(s,count,flag)
    else:
      cls_screen()
      print (np.array(co_sym_suggest(gender,s)).reshape(3,1))   
      print (np.array(['a. Enter another symptom','b. If you do not have any other symptom']).reshape(1,2)) 
      ip=raw_input('Please select the one of the co-symptoms suggested or select the relevant option\n\n')
      if (ip=='a'):
        cls_screen()
        ip=raw_input('Please enter your symptoms to be evaluated\n\n')
        temp_q.append(ip) 
        s_temp=sym_anti(gender,ip)
        if (s_temp!='404'):
          cls_screen()
          print (str('Based on the description of your medical problem, I have identified "')+s_temp+str('" as the symptom\n'))
          d=raw_input('Do you want to proceed further (y/n)\n')     
        else:
          s,count,flag=no_match(s,count,flag)
        if ((d=='y') or (d=='Y')):
          f=open('/home/pavankumar/call-health-server/medibot/source/correct.csv')
          f=csv.reader(f)
          data=[]
          for row in f:
            data.append(row[0])
            data.append(row[1])
          data.append(cleaned_query(ip))
          data.append(s_temp)
          data=np.array(data).reshape(int(len(data)/2),2)
          np.savetxt('/home/pavankumar/call-health-server/medibot/source/correct.csv',data,delimiter=',',fmt="%s") 
          s,count,flag=correct(s_temp,s,count,flag)
        else:
          f=open('/home/pavankumar/call-health-server/medibot/source/incorrect.csv')
          f=csv.reader(f)
          data=[]
          for row in f:
            data.append(row[0])
            data.append(row[1])
          data.append(cleaned_query(ip))
          data.append(s_temp)
          data=np.array(data).reshape(int(len(data)/2),2)
          np.savetxt('/home/pavankumar/call-health-server/medibot/source/incorrect.csv',data,delimiter=',',fmt="%s") 
          s,count,flag=incorrect(s,count,flag) 
      elif (ip=='1'):
        s.append(co_sym_suggest(gender,s)[0])
        temp_q.append(co_sym_suggest(gender,s)[0])
        count=count+1
      elif (ip=='2'):
        s.append(co_sym_suggest(gender,s)[1])
        temp_q.append(co_sym_suggest(gender,s)[1])
        count=count+1
      elif (ip=='3'):
        s.append(co_sym_suggest(gender,s)[2])
        temp_q.append(co_sym_suggest(gender,s)[2]) 
        count=count+1
      else:
        flag=0
        count=5
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/inputs_instance.csv',np.array(temp_q),delimiter=',',fmt="%s")
  return (s,flag,count)



def chat_diff_diag(age,gender):
  s,f,c=diff_diag_converse(gender)
  if (f>=3):
    print ('I am sorry that I could not help you..But I am a learning bot and will soon become smarter\n')
    return ('404') 
  if (c>=5):
    symps=[]
    for i in s:
      symps.append(i.upper())
    cls_screen()
    print ('Based on your profile and medical complaints, your are likely to be suffering from:\n')
    print (diff_diag(age,gender.upper(),symps))
    print ('\n\n***Please note that the suggested Diseases/Conditions are just likelihood estimates\n')
    print ('Please consult our specialist to evaluate your medical problems\n')  
    np.savetxt('/home/pavankumar/call-health-server/medibot/source/symps_instance.csv',np.array(symps),delimiter=',',fmt="%s")
    return (diff_diag(age,gender.upper(),symps))




##########################################################################################3


def extract_entities(text):
  for sent in nltk.sent_tokenize(text):
    for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(sent))):
      if hasattr(chunk, 'node'):
        return chunk.node, ' '.join(c[0] for c in chunk.leaves())




def geo_loc(q):
  url = str('http://maps.googleapis.com/maps/api/geocode/json?address='+q)
  response = urllib.urlopen(url)
  data = json.loads(response.read())
  if (len(data['results'][0]['formatted_address'].split(','))<=2):
    return (str(','.join([data['results'][0]['formatted_address'].split(',')[-len(data['results'][0]['formatted_address'].split(','))],data['results'][0]['formatted_address'].split(',')[-1]])))
  else:
    return (str(','.join([data['results'][0]['formatted_address'].split(',')[-3],data['results'][0]['formatted_address'].split(',')[-1]])))



def weatherapi(location):
  owm = pyowm.OWM("611c26dae2bb2b138e30811e66721dca")	
  observation = owm.weather_at_place(str(location))
  w=observation.get_weather()
  temperature=w.get_temperature('celsius')["temp"]
  weather_cond=w.get_detailed_status()
  return weather_cond , temperature



def weather_by_latlon(lat,lon):
  owm = pyowm.OWM("611c26dae2bb2b138e30811e66721dca")	
  obs = owm.weather_at_coords(lat,lon)
  mn=round(json.loads(obs.to_JSON())['Weather']['temperature']['temp_min']-273,2)
  mx=round(json.loads(obs.to_JSON())['Weather']['temperature']['temp_max']-273,2)
  weather_cond=str(json.loads(obs.to_JSON())['Weather']['detailed_status'])
  temperature=round(json.loads(obs.to_JSON())['Weather']['temperature']['temp']-273,2)
  return weather_cond , temperature, mn, mx


def location_by_latlon(lat,lon):
  owm = pyowm.OWM("611c26dae2bb2b138e30811e66721dca")	
  observation = owm.weather_at_coords(lat,lon)
  w=observation.get_location()
  location=w.get_name()
  return location


def sym_speciality(age,gender,q):
  f=open('/home/pavankumar/call-health-server/medibot/source/categories.csv')
  f=csv.reader(f)
  keywords=[]
  score=[]
  cat=[]
  for i in f:
    keywords.append(i[0])
    score.append(float(i[2]))
    cat.append(i[3])
  cat_uniq=np.unique(cat)
  if (age>=13):
    temp=[]
    for i in cat_uniq:
      if (i!='Pediatrics'):
        temp.append(i)
    cat_uniq=temp
  if (gender=='m' or gender=='M'):
    temp=[]
    for i in cat_uniq:
      if (i!='Obstetrtics and Gynaecology'):
        temp.append(i)
    cat_uniq=temp
  vote=np.zeros((len(cat_uniq),1))
  cat_uniq=np.array(cat_uniq)
  for i in q.split():
    if i in keywords:
      try:
        vote[np.where(cat[np.where(i==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]=score[np.where(i==np.array(keywords))[0][0]]+vote[np.where(cat[np.where(i==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]
      except:
        pass
    else:
      d=[]
      if (i not in words):
        for j in keywords:
          try:
            d.append((1-dist(embeddings_index[i],embeddings_index[j])))
          except:
            d.append(0)
        try:
          vote[np.where(cat[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0]=score[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]+vote[np.where(cat[np.where(keywords[np.argmax(d)]==np.array(keywords))[0][0]]==np.array(cat_uniq))[0][0],0] 
        except:
          pass
  if (np.sum(vote)>0): 
    return (cat_uniq[np.argmax(vote)])
  else:
    return ('404') 




def mayo_articles_url(q):
  urls=[]
  q=cleaned_query(q)
  q=q.lower()
  ques=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      ques.append(i)
  q=(' '.join(ques)) 	  
  f=open('/home/pavankumar/call-health-server/medibot/source/mayo_articles.csv')
  f=csv.reader(f)
  data=[]
  for i in f:
    data.append(' '.join(i[1].split()))
    urls.append(i[0])
  vote=np.zeros((len(data),1))
  for i in nltk.word_tokenize(q):
    for j in np.arange(len(data)):
      vote[j,0]=vote[j,0]+len(data[j].lower().split(i))-1
  temp=[]
  for i in vote:
    temp.append(i[0])
  vote=temp
  if (np.sum(vote)>0):
    return (np.array(urls)[np.argsort(vote)[::-1]][0:10])
  else:
    return (['404'])



def name_gender(q):
 try: 
  f=open('/home/pavankumar/call-health-server/medibot/source/indian_names.csv')
  f=csv.reader(f)
  m_names=[]
  f_names=[]
  for i in f:
    if (i[1]=='m'):
      m_names.append(i[0])
    else:
      f_names.append(i[0])
  first_name=nltk.word_tokenize(q)[0].capitalize()
  m=0
  f=0
  for i in nltk.word_tokenize(q):
    for j in m_names:
      if (i==j):
        m=m+1
    for j in f_names:
      if (i==j):
        f=f+1
  if (m>f):
    return ('m',first_name)
  elif (f>m):
    return ('f',first_name)
  else:
    return ('404',first_name)
 except:
  return (['404'])



def get_brand_mole_mapping():
  f=open('/home/pavankumar/call-health-server/medibot/source/brand_to_molecule.csv')
  f=csv.reader(f)
  brand_molecule={}
  for i in f:
    temp=[]
    for j in i[1].split('+'):
      temp.append(re.sub('[(]',' ',j))
    brand_molecule[i[0]]=[temp]
  cats=[]
  subcats=[]
  f=open('/home/pavankumar/call-health-server/medibot/source/cat_subcat.csv')
  f=csv.reader(f)
  for i in f:
    subcats.append(i[0])
    cats.append(i[1])
  for i,j in brand_molecule.items():
     flag=0 
     for k in i.split():
       if (k in subcats):
         flag=1
         brand_molecule[i].append([subcats[np.where(k==np.array(subcats))[0][0]]]) 
         break
     if (flag==0):
       brand_molecule[i].append(['others'])
     flag=0
     for k in i.split():
       if (k in cats):
         flag=1
         brand_molecule[i].append([cats[np.where(k==np.array(cats))[0][0]]]) 
         break
     if (flag==0):
       brand_molecule[i].append(['others'])
  return (brand_molecule)



brand_molecule=get_brand_mole_mapping()



def get_brand_mole(q):
  vote=[]
  name=[]
  cat=[]
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      if (len(i)>=3):
        temp.append(i)
  q=(' '.join(temp))
  for i,j in brand_molecule.items():
    count=0
    name.append(i)
    cat.append(j[1])
    for k in q.split():
      if (k==i.split()[0]):
        count=count+1
      try:
        if (k==i.split()[1]):
          count=count+0.5
      except:
        pass 
    vote.append(count)
  if (np.sum(vote)>0):
    v=np.array(vote)[np.where(np.array(vote)>0)]
    c_uniq=np.unique(np.array(cat)[np.where(np.array(vote)>0)])
    c=np.array(cat)[np.where(np.array(vote)>0)]
    n=np.array(name)[np.where(np.array(vote)>0)]
    v=v[np.argsort(v)[::-1]]
    n=n[np.argsort(v)[::-1]]
    c=c[np.argsort(v)[::-1]]
    print (np.array(c_uniq).reshape(len(c_uniq),1))
    ip=raw_input('Please select from the following Dose Form\n')
    n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip)-1]==c)[0]]
    c_selected=np.array(c_uniq)[int(ip)-1]  
    n_final=n_final.reshape(len(n_final),1)
    print (n_final)
    ip=raw_input('Please select from the following brand names\n')
    for i,j in brand_molecule.items():
      if (i==n_final[int(ip)-1]):
        break
    return (n_final[int(ip)-1],j[0],c_selected) 
  else:
    return ('404')






def drugs_clean(q):
  q=q.lower()
  q1=q  
  rx_mole_list=[]
  f=open('/home/pavankumar/call-health-server/medibot/source/drug_rx_mole_master.csv')
  f=csv.reader(f)
  for i in f:
    rx_mole_list.append(i[0])
  drug_master_words=[]
  f=open('/home/pavankumar/call-health-server/medibot/source/drug_master_words.csv')
  f=csv.reader(f)
  for i in f:
    drug_master_words.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i in drug_master_words):
      temp.append(i)
  q=(' '.join(temp))
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      temp.append(i)
  q=(' '.join(temp))
  if (len(temp)>0):
    return (q)
  else:
    temp=[]
    e_dist=[]
    for i in nltk.word_tokenize(q1):
      if (i not in words):
        temp.append(i)
    q1=(' '.join(temp))
    uniq_master=np.unique(drug_master_words)
    temp=[] 
    for i in uniq_master:
      for j in nltk.word_tokenize(q1):
        if ((len(i)>=3) and (len(j)>=3)): 
          d=edit_distance(i,j)
          if (d<=1):
            if (i[0]==j[0]):  
              temp.append(i)
    if (len(temp)>0):
      q=(' '.join(temp))
      return (q)
    else:
      return ('404')



def mole_rx_mole(q):
  rx_mole_list=[]
  f=open('/home/pavankumar/call-health-server/medibot/source/drug_rx_mole_master.csv')
  f=csv.reader(f)
  for i in f:
    rx_mole_list.append(i[0])
  drug_master_words=[]
  f=open('/home/pavankumar/call-health-server/medibot/source/drug_master_words.csv')
  f=csv.reader(f)
  for i in f:
    drug_master_words.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i in drug_master_words):
      temp.append(i)
  q=(' '.join(temp))
  temp=[]
  for i in nltk.word_tokenize(q):
    if (i not in words):
      temp.append(i)
  q=(' '.join(temp))
  mole=get_brand_mole(q)  
  c_selected=[mole[2]]
  mole=mole[1]
  vote=[]
  name=[]
  for i in rx_mole_list:
    count=0
    name.append(i) 
    for j in mole:
      for k in nltk.word_tokenize(j):
        if (i==k):
          count=count+1
    vote.append(count)
  if (np.sum(vote)>0):
    n=np.array(name)[np.where(np.max(vote)==np.array(vote))]	
    v=np.array(vote)[np.where(np.max(vote)==np.array(vote))]
    return (n,np.array(c_selected))
  else:
    return ([['404']])






def diag_names_match(q):
 try:
  f=open('/home/pavankumar/call-health-server/medibot/source/diagnositic_test_name.csv')
  f=csv.reader(f)
  dic=[]
  diag_name={}
  for i in f:
    temp=[]
    for j in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',i[0].lower())):
      if (j not in words):
        if (j!=''):
          temp.append(j)
    for j in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',i[1].lower())):
      if (j not in words):
        if (j!=''):
          temp.append(j) 
    for j in temp:
      if (j!='done'):
        if (len(j)>=3):
          dic.append(j)
    diag_name[i[0]]=[temp,i[2]]
  dic=np.unique(dic)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/diag_name_list.csv',dic,delimiter=',',fmt="%s") 
  f=open('/home/pavankumar/call-health-server/medibot/source/diag_name_list.csv')
  f=csv.reader(f)
  diag_names=[]
  for i in f:
    diag_names.append(i[0])
  temp=[]
  for i in nltk.word_tokenize(re.sub('[^a-zA-Z ]',' ',q.lower())):
    if (i not in words):
      if (i in diag_names):
        if (i!=''):
          temp.append(i)
  q=(' '.join(temp))
  pop=[]
  pop_code=[]
  f=open('/home/pavankumar/call-health-server/medibot/source/diag_test_popularity.csv')
  f=csv.reader(f)
  for i in f:
    pop_code.append(i[0])
    pop.append(float(i[1]))
  names=[]
  vote=[]
  codes=[]  
  for i,j in diag_name.items():
    names.append(i)
    codes.append(j[1])
    t=0
    for k in nltk.word_tokenize(q):
      t=t+(j[0].count(k))
    if (len(np.where(np.array(pop_code)==j[1])[0])>0):
      vote.append(t*10*pop[np.where(np.array(pop_code)==j[1])[0][0]])
    else:
      vote.append(t)
  if (np.sum(vote)>0):
    names_final=np.array(names)[np.argsort(vote)[::-1]]
    codes_final=np.array(codes)[np.argsort(vote)[::-1]]
    vote_final=np.array(vote)[np.argsort(vote)[::-1]]
    n=[]
    c=[]
    for i in np.arange(len(vote_final)):
      if (vote_final[i]>0):
        n.append(names_final[i])
        c.append(codes_final[i])
    if (len(n)>5):
      return (n[0:5],c[0:5])
    else:
      return (n,c)
  else:
    return ([['404']])
 except:
  return ([['404']])






def diag_full_info(q):
  res=diag_names_match(q)
  if (res[0][0]!='404'):
    names=res[0]
    codes=res[1]
    print (names.reshape(len(names),1))
    ip=raw_input('Please select the Diagnosic test based on the query\n')
    name=names[int(ip)-1]
    code=codes[int(ip)-1]
    diag_price={}
    f=open('/home/pavankumar/call-health-server/medibot/source/diagnositic_test_price.csv')
    f=csv.reader(f)
    for i in f:
      diag_price[i[0]]=[i[1],i[2]]
    diag_info={}
    f=open('/home/pavankumar/call-health-server/medibot/source/diagnositic_test_info.csv')
    f=csv.reader(f)
    for i in f:
      diag_info[i[0]]=[i[1]]
    diag_package={}
    f=open('/home/pavankumar/call-health-server/medibot/source/diagnositic_test_package.csv')
    f=csv.reader(f)
    for i in f:
      diag_package[i[0]]=[i[1:]]
    packages=[]
    for i,j in diag_package.items():
      if (code in j[0]):
        packages.append(i)
    if (len(packages)<=0):
      return ('The test '+str(name)+' is usually priced between Rs '+str(diag_price[code][0])+' and Rs '+str(diag_price[code][1])+' and has the following purpose \n'+str(diag_info[code][0]))     
    else:
      return ([['The test '+str(name)+' is usually priced between Rs '+str(diag_price[code][0])+' and Rs '+str(diag_price[code][1])+' and has the following purpose \n'+str(diag_info[code][0])+'\nThis test is available in the following packages\n'],[np.array(packages).reshape(len(packages),1)]])
  else:
    return ('404')




def drugs_info_final(q):
  f=open('/home/pavankumar/call-health-server/medibot/source/drug_dis_contra.csv')
  f=csv.reader(f)
  dis_contra={}
  for i in f:
    dis_contra[i[0]]=i[1:]
  f=open('/home/pavankumar/call-health-server/medibot/source/drug_moa.csv')
  f=csv.reader(f)
  drug_moa={}
  for i in f:
    drug_moa[i[0]]=i[1:]
  f=open('/home/pavankumar/call-health-server/medibot/source/drug_pe_induces.csv')
  f=csv.reader(f)
  drug_pe={}
  for i in f:
    drug_pe[i[0]]=i[1:]
  f=open('/home/pavankumar/call-health-server/medibot/source/drug_uses.csv')
  f=csv.reader(f)
  drug_uses={}
  for i in f:
    drug_uses[i[0]]=[' '.join((', '.join(i[1:]).split('\n')))]
  mole=mole_rx_mole(q)
  if (mole[0][0]!='404'):
    c_selected=mole[1]
    mole=mole[0]
    drug_info=[]
    for i in mole:
      try:
        drug_info.append(drug_uses[i][0])
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(drug_moa[i])))
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(dis_contra[i])))
      except:
        pass
      try:
        drug_info.append(str(i)+' '+(' '.join(drug_pe[i])))
      except:
        pass
    subs=[]
    for i,j in brand_molecule.items():
      if (set(j[0])==set(mole)):
        if (j[1][0]==c_selected[0]):
          subs.append(i)
    return (np.array(subs)[0:5],np.array(mole),(np.array(drug_info).reshape(len(drug_info),1)))
  else:
    return ('404')



     
##########################################################################################################################
################ start logging

def write_main_log(q,sessid):
  with open("/home/pavankumar/call-health-server/medibot/source/log/all_log_text.txt", "a") as myfile:
    myfile.write(str(sessid)+','+str(q))
    myfile.write('\n')



#########################################################################################################################

############# capture general user input


def sess_input(ip,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/dd_input.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    if (str(i[0])==str(sessid)):
      data[i[0]]=ip
      flag=1
    else:
      data[i[0]]=i[1]    
  if (flag==0):
    data[str(sessid)]=ip
  new_data=[]
  for i,j in data.items():
    new_data.append(re.sub('[^a-zA-Z0-9 ]','',i))
    new_data.append(re.sub('[^a-zA-Z0-9 ]','',j))
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/dd_input.csv',new_data,delimiter=',',fmt="%s")


############################################################################################################################
################### Read general input by the user

def read_sess_input(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/dd_input.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    if (str(i[0])==str(sessid)):
      return str(i[1])



############################################################################################################################
############ capture the flow id changes for users


def sess_flow_id(ip,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_flow_id.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    if (str(i[0])==str(sessid)):
      data[i[0]]=ip
      flag=1
    else:
      data[i[0]]=i[1]    
  if (flag==0):
    data[str(sessid)]=ip
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_flow_id.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################# DD status (correct,wrong) for users

def dd_status_log_counter(ip,sessid):
  ip=ip.lower()
  f=open('/home/pavankumar/call-health-server/medibot/source/log/dd_status_log.csv')
  f=csv.reader(f)
  data={}
  flag=0
  for i in f:
    data[i[0]]=i[1:]
    if (str(i[0])==str(sessid)):
      flag=1
  new_data={}
  for i,j in data.items():
    new_data[i]=[int(j[0]),int(j[1])]
    if (flag==1):
      if ((str(ip)=='y') and (str(sessid)==str(i))):
        new_data[i]=[int(j[0])+1,int(j[1])]
      if ((str(ip)=='n') and (str(sessid)==str(i))):
        new_data[i]=[int(j[0]),int(j[1])+1]
      if ((str(ip)=='0') and (str(sessid)==str(i))):
        new_data[sessid]=[0,0]
      continue
    if (flag==0):
      if (str(ip)=='y'):
        new_data[sessid]=[1,0]
      if (str(ip)=='n'):
        new_data[sessid]=[0,1]
      if (str(ip)=='0'):
        new_data[sessid]=[0,0]
      continue
  data=[]
  for i,j in new_data.items():
    data.append(i)
    for k in j:
      data.append(k)
  data=np.array(data).reshape((len(data)/3),3)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/dd_status_log.csv',data,delimiter=',',fmt="%s")



####################################################################################################################
############################# Edit distance function

def edit_distance(s1, s2):
    m=len(s1)+1
    n=len(s2)+1
    tbl = {}
    for i in range(m): tbl[i,0]=i
    for j in range(n): tbl[0,j]=j
    for i in range(1, m):
        for j in range(1, n):
            cost = 0 if s1[i-1] == s2[j-1] else 1
            tbl[i,j] = min(tbl[i, j-1]+1, tbl[i-1, j]+1, tbl[i-1, j-1]+cost)
    return tbl[i,j]


#####################################################################################################################
################################# DD status (correct,wrong) for users

def read_dd_status_log_counter(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/dd_status_log.csv')
  f=csv.reader(f)
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1],i[2])



#####################################################################################################################
######################################## capture symptoms list for users
 
def write_symps_log(sym,sessid):
  data={}
  flag=0  
  f=open('/home/pavankumar/call-health-server/medibot/source/log/symps_log.csv')
  f=csv.reader(f) 
  for i in f:
    if (str(i[0])==str(sessid)):
      flag=1
    if (i[1]!=''):
      data[i[0]]=i[1].split('XXXXX')
    else:
      data[i[0]]=[]
  if (flag==0):
    data[sessid]=[]  
  new_data={}
  for i,j in data.items():
    if (str(i)==str(sessid)):
      j.append(sym)
      new_data[i]=j
    else:
      new_data[i]=j
  data=[]
  for i,j in new_data.items():
    data.append(i)
    data.append('XXXXX'.join(j)) 
  data=np.array(data).reshape((len(data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/symps_log.csv',data,delimiter=',',fmt="%s")



#####################################################################################################################
######################################## read captured symptoms list for users
 
def read_symps_log(sessid):
  data={}
  flag=0  
  f=open('/home/pavankumar/call-health-server/medibot/source/log/symps_log.csv')
  f=csv.reader(f) 
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1].split('XXXXX'))




############################################################################################################################
############ read the flow id changes for users


def read_sess_flow_id(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_flow_id.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    if (str(i[0])==str(sessid)):
      return (i[1])




##############################################################################################################
################################## capture raw input of users

def sess_raw_input(msg,sessid):
  ip=raw_input(str(msg))
  return (ip,sessid)


##############################################################################################################
################################## read captured user info to see existing or new user 

def read_user_profile(mob):
  if (mob!='404'):
    f=open('/home/pavankumar/call-health-server/medibot/source/log/user_profiles.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1:]
    flag=0
    for i,j in data.items():
      if (str(mob)==i):
        flag=1
        break
    if (flag==0):
      return ('404')
    else:
      return (data[mob])
  else:
    return ('404')
   

##############################################################################################################
################################## read captured user info to see existing or new user 

def write_user_profile(mob,name,age,gender,location):
  if (mob!='404'):
    f=open('/home/pavankumar/call-health-server/medibot/source/log/user_profiles.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1:]
    data[mob]=[name,age,gender,location]
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      for k in j:
        new_data.append(k)
    new_data=np.array(new_data).reshape((len(new_data)/5),5)
    np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/user_profiles.csv',new_data,delimiter=',',fmt="%s") 
  else:
    return ('404')


#####################################################################################################################
################################## read sessid mobile number 

def read_sess_mob(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_mob.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid mobile number 

def write_sess_mob(mob,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_mob.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(mob)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_mob.csv',new_data,delimiter=',',fmt="%s")


#####################################################################################################################
################################## read sessid name 

def read_sess_name(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_name.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid name 

def write_sess_name(name,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_name.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(name)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_name.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################## read sessid age 

def read_sess_age(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_age.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid age 

def write_sess_age(age,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_age.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(age)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_age.csv',new_data,delimiter=',',fmt="%s")



#####################################################################################################################
################################## read sessid gender 

def read_sess_gender(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_gender.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid gender 

def write_sess_gender(gender,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_gender.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(gender)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_gender.csv',new_data,delimiter=',',fmt="%s")


#####################################################################################################################
################################## read sessid location 

def read_sess_location(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_location.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid location 

def write_sess_location(location,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_location.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(location)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_location.csv',new_data,delimiter=',',fmt="%s")


################################## write sessid latlon 

def write_sess_latlon(location,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_latlon.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(location)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_latlon.csv',new_data,delimiter=',',fmt="%s")


################################## read sessid latlon 

def read_sess_latlon(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_latlon.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp.split('XXXXX'))
  else:
    return ('404') 


################################## write sessid time 

def write_sess_time(time,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_time.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(time)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_time.csv',new_data,delimiter=',',fmt="%s")




################################## read sessid latlon 

def read_sess_time(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_time.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 




################################## write sessid me_someone 

def write_sess_me_someone(txt,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_me_someone.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(txt)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_me_someone.csv',new_data,delimiter=',',fmt="%s")



################################## read sessid me_someone 

def read_sess_me_someone(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_me_someone.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 



################################## write sessid brand
def write_sess_brand(txt,sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_brand.csv')
  f=csv.reader(f)
  data={}
  for i in f:
    data[i[0]]=i[1]
  data[str(sessid)]=str(txt)  
  new_data=[]
  for i,j in data.items():
    new_data.append(i)
    new_data.append(j)
  new_data=np.array(new_data).reshape((len(new_data)/2),2)
  np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/sess_brand.csv',new_data,delimiter=',',fmt="%s")



################################## read sessid brand

def read_sess_brand(sessid):
  f=open('/home/pavankumar/call-health-server/medibot/source/log/sess_brand.csv')
  f=csv.reader(f)
  data={}
  flag=0 
  for i in f:
    data[i[0]]=i[1]
  for i,j in data.items():
    if (str(i)==str(sessid)):
      temp=j
      flag=1
      break
  if (flag==1):
    return (temp)
  else:
    return ('404') 




################################## write blank response with 888 as code

def blank_response_json(sessid):
  op_json={}
  op_json['data']=''
  op_json['options']=[]
  op_json['sessid']=str(sessid)
  op_json['response_type']='blank_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 


################################## write text response

def text_response_json(text,sessid):
  q=('Bot: '+str(text))
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=[]
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 


################################## write text+single selection response

def text_ss_response_json(text,options,sessid):
  q=('Bot: '+str(text)).encode('utf-8').strip()
  t=[]
  for i in np.arange(len(options)):
    t.append(' option '+str(i)+': '+str(options[i]).encode('utf-8').strip()+',')
  t=''.join(t).encode('utf-8').strip()
  q=str(q)+str(t).encode('utf-8').strip()    
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_and_ss_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 



################################## write text+list response

def text_list_response_json(text,options,sessid):
  q=('Bot: '+str(text))
  t=[]
  for i in np.arange(len(options)):
    t.append(' option '+str(i)+': '+str(options[i])+',')
  t=''.join(t)
  q=str(q)+str(t)    
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_list_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 



################################## write text+list response

def url_list_response_json(text,options,sessid):
  q=('Bot: '+str(text))
  t=[]
  for i in np.arange(len(options)):
    t.append(' option '+str(i)+': '+str(options[i])+',')
  t=''.join(t)
  q=str(q)+str(t)    
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='url_list_response'
  op_json['response_code']='888'
  return (json.dumps(op_json)) 




################################## write text+list response

def text_blank_response_json(text,options,flow_id,sessid):
  q=('Bot: '+str(re.sub('[^a-zA-Z0-9]',' ',text)))
  t=[]
  for i in np.arange(len(options)):
    t.append(' option '+str(i)+': '+str(options[i])+',')
  t=''.join(t)
  q=str(q)+str(t)    
  write_main_log(q,sessid) 
  op_json={}
  op_json['data']=text
  op_json['options']=options
  op_json['sessid']=str(sessid)
  op_json['response_type']='text_blank_response'
  op_json['response_code']='888'
  sess_flow_id(flow_id,sessid)  
  return (json.dumps(op_json)) 


####################################### Main menu response with image embedded

def main_menu_response_json(sessid):
  op_json={}
  op_json['data']='' 
  op_json['options']=[['Symptom Checker','https://chat.callhealth.com/img/symptomchecker.png'],['Medicines','https://chat.callhealth.com/img/medicines.png'],['Diagnostic Tests','https://chat.callhealth.com/img/diagnostics.png'],['Know more about health','https://chat.callhealth.com/img/abouthealth.png']]
  op_json['sessid']=str(sessid)
  op_json['response_type']='main_menu_response'
  op_json['response_code']='888'
  return (json.dumps(op_json))



def email_otp(mailid,sessid):
  otp=str(random.randint(100000,999999))
  sess_input(otp,sessid)
  to = str(mailid)
  gmail_user = 'callhealthindia@gmail.com'
  gmail_pwd = 'Siva@123'
  smtpserver = smtplib.SMTP("smtp.gmail.com",587)
  smtpserver.ehlo()
  smtpserver.starttls()
  smtpserver.ehlo
  smtpserver.login(gmail_user, gmail_pwd)
  header = 'To:' + to + '\n' + 'From: ' + gmail_user + '\n' + 'Subject: Your OTP! \n'
  #print header
  msg = header + '\n Please Enter the OTP \n\n'+str(otp) 
  smtpserver.sendmail(gmail_user, to, msg)
  #print 'done!'
  smtpserver.close()



dis_urls={}
f=open('/home/pavankumar/call-health-server/medibot/source/dis_urls.csv')
f=csv.reader(f)
for i in f:
  dis_urls[i[0]]=str(i[1])




#################################################################################################################
############################ DD API 



brand_molecule=get_brand_mole_mapping()
generic_symps=['pain','swelling','bleeding','discharge']


def dd_api(mob,sessid,ip,request_type):
  if (str(ip)!='Hello'):
    write_main_log(('User: '+str(ip)),sessid)
  if (request_type=='auth_request'):
    email_otp(ip,sessid)
    sess_flow_id('authenticate',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='authenticate'):
    ip=ip
    print ip 
    if (str(ip)==str(read_sess_input(sessid))):
      op_json={}
      op_json['response_type']='auth_success'
      op_json['response_code']='888'
      op_json=json.dumps(op_json)
      return (op_json)
    else:
      op_json={}
      op_json['response_type']='auth_failure'
      op_json['response_code']='888'
      op_json=json.dumps(op_json)
      return (op_json)
  if (request_type=='initial_request'):
    d=ip.split('[')
    u=[]
    for i in d:
      for j in i.split(']'):
        if (j!=''):
          u.append(j)
    if (u[0]=='FALSE'):
      write_sess_name(u[1],sessid)
      write_sess_age(date_diff(u[2]),sessid)
      write_sess_gender(u[3].lower(),sessid)
      write_sess_location(u[4],sessid)
      write_sess_latlon(str(str(u[5])+'XXXXX'+str(u[6])),sessid)
      try:
        write_sess_time(str(u[7]),sessid)
        wish_on_time(sessid)
      except:
        write_sess_time(str(u[8]),sessid)
        wish_on_time(sessid)
      sess_flow_id('get_weather',sessid)
      #write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
      op_json=blank_response_json(sessid)
    else:
      write_sess_latlon(str(str(u[5])+'XXXXX'+str(u[6])),sessid)
      write_sess_time(str(u[7]),sessid)
      sess_flow_id('check_user',sessid)
      op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='None'):
    sess_flow_id('check_user',sessid)
    op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='check_user'):
    if (read_user_profile(mob)!='404'):
      write_sess_name(read_user_profile(mob)[0],sessid)
      write_sess_age(read_user_profile(mob)[1],sessid)
      write_sess_gender(read_user_profile(mob)[2],sessid)
      write_sess_location(read_user_profile(mob)[3],sessid)
      sess_flow_id('get_weather',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    elif (mob=='404'):
      write_sess_name('',sessid)
      write_sess_location('Hyderabad, India',sessid) 
      sess_flow_id('get_weather',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
    else:
      try: 
        weather = weather_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        #location = location_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        location='Hyderabad, India'   
        write_sess_location(location,sessid) 
      except:
        location='Hyderabad, India'   
        weather = weather_by_latlon(float(17.5),float(78.5))
        write_sess_location(location,sessid)
      temperature = weather[1]
      weather_cond = weather[0]
      min_temp = weather[2]
      max_temp = weather[3] 
      text=str(wish_on_time(sessid))+" It's now "+str(temperature)+" Deg C, "+weather_cond.capitalize()+str(" outside with a max of ")+str(max_temp)+str(" Deg C and a min of ")+str(min_temp)+' Deg C'
      options=[]
      flow_id='check_user_continue'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='check_user_continue'):
    text="Lets introduce ourselves to begin with. I am your Personal Health Assistant. What's your name?"
    op_json=text_response_json(text,sessid)
    sess_flow_id('new_user_name',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='new_user_name'):
    ip=ip
    write_sess_name(ip,sessid)
    sess_flow_id('get_weather',sessid)
    op_json=blank_response_json(sessid)
    sess_input('newuser',sessid) 
    return (op_json)    
  if (str(read_sess_flow_id(sessid))=='get_location'):
    if (read_sess_latlon(sessid)[0]=='404'):
      text='Where are you from?\n'
      op_json=text_response_json(text,sessid)
      sess_flow_id('input_get_location',sessid)
      return (op_json)
    else:
      try:
        location = location_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        write_sess_location(location,sessid)
        sess_flow_id('get_weather',sessid)
        op_json=blank_response_json(sessid)
        return (op_json) 
      except:
        location='Hyderabad, India'   
        write_sess_location(location,sessid)
        sess_flow_id('get_weather',sessid)
        op_json=blank_response_json(sessid)
        return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_get_location'):
    ip=ip
    location=geo_loc(ip)
    write_sess_location(re.sub('[^a-zA-Z0-9 ]','',location),sessid)
    sess_flow_id('get_weather',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='get_weather'):
    if (mob=='404'):
      try:
        if (read_sess_name(sessid)!=''):
          text=wish_on_time(sessid)+" "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
        else:
          text=wish_on_time(sessid)+"!"+" How can I help you?"
      except:
        if (read_sess_name(sessid)!=''):
          text=wish()+" "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
        else:
          text=wish()+"!"+" How can I help you?"
      flow_id='main_menu'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
    elif (read_sess_latlon(sessid)[0]=='404'):
      try:
        text=wish_on_time(sessid)+" "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
      except:
        text=wish()+" "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! How can I help you?"
      flow_id='main_menu'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
    else:
      try: 
        weather = weather_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        #location = location_by_latlon(float(read_sess_latlon(sessid)[0]),float(read_sess_latlon(sessid)[1]))
        location='Hyderabad, India'   
        write_sess_location(location,sessid) 
      except:
        location='Hyderabad, India'   
        weather = weatherapi(location)
        write_sess_location(location,sessid)
      temperature = weather[1]
      weather_cond = weather[0]
      min_temp=weather[2]
      max_temp=weather[3]
      if (read_sess_input(sessid)=='newuser'):
        text = "Hello "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+", How can I help you ?"      
      else: 
        text="It's now "+str(temperature)+" Deg C, "+weather_cond.capitalize()+str(" outside with a max of ")+str(max_temp)+str(" Deg C and a min of ")+str(min_temp)+' Deg C'+", How can I help you "+read_sess_name(sessid).capitalize()+"?" 
        #text="Hello, How can I help you "+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"?" 
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='main_menu'):
#    res=[]
#    res.append('1. Are you or your loved ones experiencing some symptoms and want to get them investigated ?')
#    res.append('2. Do you want to know information about drugs?')
#    res.append('3. Do you want to know information about diagnostic tests?')
#    res.append('4. Are you looking for some info on prevention and wellness ?')
#    text='Please select from the following options\n'
#    options=res
#    op_json=text_ss_response_json(text,options,sessid)
    op_json=main_menu_response_json(sessid)
    sess_flow_id('input_main_menu',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_main_menu'):
    sess_input(ip,sessid)
    sess_flow_id('service_choice_main_menu',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='service_choice_main_menu'):
    ip=read_sess_input(sessid)
    if (str(ip)=='1'):
      sess_flow_id('dd_age',sessid)
    if (str(ip)=='2'):
      sess_flow_id('drugs_flow',sessid)
    if (str(ip)=='3'):
      sess_flow_id('diag_flow',sessid)
    if (str(ip)=='4'):
      sess_flow_id('mayo_articles_flow',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_age'):
    ip=ip
    ip=re.sub('[^0-9]','',ip)
    if (ip!=''):
      if ((int(ip)>=0) and (int(ip)<=100)):
        write_sess_age(ip,sessid)
        sess_flow_id('dd_gender',sessid)
        write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid)) 
      else:
        sess_flow_id('dd_age_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      sess_flow_id('dd_age_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='dd_age'):
    dd_status_log_counter('0',sessid)
    text='To give you the most accurate information, I need to ask a few questions'
    options=[]
    flow_id='dd_start'
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='continue_dd'):
    if (read_sess_age(sessid)=='404'):
      try:
        text="What is your Age?"
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_dd_age',sessid)
      except:
        op_json=blank_response_json(sessid)
        sess_flow_id('dd_age_wrong',sessid)
    else:
      op_json=blank_response_json(sessid)  
      sess_flow_id('dd_gender',sessid)
    return (op_json)  
  if (str(read_sess_flow_id(sessid))=='dd_age_wrong'):
    text='Sorry! I could not understand. Please try again'
    options=[]
    flow_id='continue_dd'
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='input_dd_gender'):
    ip=ip[0]
    if (ip=='1'): 
      write_sess_gender('m',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid)) 
    else:
      write_sess_gender('f',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
    sess_flow_id('dd_me',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_gender_male_guess'):
    ip=ip[0]
    if (ip=='1'):
      write_sess_gender('m',sessid)
      sess_flow_id('dd_me',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
    else:
      sess_input('f',sessid)
      sess_flow_id('gender_wrong',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))     
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_gender_female_guess'):
    ip=ip[0]
    if (ip=='1'):
      write_sess_gender('f',sessid)
      sess_flow_id('dd_me',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
    else:
      sess_input('m',sessid)
      sess_flow_id('gender_wrong',sessid)
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))     
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_gender'):
    if (read_sess_gender(sessid)=='404'):
      g=name_gender(read_sess_name(sessid))
      if (g[0]=='404'):
        options=['Male','Female']
        text='And your gender?'
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_dd_gender',sessid)
        return (op_json) 
      elif (g[0]=='m'):
        text="'"+str(read_sess_name(sessid)).capitalize()+"' seems a male name. Am I right?"
        options=['Yes','No']
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_gender_male_guess',sessid)
        return (op_json)
      elif (g[0]=='f'):
        text="'"+str(read_sess_name(sessid)).capitalize()+"' seems a female name. Am I right?"
        options=['Yes','No']
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_gender_female_guess',sessid)
        return (op_json)
    else:
      sess_flow_id('dd_me',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='gender_wrong'):
    text='Oops! :('
    write_sess_gender(read_sess_input(sessid),sessid)
    write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid)) 
    f=open('/home/pavankumar/call-health-server/medibot/source/indian_names.csv')
    f=csv.reader(f)
    data={}
    for i in f:
      data[i[0]]=i[1]
    data[read_sess_name(sessid)]=read_sess_input(sessid)        
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      new_data.append(j)
    new_data=np.array(new_data).reshape((len(new_data)/2),2)
    np.savetxt('/home/pavankumar/call-health-server/medibot/source/indian_names.csv',new_data,delimiter=',',fmt="%s")
    flow_id='dd_me'
    options=[]
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_start'):
    ip=ip[0]
    if (ip=='1'):
      write_user_profile(mob,read_sess_name(sessid),read_sess_age(sessid),read_sess_gender(sessid),read_sess_location(sessid))
      write_sess_me_someone('me',sessid)
      sess_flow_id('continue_dd',sessid)
    if (ip=='2'):
      sess_flow_id('dd_someone_else',sessid)
      write_sess_me_someone('someone',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_start'):
    dd_status_log_counter('0',sessid)
    if (read_sess_name(sessid)!=''):
      text='Ok '+str(read_sess_name(sessid))+', before we proceed let me know who is this symptom check for?'
    else:
      text='First, Who is this symptom check for?'
    options=['Me','Someone else']
    sess_flow_id('input_dd_start',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dd_someone_else'):
    ip=ip
    ip=re.sub('[^0-9]','',ip)
    if (ip!=''):
      if ((int(ip)>=0) and (int(ip)<=100)):
        write_sess_age(ip,sessid)
        sess_flow_id('dd_someone_else_gender',sessid)
      else:
        sess_flow_id('dd_age_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      sess_flow_id('dd_age_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_someone_else'):
    text='How old is that person?'
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_dd_someone_else',sessid)
    return (op_json)    
  if (str(read_sess_flow_id(sessid))=='input_dd_someone_else_gender'):
    ip=ip
    g=name_gender(ip)
    if (g[0]=='m'):
      text="'"+str(ip).capitalize()+"' seems a male name. Am I right?"
      options=['Yes','No']
      sess_input(g[0],sessid)
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('someone_gender_check',sessid)
      return (op_json)
    elif (g[0]=='f'):
      text="'"+str(ip).capitalize()+"' seems a female name. Am I right?"
      options=['Yes','No']
      sess_input(g[0],sessid)
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('someone_gender_check',sessid)
      return (op_json)
    else:
      options=['Male','Female']
      text='And the gender?'
      sess_input('after_gender_options',sessid)
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('someone_gender_check',sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='someone_gender_check'):
    if (read_sess_input(sessid)=='after_gender_options'):
      ip=ip[0]
      res=['m','f']
      write_sess_gender(res[int(ip)-1],sessid)
      sess_flow_id('dd_me',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      ip=ip[0]
      if (str(ip)=='1'):
        write_sess_gender(read_sess_input(sessid),sessid)
        sess_flow_id('dd_me',sessid)
        op_json=blank_response_json(sessid)
        return (op_json)
      else:
        if (read_sess_input(sessid)=='m'):
          write_sess_gender('f',sessid)
        else:
          write_sess_gender('m',sessid)
        text='Oops! :('
        options=[]
        flow_id='dd_me'
        op_json=text_blank_response_json(text,options,flow_id,sessid)
        return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_someone_else_gender'):
    text="What is the person's name?"
    op_json=text_response_json(text,sessid)
#    options=['Male','Female']
#    text='And gender?'
#    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_dd_someone_else_gender',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_sym_anti'):
      ip=ip
      sess_input(ip,sessid)
      sess_flow_id('sym_anti',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_me'):
   if (read_sess_input(sessid)!='less_than_two_check'):
    data={}
    f=open('/home/pavankumar/call-health-server/medibot/source/log/symps_log.csv')
    f=csv.reader(f)
    for i in f:
      if (str(i[0])==str(sessid)): 
        data[i[0]]=''
      else:
        data[i[0]]=i[1]
    new_data=[]
    for i,j in data.items():
      new_data.append(i)
      new_data.append(j)
    new_data=np.array(new_data).reshape((len(new_data)/2),2)
    np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/symps_log.csv',new_data,delimiter=',',fmt="%s")
    dd_status_log_counter('0',sessid)    
    if (read_dd_status_log_counter(sessid)==None):
      dd_status_log_counter('0',sessid)
    if ((int(read_dd_status_log_counter(sessid)[0])<4) and (int(read_dd_status_log_counter(sessid)[1])<=3)):
      if ((int(read_dd_status_log_counter(sessid)[0])+int(read_dd_status_log_counter(sessid)[1]))>0):
        if (str(read_sess_me_someone(sessid))=='me'):
          text=str('Please describe your symptoms')
        else:
          text=str('Please describe their symptoms')
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_sym_anti',sessid)
        return (op_json)
      else:
        if (str(read_sess_me_someone(sessid))=='me'):
          text=str('Lets get started tell me about the symptoms you have today?')
        else:
          text='Thanks! :) we are set. What are symptoms?'
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_sym_anti',sessid)
        return (op_json)
    elif (int(read_dd_status_log_counter(sessid)[1])>=3):
      text='Sorry! I could not understand you'
      options=[]
      flow_id='dd_end' 
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
   else:
    if ((int(read_dd_status_log_counter(sessid)[0])<4) and (int(read_dd_status_log_counter(sessid)[1])<=3)):
      if ((int(read_dd_status_log_counter(sessid)[0])+int(read_dd_status_log_counter(sessid)[1]))>0):
        if (str(read_sess_me_someone(sessid))=='me'):
          text=str('Please describe your symptoms')
        else:
          text=str('Please describe their symptoms')  
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_sym_anti',sessid)
        return (op_json)
      else:
        if (str(read_sess_me_someone(sessid))=='me'):   
          text=str('Lets get started tell me about the symptoms you have today?')
        else:
          text='Thanks! :) we are set. What are symptoms?' 
        op_json=text_response_json(text,sessid)
        sess_flow_id('input_sym_anti',sessid)
        return (op_json)
    elif (int(read_dd_status_log_counter(sessid)[1])>=3):
      text='Sorry! I could not understand you'
      options=[]
      flow_id='dd_end' 
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='sym_anti'):
    ip=read_sess_input(sessid)
    flag=0
    s_temp=sym_anti(read_sess_gender(sessid),ip) 
    sym_list=[]
    for i,j in sym_crawl.items():
      sym_list.append(i.lower()) 
      if (str(i.lower())==str(ip.lower())):
        flag=1
        break
    if (flag==1 and str(s_temp)!='404'):
      s_temp=sym_anti(read_sess_gender(sessid),ip)
      #s_temp=read_sess_input(sessid)
      sess_input(s_temp,sessid)
      write_symps_log(s_temp.upper(),sessid)
      sess_input(s_temp,sessid) 
      sess_flow_id('next_sym',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    elif (flag==0 and str(s_temp)!='404'):
      s_temp=sym_anti(read_sess_gender(sessid),ip) 
      #s_temp=read_sess_input(sessid)
      write_symps_log(s_temp.upper(),sessid)
      sess_input(s_temp,sessid)
      sess_flow_id('sym_correct_wrong',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      text='Sorry! I could not understand you'
      dd_status_log_counter('n',sessid)
      flow_id='dd_me'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_sym_correct_wrong'):
    ip=ip[0]
    res=['y','n'] 
    if (ip=='1'):
      s_temp=read_sess_input(sessid)
      write_symps_log(s_temp.upper(),sessid)
      sess_flow_id('next_sym',sessid)	
    else:
      sess_flow_id('dd_me',sessid)
    dd_status_log_counter(res[int(ip)-1],sessid)
    op_json=blank_response_json(sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='sym_correct_wrong'):
    if ((int(read_dd_status_log_counter(sessid)[0])<4) or (int(read_dd_status_log_counter(sessid)[1])<=3)):
        s_temp=read_sess_input(sessid)
        text=str('Did you mean ')+str(s_temp).title()+str('?')
        options=['Yes','No']
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_sym_correct_wrong',sessid)
        return (op_json)
    elif ((int(read_dd_status_log_counter(sessid)[0])==3)):
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    elif (int(read_dd_status_log_counter(sessid)[1])==3):
      text='My apologies! I could not understand you'
      flow_id='dd_end'
      options=[]
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
    else:
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_next_sym'):
    res=[]
    temp=read_symps_log(sessid)
    s=[]
    for i in temp:
      s.append(i.lower())
    for i in co_sym_suggest(read_sess_gender(sessid),s):
      res.append(i.capitalize())    
    res.append('Other symptom')
    res.append('No other symptom')
    ip=ip[0]
    sess_input(ip,sessid)      
    sess_flow_id('dd_decision',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)  
  if (str(read_sess_flow_id(sessid))=='next_sym'):
    res=[]
    temp=read_symps_log(sessid)
    s=[]
    for i in temp:
      s.append(i.lower())
    for i in co_sym_suggest(read_sess_gender(sessid),s):
      res.append(i.capitalize())    
    res.append('None of these')
    res.append('No other symptom')
    options=res
    if (len(s)==1):
      text='Ok '+str(s[-1])+'. Any other symptoms?'
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('input_next_sym',sessid)
      return (op_json)
    elif (len(s)==2):
      if (str(read_sess_me_someone(sessid))=='me'):   
        text='Do you have any of these symptoms?'
      else:
        text='Do they have any of these symptoms?'  
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('input_next_sym',sessid)
      return (op_json)
    else:
      if (str(read_sess_me_someone(sessid))=='me'):
        text='How long you had these symptoms?'
      else:
        text='How long they had these symptoms?'
      options=['Few Hours','Few Days','Few Weeks','None Of These'] 
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('last_sym_input',sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='last_sym_input'):
      ip=ip
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='input_other_symptom'):
    ip=ip
    sess_input(ip,sessid)
    sess_flow_id('sym_anti',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_decision'):
    res=[]
    ip=read_sess_input(sessid)
    temp=read_symps_log(sessid)    
    s=[]
    for i in temp:
      s.append(i.lower())
    if (len(s)>=3):
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
    for i in co_sym_suggest(read_sess_gender(sessid),s):
      res.append(i.capitalize())    
    res.append('Other symptom')
    res.append('No other symptom')
    choice=res[int(ip)-1]
    if (choice=='Other symptom'):
      if (str(read_sess_me_someone(sessid))=='me'):
        text='Please describe your symptoms'
      else:
        text="Please describe the person's symptoms"
      op_json=text_response_json(text,sessid)
      sess_flow_id('input_other_symptom',sessid)
      return (op_json)   
    elif (choice=='No other symptom'):
      sess_flow_id('get_dd',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
    else:
      write_symps_log(choice.upper(),sessid)
      sess_flow_id('next_sym',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='less_than_two_symps'):
    ip=ip[0]
    if (ip=='1'):
      sess_flow_id('dd_me',sessid)
      op_json=blank_response_json(sessid)
      sess_input('less_than_two_check',sessid) 
      return (op_json)
    else:
      text='Do you want to readup on the possible conditions?'
      options=['Yes','No']
      sess_flow_id('dd_yes_no',sessid)
      op_json=text_ss_response_json(text,options,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_yes_no'):
     ip=ip[0]
     if (ip=='1'):    
      s=read_symps_log(sessid)
      s=np.unique(s)
      symps=[]
      for i in s:
        symps.append(i.upper())
      d=diff_diag(int(read_sess_age(sessid)),read_sess_gender(sessid).upper(),symps)
      options=[]
      #for i in d:
      #  options.append(i[0].title())
      dis=[]
      urls=[]
      for i,j in dis_urls.items():
        dis.append(i)
        urls.append(j)
      for i in d:
         options.append([urls[np.where(np.array(dis)==i[0])[0][0]],'url']) 
      s=(' '.join(np.unique(read_symps_log(sessid))))
      s=s.lower()
      sess_input(s,sessid)
#      if (str(read_sess_me_someone(sessid))=='me'):
#        text='Based on your symptoms, you are likely to be diagnosed with:'
#      else:
#        text='Based on the symptoms, the likely diagnosis are:' 
      text='Here is what I found..'
      flow_id='sym_to_speciality'
      sess_flow_id(flow_id,sessid)
      op_json=url_list_response_json(text,options,sessid)
      #op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
     else:
      flow_id='sym_to_speciality_continue'
      sess_flow_id(flow_id,sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='get_dd'):
    s=read_symps_log(sessid)
    s=np.unique(s)
    symps=[]
    for i in s:
      symps.append(i.upper())
    if (len(symps)<2):
      sess_flow_id('less_than_two_symps',sessid)
      text='Too few symptoms given, to give an accurate diagnosis. Enter more symptoms?'
      options=['Yes','No']
      op_json=text_ss_response_json(text,options,sessid)
      return (op_json)
    text='Do you want to readup on the possible conditions?'
    options=['Yes','No']
    sess_flow_id('dd_yes_no_proper',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='dd_yes_no_proper'):
    ip=ip[0]
    if (ip=='1'):
      s=read_symps_log(sessid)
      s=np.unique(s)
      symps=[]
      for i in s:
        symps.append(i.upper())
      d=diff_diag(int(read_sess_age(sessid)),read_sess_gender(sessid).upper(),symps)
#    options=[]
#    for i in d:
#      options.append(str(i[0]).title())
      options=[]
      dis=[]
      urls=[]
      for i,j in dis_urls.items():
        dis.append(i)
        urls.append(j)
      for i in d:
        options.append([str(urls[np.where(np.array(dis)==i[0])[0][0]]),'url']) 
      s=(' '.join(np.unique(read_symps_log(sessid))))
      s=s.lower()
      sess_input(s,sessid)
#      if (str(read_sess_me_someone(sessid))=='me'):
#        text='Based on your symptoms, you are likely to be diagnosed with:'
#      else:
#        text='Based on the symptoms, the likely to be diagnosed with:'
      text='Here is what I found..'
      flow_id='sym_to_speciality'
      sess_flow_id(flow_id,sessid)
#      #op_json=text_blank_response_json(text,options,flow_id,sessid)
      op_json=url_list_response_json(text,options,sessid)
      return (op_json)
    else:
      sess_flow_id('sym_to_speciality_continue',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='sym_to_speciality'):
#    s=read_sess_input(sessid)
#    if (sym_speciality(int(read_sess_age(sessid)),read_sess_gender(sessid),s)[0]!='404'):
#      text=('Based on your condition I recommend you consult '+sym_speciality(int(read_sess_age(sessid)),read_sess_gender(sessid),(s))+'\nYou can call us on 33557799\n')
      text='** Please note that the above conditions are likely but not conclusive'
      options=[]
      flow_id='sym_to_speciality_continue'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='sym_to_speciality_continue'):
      text=('Please call 33557799 to schedule a consultation with our specialists') 
      options=[]
      flow_id='sym_to_mayo_message' 
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
#    else:
#      op_json=blank_response_json(sessid)
#      sess_flow_id('sym_to_mayo',sessid)
#      sess_input(s,sessid)
#      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='sym_to_mayo_message'):
    if (str(read_sess_me_someone(sessid))=='me'):
      text='Do you want to read up more about your symptoms?'
    else:
      text='Do you want to read up more about the symptoms?' 
    options=['Yes','No']
    sess_flow_id('sym_to_mayo',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='sym_to_mayo'):
    ip=ip[0]
    if (str(ip)=='1'):
      s=read_sess_input(sessid)
      if (len(mayo_articles_url((s).lower()))!=0):
        if ((mayo_articles_url((s).lower())[0]!='404')):
          text = ('Here is what I found..')
          u=[]
          g=read_sess_gender(sessid)
          a=read_sess_age(sessid)
          options=[]
          if (g=='m'):
            if (len(mayo_articles_url((s).lower()))>0):    
              for i in (mayo_articles_url((s).lower())):
                if ((i.split('/')[4]!='womens-health') and (i.split('/')[4]!='pregnancy')):
                  u.append([i,'url'])
            else:
              for i in (mayo_articles_url((s).lower())):
                  u.append([i,'url'])
#          if (int(a)>14):
#            if (len(u)>0):
#              for i in u:
#                if ((i.split('/')[4]!='childrens-health')):
#                  options.append([i,'url'])
          if (len(u)>8):
            u=u[np.arange(8)] 
            options=u
          if (len(u)>0):   
            op_json=url_list_response_json(text,options,sessid)
            sess_flow_id('dd_end',sessid)
            return (op_json)
          else:
            text='Sorry! I could not find any articles related to your symptoms'
            options=[]
            flow_id='dd_end' 
            op_json=text_blank_response_json(text,options,flow_id,sessid)
            return (op_json) 
        else:
          op_json=blank_response_json(sessid)
          sess_flow_id('dd_end',sessid)
          return (op_json) 
      else:
        op_json=blank_response_json(sessid)
        sess_flow_id('dd_end',sessid)
        return (op_json)
    else:
      op_json=blank_response_json(sessid)
      sess_flow_id('dd_end',sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='dd_end'):
    text='Was this information helpful?'
    options=['Yes','No']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_feedback_response',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_feedback_response'):
    ip=ip[0]
    if (ip=='1'):
      sess_flow_id('reason_pos_feedback',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      sess_flow_id('reason_feedback',sessid)
      if (read_sess_name(sessid)!=''): 
        text=nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+", I am sorry. I could'nt be of more help this time.\nPlease tell me what went wrong so that I can improve"
      else:
        text="I am sorry. I could'nt be of more help this time.\nPlease tell me what went wrong so that I can improve"
      options=['You did not understand me','You asked me irrelevant questions','Results shown were not satisfactory','Others']
      op_json=text_ss_response_json(text,options,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='reason_pos_feedback'):
    if (read_sess_name(sessid)!=''): 
      text='Thanks '+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+'. I am pleased that I could help you'
    else:
      text='Thanks, I am pleased that I could help you' 
    options=[]
    flow_id='before_main_menu'
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='reason_feedback'):
    if (str(ip[0])=='4'):
      text='Please let me know the reason'
      options=[]
      sess_flow_id('before_main_menu',sessid)
      op_json=text_response_json(text,sessid)
      return (op_json)
    else:
      sess_flow_id('before_main_menu',sessid)
      op_json=blank_response_json(sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='before_main_menu'):
    if (read_sess_name(sessid)!=''): 
      text='Ok '+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+' do you want to know anything else?'
    else:
      text='Do you want to know anything else?'
    options=['Yes','No']
    sess_flow_id('end_session',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='end_session'):
    ip=ip[0]
    if (str(ip)=='2'):
      sess_flow_id('take_email',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      sess_flow_id('main_menu',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='take_email'):
    text='Do you want me to send this chat to your E-Mail?'
    options=['Yes','No']
    sess_flow_id('input_take_email',sessid)
    op_json=text_ss_response_json(text,options,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_take_email'):
    if (str(ip[0])=='1'):
      text='Enter your email'
      op_json=text_response_json(text,sessid)
      sess_flow_id('end_session_continue',sessid)
      return (op_json)
    else:
      op_json=blank_response_json(sessid)
      sess_flow_id('end_session_continue',sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='end_session_continue'):
      if (read_sess_name(sessid)!=''):
        text='Thank you! '+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! for using CallHealth 'My Personal Health Assistant'"
      else:
        text="Thank you! for using CallHealth 'My Personal Health Assistant'"
      options=[]
      flow_id='to_end_all'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
#      if (read_sess_name(sessid)!=''):
#        text='Thank you! '+nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+"! for using CallHealth 'My Personal Health Assistant'"
#      else:
#        text="Thank you! for using CallHealth 'My Personal Health Assistant'"
#      options=[]
#      flow_id='take_email'
#      op_json=text_blank_response_json(text,options,flow_id,sessid)
#      return (op_json)
#    else:
#      sess_flow_id('main_menu',sessid)
#      op_json=blank_response_json(sessid)
#      return (op_json)
#  if (str(read_sess_flow_id(sessid))=='take_email'):
#    text='Do you want me to send this chat to your E-Mail?'
#    options=['Yes','No']
#    sess_flow_id('input_take_email',sessid)
#    op_json=text_ss_response_json(text,options,sessid)
#    return (op_json)
#  if (str(read_sess_flow_id(sessid))=='input_take_email'):
#    if (str(ip[0])=='1'):
#      text='Enter your email'
#      op_json=text_response_json(text,sessid)
#      sess_flow_id('to_end_all',sessid)
#      return (op_json)
#    else:
#      op_json=blank_response_json(sessid)
#      sess_flow_id('to_end_all',sessid)
#      return (op_json)
  if (str(read_sess_flow_id(sessid))=='to_end_all'):
    ip=ip
    op_json={}
    op_json['sessid']=sessid
    op_json['options']=[]
    op_json['response_code']='888'
    op_json['response_type']='end_session'
    op_json['data']=''
    sess_flow_id('end_all',sessid) 
    return (json.dumps(op_json))
  if (str(read_sess_flow_id(sessid))=='input_mayo_articles_flow'):
    ip=ip
    a=mayo_articles_url(ip)
    options=[]
    if (a[0]!='404'):
      for i in a:
        options.append([i,'url'])
      sess_flow_id('get_mayo_feedback',sessid)
      text='Here is some information that you might find useful'
      op_json=url_list_response_json(text,options,sessid)
      return (op_json) 
    else:
      text=('I could not find any relevant articles based on your query')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='get_mayo_feedback'):
    text='Was this information helpful?'
    options=['Yes','No']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_feedback_response',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='mayo_articles_flow'):
    if (read_sess_name(sessid)!=''):
      text=nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+', what do you want to know?'
    else:
      text='What do you want to know?' 
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_mayo_articles_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_drugs_flow'):
    ip=ip
    ip=ip.lower()
    sess_input(ip,sessid)
    op_json=blank_response_json(sessid)
    sess_flow_id('drugs_flow_continue',sessid)
    return (op_json)   
  if (str(read_sess_flow_id(sessid))=='drugs_flow'):
    text=('Tell me the name of the medicine you wish to know about')
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_drugs_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='drugs_flow_continue'):
    q=read_sess_input(sessid) 
    q=drugs_clean(q)
    q_name=read_sess_input(sessid)
    q_name=nltk.word_tokenize(drugs_clean(q_name))[0]
    vote=[]
    if (q!='404'):
      vote=[]
      name=[]
      cat=[]
      temp=[]
      for i in nltk.word_tokenize(q):
        if (i not in words):
          if (len(i)>=3):
            temp.append(i)
      q=(' '.join(temp))
      for i,j in brand_molecule.items():
        count=0
        name.append(i)
        cat.append(j[1])
        for k in q.split():
          if (k==i.split()[0]):
            count=count+1
          try:
            if (k==i.split()[1]):
              count=count+0.5
          except:
            pass 
        vote.append(count)
    if (np.sum(vote)>0):
      v=np.array(vote)[np.where(np.array(vote)>0)]
      c_uniq=np.unique(np.array(cat)[np.where(np.array(vote)>0)])
      c=np.array(cat)[np.where(np.array(vote)>0)]
      n=np.array(name)[np.where(np.array(vote)>0)]
      v=v[np.argsort(v)[::-1]]
      n=n[np.argsort(v)[::-1]]
      c=c[np.argsort(v)[::-1]]
      f=open('/home/pavankumar/call-health-server/medibot/source/log/drug_name_log.csv')
      f=csv.reader(f)
      name_log={}
      for i in f:
        name_log[i[0]]=i[1]
      name_log[sessid]=str('XXXXX'.join(n))
      new_data=[]
      for i,j in name_log.items():
        new_data.append(i)
        new_data.append(j)
      new_data=np.array(new_data).reshape((len(new_data)/2),2)
      np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/drug_name_log.csv',new_data,delimiter=',',fmt="%s")
      f=open('/home/pavankumar/call-health-server/medibot/source/log/drug_cat_log.csv')
      f=csv.reader(f)
      cat_log={}
      for i in f:
        cat_log[i[0]]=i[1]
      x=[]
      for i in c:
        x.append(i[0])
      cat_log[sessid]=str('XXXXX'.join(x))
      new_data=[]
      for i,j in cat_log.items():
        new_data.append(i)
        new_data.append(j)
      new_data=np.array(new_data).reshape((len(new_data)/2),2)
      np.savetxt('/home/pavankumar/call-health-server/medibot/source/log/drug_cat_log.csv',new_data,delimiter=',',fmt="%s")
      options=list(c_uniq)
      if (len(options)>1):
       if (read_sess_name(sessid)!=''): 
         text=nltk.word_tokenize(read_sess_name(sessid))[0].capitalize()+' the medicine comes in the following forms. Please choose one to know the details'
       else:
         text='The medicine comes in the following forms. Please choose one to know the details' 
       sess_flow_id('input_dose_form',sessid)
       x=[]
       for i in options:
         x.append(i.capitalize())
       options=x
       op_json=text_ss_response_json(text,options,sessid)
       return (op_json)
      else:
        ip='1'
        sess_input(ip,sessid)
        sess_flow_id('drug_brand_names',sessid) 
        op_json=blank_response_json(sessid)
        return (op_json)     
    else:
      sess_flow_id('no_drug_match',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_dose_form'):
    ip=ip[0]
    sess_input(ip,sessid)
    sess_flow_id('drug_brand_names',sessid) 
    op_json=blank_response_json(sessid)
    return (op_json)     
  if (str(read_sess_flow_id(sessid))=='input_drug_brand_names'):
    ip=ip[0]
    temp=read_sess_input(sessid)
    ip='XXXXX'.join([ip,temp])
    sess_input(ip,sessid)
    sess_flow_id('drug_brand_names_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='drug_brand_names'):
    ip=read_sess_input(sessid)
    flag1=0
    flag2=0
    f=open('/home/pavankumar/call-health-server/medibot/source/log/drug_name_log.csv')
    f=csv.reader(f)
    name_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag1=1
        n=i[1].split('XXXXX')
        break
    f=open('/home/pavankumar/call-health-server/medibot/source/log/drug_cat_log.csv')
    f=csv.reader(f)
    cat_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag2=1
        c=i[1].split('XXXXX')
        break
    if ((flag1!=0) and (flag2!=0)):
      ip=read_sess_input(sessid)
      c_uniq=np.unique(c) 
      n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip)-1]==np.array(c))[0]]
      c_selected=np.array(c_uniq)[int(ip)-1]
      options=[]
      for i in n_final:
        options.append(i)
      if (len(options)>1):  
        text=('Please select the dosage')
        sess_flow_id('input_drug_brand_names',sessid)
        sess_input(ip,sessid)
        x=[]
        for i in options:
          x.append(i.capitalize())
        options=x 
        op_json=text_ss_response_json(text,options,sessid)
        return (op_json)
      else:
        ip='1'
        temp=read_sess_input(sessid)
        ip='XXXXX'.join([ip,temp])
        sess_input(ip,sessid)
        sess_flow_id('drug_brand_names_continue',sessid)
        op_json=blank_response_json(sessid)
        return (op_json)
  if (str(read_sess_flow_id(sessid))=='drug_brand_names_continue'):
    ip=read_sess_input(sessid).split('XXXXX')[0]
    ip1=read_sess_input(sessid).split('XXXXX')[1] 
    flag1=0
    flag2=0
    f=open('/home/pavankumar/call-health-server/medibot/source/log/drug_name_log.csv')
    f=csv.reader(f)
    name_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag1=1
        n=i[1].split('XXXXX')
        break
    f=open('/home/pavankumar/call-health-server/medibot/source/log/drug_cat_log.csv')
    f=csv.reader(f)
    cat_log={}
    for i in f:
      if (str(i[0])==str(sessid)):
        flag2=1
        c=i[1].split('XXXXX')
        break
    if ((flag1!=0) and (flag2!=0)):
      c_uniq=np.unique(c) 
      n_final=np.array(n)[np.where(np.array(c_uniq)[int(ip1)-1]==np.array(c))[0]]
      c_selected=np.array(c_uniq)[int(ip1)-1]
      for i,j in brand_molecule.items():
        if (i==n_final[int(ip)-1]):
          break
      comp=('YYYYY'.join(j[0]))
      brand_name=n_final[int(ip)-1]
      write_sess_brand(brand_name,sessid)
      cat_selected=c_selected
      sess_input(('XXXXX'.join([brand_name,comp,cat_selected])),sessid)
      sess_flow_id('mole_rx',sessid)
      op_json=blank_response_json(sessid)
    else:
      sess_flow_id('no_drug_match',sessid)
      op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='no_drug_match'):    
    text="Sorry! I don't understand"
    flow_id='main_menu'
    options=[]
    op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='mole_rx'):    
    rx_mole_list=[]
    f=open('/home/pavankumar/call-health-server/medibot/source/drug_rx_mole_master.csv')
    f=csv.reader(f)
    for i in f:
      rx_mole_list.append(i[0])
    ip=read_sess_input(sessid)
    ip=ip.split('XXXXX')
    c_selected=[ip[2]]
    mole=ip[1].split('YYYYY')
    vote=[]
    name=[]
    for i in rx_mole_list:
      count=0
      name.append(i) 
      for j in mole:
        for k in nltk.word_tokenize(j):
          if (i==k):
            count=count+1
      vote.append(count)
    if (np.sum(vote)>0):
      n=np.array(name)[np.where(np.max(vote)==np.array(vote))]	
      v=np.array(vote)[np.where(np.max(vote)==np.array(vote))]
      a='YYYYY'.join(n)
      b=c_selected[0]
      a='XXXXX'.join([a,b])
      sess_input(a,sessid)
      sess_flow_id('drugs_info_final',sessid)
      op_json=blank_response_json(sessid)
    else:
      text="Sorry! I did not find any information for the medicine"
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json) 
  if (str(read_sess_flow_id(sessid))=='drugs_info_final'):
    text='What do you want to know?'
    options=['Drug Use Information','Drug Mechanism of Action','Drug Contra-indications','Drug Physiologic effects','Drug Substitutes']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_drugs_info_final',sessid) 
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_drugs_info_final'):
    ip=ip[0]
    past=read_sess_input(sessid).split('XXXXX')
    temp=('XXXXX'.join([past[0],past[1],ip]))
    sess_input(temp,sessid)
    sess_flow_id('drugs_info_final_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='drugs_info_final_continue'):
    f=open('/home/pavankumar/call-health-server/medibot/source/drug_dis_contra.csv')
    f=csv.reader(f)
    dis_contra={}
    for i in f:
      dis_contra[i[0]]=i[1:]
    f=open('/home/pavankumar/call-health-server/medibot/source/drug_moa.csv')
    f=csv.reader(f)
    drug_moa={}
    for i in f:
      drug_moa[i[0]]=i[1:]
    f=open('/home/pavankumar/call-health-server/medibot/source/drug_pe_induces.csv')
    f=csv.reader(f)
    drug_pe={}
    for i in f:
      drug_pe[i[0]]=i[1:]
    f=open('/home/pavankumar/call-health-server/medibot/source/drug_uses.csv')
    f=csv.reader(f)
    drug_uses={}
    for i in f:
      drug_uses[i[0]]=[' '.join((', '.join(i[1:]).split('\n')))]
    ip=read_sess_input(sessid)
    ip=ip.split('XXXXX')
    choice=ip[2] 
    mole=ip[0].split('YYYYY')
    if (mole[0]!='404'):
      c_selected=ip[1]
      drug_info_uses=[]
      drug_info_uses.append('     The uses of the drug are:')
      drug_info_moa=[]
      drug_info_moa.append('     The following is the Mechanism of Action:')
      drug_info_contra=[]
      drug_info_contra.append('     The following is the drug contra indication:')
      drug_info_physio=[]
      drug_info_physio.append('     The following is the drug physiologic effects:')
      drug_info_subs=[]
      drug_info_subs.append('    The following are the substitutes for the drug:') 
      for i in mole:
        try:
          drug_info_uses.append(drug_uses[i][0].capitalize())
        except:
          pass
        try:
          drug_info_moa.append(str(i).capitalize()+' '+(' '.join(drug_moa[i])).capitalize())
        except:
          pass
        try:
          drug_info_contra.append(str(i).capitalize()+' '+(' '.join(dis_contra[i])).capitalize())
        except:
          pass
        try:         
          drug_info_physio.append(str(i).capitalize()+' '+(' '.join(drug_pe[i])).capitalize())
        except:
          pass
      subs=[]
      for i,j in brand_molecule.items():
        if (set(j[0])==set(mole)):
          if (j[1][0]==c_selected):
            subs.append(i)
      if (len(subs)>0):
        count=0
        for i in subs:
          if (count<=5): 
            drug_info_subs.append(i.title())
            count=count+1
      if (str(choice)=='1'):
        if (len(drug_info_uses)>1):
          options=drug_info_uses
        else:
          options=['Sorry!! No usage information is available for the medicine']
      if (str(choice)=='2'):
        if (len(drug_info_moa)>1):
          options=drug_info_moa
        else:
          options=['Sorry!! No mechanism of action information is available for the medicine']
      if (str(choice)=='3'):
        if (len(drug_info_contra)>1):
          options=drug_info_contra
        else:
          options=['Sorry!! No contra-indication information is available for the medicine']
      if (str(choice)=='4'):
        if (len(drug_info_physio)>1):
          options=drug_info_physio
        else:
          options=['Sorry!! No drug physiologic effects information is available for the medicine']
      if (str(choice)=='5'):
        if (len(drug_info_subs)>1):
          options=drug_info_subs
        else:
          options=['Sorry!! No substitute information is available for the medicine']
      text='Drugs Information: '+str(read_sess_brand(sessid).title())
      flow_id='more_drugs_info'
      op_json=text_blank_response_json(text,options,flow_id,sessid) 
    else:
      text=('Sorry!! I could not find any information relevant to your query\n')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='more_drugs_info'):
    text=('Do you want to know more about it?')
    options=['Yes','No']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_more_drugs_info',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_more_drugs_info'):
    ip=ip[0]
    if (str(ip)=='1'):
      sess_flow_id('drugs_info_final',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      text='Does this information help?'
      options=['Yes','No']
      op_json=text_ss_response_json(text,options,sessid)
      sess_flow_id('input_feedback_response',sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_diag_flow'):
    ip=ip
    sess_input(ip,sessid)
    sess_flow_id('diag_flow_continue',sessid)
    op_json=blank_response_json(sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='diag_flow'):
    text=('Tell me the name of the test you wish to know the details about')
    op_json=text_response_json(text,sessid)
    sess_flow_id('input_diag_flow',sessid)
    return (op_json)
  if (str(read_sess_flow_id(sessid))=='diag_flow_continue'):
    q=read_sess_input(sessid)
    res=diag_names_match(q)
    if (res[0][0]!='404'):
      names=res[0]
      codes=res[1]
      n=str('YYYYY'.join(list(names)))
      c=str('YYYYY'.join(list(codes)))
      n=str('XXXXX'.join([n,c])) 
      sess_input(n,sessid)
      sess_flow_id('select_diag_name',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
    else:
      text=('Sorry!! I could not find any diagnostic test relevant to your query..\n')
      options=[]
      flow_id='main_menu'
      op_json=text_blank_response_json(text,options,flow_id,sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='input_select_diag_name'):
      ip=ip[0]
      temp=read_sess_input(sessid)
      ip=('XXXXX'.join([temp,ip]))
      sess_input(ip,sessid)
      sess_flow_id('select_diag_name_continue',sessid)
      op_json=blank_response_json(sessid)
      return (op_json)
  if (str(read_sess_flow_id(sessid))=='select_diag_name'):
      ip=read_sess_input(sessid).split('XXXXX')
      names=ip[0].split('YYYYY')
      codes=ip[1].split('YYYYY')
      options=names
      names=np.array(names)
      if (len(options)>1): 
        text='Did you mean:'
        op_json=text_ss_response_json(text,options,sessid)
        sess_flow_id('input_select_diag_name',sessid)
        return (op_json)
      else:
        ip='1'
        temp=read_sess_input(sessid)
        ip=('XXXXX'.join([temp,ip]))
        sess_input(ip,sessid)
        sess_flow_id('select_diag_name_continue',sessid)
        op_json=blank_response_json(sessid)
        return (op_json)
  if (str(read_sess_flow_id(sessid))=='select_diag_name_continue'):
      ip=read_sess_input(sessid).split('XXXXX')
      names=ip[0].split('YYYYY')
      codes=ip[1].split('YYYYY')
      ip=ip[2]
      names=np.array(names) 
      name=names[int(ip)-1]
      code=codes[int(ip)-1]
      diag_price={}
      f=open('/home/pavankumar/call-health-server/medibot/source/diagnositic_test_price.csv')
      f=csv.reader(f)
      for i in f:
        diag_price[i[0]]=[i[1],i[2]]
      diag_info={}
      f=open('/home/pavankumar/call-health-server/medibot/source/diagnositic_test_info.csv')
      f=csv.reader(f)
      for i in f:
        diag_info[i[0]]=[i[1]]
      diag_package={}
      f=open('/home/pavankumar/call-health-server/medibot/source/diagnositic_test_package.csv')
      f=csv.reader(f)
      for i in f:
        diag_package[i[0]]=[i[1:]]
      diag_preq={}
      f=open('/home/pavankumar/call-health-server/medibot/source/lab_instructions.csv')
      f=csv.reader(f)
      for i in f:
        diag_preq[i[0]]=[i[1]]
      packages=[]
      for i,j in diag_package.items():
        if (code in j[0]):
          packages.append(i)
      if (len(packages)<=0):
        if (str(diag_preq[code][0])!=''):
          text='The test '+str(name)+' and has the following purpose \n'+str(diag_info[code][0])+'. Before you take the test '+str(diag_preq[code][0])
        else:
          text='The test '+str(name)+' and has the following purpose \n'+str(diag_info[code][0])
        options=[]
        flow_id='diag_feedback'
        op_json=text_blank_response_json(text.decode('windows-1252').strip(),options,flow_id,sessid)
      else:
        if (str(diag_preq[code][0])!=''):
          text='The test '+str(name)+' and has the following purpose \n'+str(diag_info[code][0])+'. Before you take the test '+str(diag_preq[code][0])+'\nThis test is available in the following packages\n'
        else:
          text='The test '+str(name)+' and has the following purpose \n'+str(diag_info[code][0])+'\nThis test is available in the following packages\n'
        options=packages
        flow_id='diag_feedback'
        op_json=text_blank_response_json(text.decode('windows-1252').strip(),options,flow_id,sessid)
      return (op_json) 
  if (str(read_sess_flow_id(sessid))=='diag_feedback'):
    text='Does this information help?'
    options=['Yes','No']
    op_json=text_ss_response_json(text,options,sessid)
    sess_flow_id('input_feedback_response',sessid)
    return (op_json)


