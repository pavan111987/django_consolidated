"""
Convert to json
"""

from bayesian.base import REngine
from rest_framework import serializers
import json

class ResultsSerializer(serializers.Serializer):
	"""
	To serialize response
	"""
	# OUTGOING FIELDS
	status = serializers.IntegerField(required=False)
	result = serializers.DictField(required=False)
	error = serializers.DictField(required=False)

	# INCOMING FIELDS
	api_key = serializers.CharField(required=False)
	age = serializers.IntegerField(required=False)
	gender = serializers.CharField(
		max_length=8, 
		required=False,
	)
	symptoms = serializers.ListField(
		required=False,
		child=serializers.CharField()
	)
	medical_history = serializers.ListField(
		required=False,
		child=serializers.CharField(),
	)
	clinical_findings = serializers.ListField(
		required=False,
		child=serializers.CharField(),
	)

	def authenticate_client(self, req_data):

		api_key = req_data.pop('api_key', None)
		print 'api_key', api_key
		if api_key is None:
			return False
		else:
			print api_key
			if api_key != '1234':
				return False
			else:
				return True

	def find_error_field(self, r_input):
		"""
		Checks if the input has any find_errors
		"""
		for key, value in r_input.iteritems():
			if value == None:
				return key

		return None

	def validate(self, req_data):
		"""
		Custom validation after auto-validation is done.
		Results are compiled and sent forward.
		"""
		print 'REQDATA', req_data
		age = req_data.pop('age', None)
		gender = req_data.pop('gender', None)
		symptoms = req_data.pop('symptoms', None)
		medical_history = req_data.pop('medical_history', None)
		clinical_findings = req_data.pop('clinical_findings', None)

		if not self.authenticate_client(req_data):
			error = {
				'code': 500,
				'message': 'Could not authenticate client',
				'data': None,
			}
			req_data['error'] = error
			req_data['status'] = 0

		else:

			r_input = {
				'age': age,
				'gender': gender,
				'symptoms': symptoms,
				'Medical History': medical_history,
				'Clinical Finding': clinical_findings,
			}

			error_field = self.find_error_field(r_input)
			if error_field is None:
				r_output = REngine.run(r_input)

				data = json.loads(r_output)

				result = {
					'code': 212,
					'message': "Success",
					'data': data,
				}

				req_data['result'] = result
				req_data['status'] = 1

			else:
				error = {
					'code': 400,
					'message': error_field + ': this field is required',
					'data': None,
				}
				req_data['error'] = error
				req_data['status'] = 0

		return req_data
