args <- commandArgs(trailingOnly = TRUE)

#########################################
#### Enter the Required inputs
#########################################
#library(e1071)
#library(rjson)

#age=35
#gender='M'

#symps<-as.data.frame(c('CONFUSION','PALPITATION','EXCESSIVE SWEATING'))


#hist_name<-as.data.frame(c('NONE'))

#clin_name<-as.data.frame(c('NONE'))

#ip_json<-toJSON(list(age=age,gender=gender,symptoms=symps,"Medical History"=hist_name,"Clinical Finding"=clin_name))

### "{\"age\":35,\"gender\":\"M\",\"symptoms\":{\"c(\\\"CONFUSION\\\", \\\"PALPITATION\\\", \\\"EXCESSIVE SWEATING\\\")\":[\"CONFUSION\",\"PALPITATION\",\"EXCESSIVE SWEATING\"]},\"Medical History\":{\"c(\\\"NONE\\\")\":\"NONE\"},\"Clinical Finding\":{\"c(\\\"NONE\\\")\":\"NONE\"}}"


ip_json<-as.character(args[1])

ip_json<-gsub("XXX","\"",ip_json)

#print (ip_json)

options(warn=-1)

library(e1071)
library(rjson)

options(warn=0)

age<-fromJSON(ip_json)$age
gender<-fromJSON(ip_json)$gender
symps<-as.data.frame(fromJSON(ip_json)$symptoms)
hist_name<-as.data.frame(fromJSON(ip_json)$"Medical History")
clin_name<-as.data.frame(fromJSON(ip_json)$"Clinical Finding")

###########################################################
################ Load the files for the input
###########################################################

x<-read.csv("C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\medical bayes test.csv")
prev_lookup<-read.csv("C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\prevalance lookup.csv")
dis_prev<-read.csv("C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\gen disease prev.csv")
symp_prev<-read.csv("C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\gen symptom prev.csv")
clin_find<-read.csv("C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\clinical finding.csv")
char_symp<-read.csv("C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\char symp.csv")
med_hist<-read.csv("C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\pmx.csv")

###########################################################
###################### Building the Bayesian
###########################################################
verify<-x

lp<-which((age>=prev_lookup[,2])*(age<=prev_lookup[,3])*(gender==prev_lookup[,4])==1)

dis_prev<-dis_prev[,c(1,(lp+1),18)]
dis_prev[dis_prev[,2]=="No",4]<-"0"
dis_prev[dis_prev[,2]=="Rare",4]<-"1"
dis_prev[dis_prev[,2]=="Uncommon",4]<-"2"
dis_prev[dis_prev[,2]=="Common",4]<-"4"
dis_prev[dis_prev[,2]=="Most Common",4]<-"8"

x_bayes<-x[,c(1,3,5)]
prev1<-dis_prev


p<-as.data.frame(NULL)
p[(1:(dim(dis_prev)[1])),1]<-1

for ( i in 1:(dim(symps)[1]))
{
temp_p<-as.data.frame(NULL)
px<-symp_prev[as.character(symps[i,1])==as.character(symp_prev[,1]),12]
for (j in 1:(dim(dis_prev)[1]))
{
idx<-((as.character(dis_prev[j,1])==as.character(x_bayes[,1]))*(as.character(symps[i,1])==as.character(x_bayes[,2])))
if (sum(idx)==0)
{
pxy<-0
}
if (sum(idx)>0)
{
pxy<-x_bayes[idx,3]
}
py<-dis_prev[j,3]
temp_p[j,1]<-(py*pxy)/(px)
}

dis<-dis_prev[,1]

temp_p<-cbind(dis,temp_p)
colnames(temp_p)<-c("DISEASE","SCORE")
rownames(temp_p)<-NULL
temp_p<-temp_p[order(temp_p[,1],decreasing=FALSE),]
temp_p[,2]<-(temp_p[,2]-min(temp_p[,2]))/(max(temp_p[,2])-min(temp_p[,2]))
p[,1]<-(p[,1])*(1+(10*temp_p[,2]))

}

p[p[,1]==min(p[,1]),1]<-0

p[,1]<-(p[,1]*as.numeric(dis_prev[,4]))

dis_final<-cbind(dis_prev[,1],p)


if (hist_name[1,1]!='NONE')
{

med_hist<-med_hist[,c(1,2,(2+lp))]
med_hist[as.character(med_hist[,3])=="No",4]<-"0"
med_hist[as.character(med_hist[,3])=="Rare",4]<-"4"
med_hist[as.character(med_hist[,3])=="Uncommon",4]<-"16"
med_hist[as.character(med_hist[,3])=="Common",4]<-"64"
med_hist[as.character(med_hist[,3])=="Most Common",4]<-"256"


bayes_hist<-med_hist[,c(1,2)]
colnames(bayes_hist)<-c("Disease.Name","Hist")


hist_name<-as.data.frame(hist_name)
rownames(hist_name)<-NULL
colnames(hist_name)<-c("Hist")

hist_temp<-as.data.frame(unique(bayes_hist[,1]))

for (j in 1:(dim(hist_temp)[1]))
{
  for (i in 1:(dim(hist_name)[1]))
   {
    hist_temp[j,2]<-(1+(sum((as.character(hist_name[i,1])==as.character(bayes_hist[,2]))*(as.character(hist_temp[j,1])==as.character(bayes_hist[,1])))/(length(unique(paste0(bayes_hist[,1],"_",bayes_hist[,2])))))/(1/length(unique(bayes_hist[,2]))))
   }
}


for (j in 1:(dim(hist_temp)[1]))
{
  for (i in 1:(dim(hist_name)[1]))
   {
   if (sum((((as.character(hist_temp[j,1])==as.character(med_hist[,1]))*(as.character(hist_name[i,1])==as.character(med_hist[,2])))==1))!=0)
   {
   hist_temp[j,2]<-hist_temp[j,2]*(as.numeric(med_hist[(((as.character(hist_temp[j,1])==as.character(med_hist[,1]))*(as.character(hist_name[i,1])==as.character(med_hist[,2])))==1),4]))[1]
   }
    
   }
}

hist_temp[is.na(hist_temp[,2]),2]<-0
hist_temp[hist_temp[,2]==0,2]<-1
hist_temp[hist_temp[,2]<1,2]<-hist_temp[hist_temp[,2]<1,2]+1

for (i in 1:(dim(hist_temp)[1]))
{ 
dis_final[as.character(hist_temp[i,1])==dis_final[,1],2]<-(hist_temp[i,2]*dis_final[as.character(hist_temp[i,1])==dis_final[,1],2])
}

}

if (clin_name[1,1]!='NONE')
{
clin_find<-clin_find[,c(1,2,2+lp)]
clin_bayes<-clin_find[,c(1,2)]

clin_find[as.character(clin_find[,3])=="No",4]<-"0"
clin_find[as.character(clin_find[,3])=="Rare",4]<-"4"
clin_find[as.character(clin_find[,3])=="Uncommon",4]<-"16"
clin_find[as.character(clin_find[,3])=="Common",4]<-"64"
clin_find[as.character(clin_find[,3])=="Most Common",4]<-"256"

clin_name<-as.data.frame(clin_name)
rownames(clin_name)<-NULL
colnames(clin_name)<-colnames(clin_bayes)[2]

find_temp<-as.data.frame(unique(clin_bayes[,1]))

for (j in 1:(dim(find_temp)[1]))
{
  for (i in 1:(dim(clin_name)[1]))
   {
    find_temp[j,2]<-(1+(sum((as.character(clin_name[i,1])==as.character(clin_bayes[,2]))*(as.character(find_temp[j,1])==as.character(clin_bayes[,1])))/(length(unique(paste0(clin_bayes[,1],"_",clin_bayes[,2])))))/(1/length(unique(clin_bayes[,2]))))
   }
}

for (j in 1:(dim(find_temp)[1]))
{
  for (i in 1:(dim(clin_name)[1]))
   {
   if (sum((((as.character(find_temp[j,1])==as.character(clin_find[,1]))*(as.character(clin_name[i,1])==as.character(clin_find[,2])))==1))!=0)
   {
   find_temp[j,2]<-find_temp[j,2]*as.numeric(clin_find[(((as.character(find_temp[j,1])==as.character(clin_find[,1]))*(as.character(clin_name[i,1])==as.character(clin_find[,2])))==1),4])
   }
    
   }
}

find_temp[is.na(find_temp[,2]),2]<-0
find_temp[find_temp[,2]==0,2]<-1
find_temp[find_temp[,2]<1,2]<-find_temp[find_temp[,2]<1,2]+1

for (i in 1:(dim(find_temp)[1]))
{ 
dis_final[as.character(find_temp[i,1])==dis_final[,1],2]<-(find_temp[i,2]*dis_final[as.character(find_temp[i,1])==dis_final[,1],2])
}

}

d<-as.data.frame(dis_final[order(dis_final[,2],decreasing=TRUE),][,1])
rownames(d)<-NULL
s<-as.data.frame(10*(dis_final[order(dis_final[,2],decreasing=TRUE),][,2]-min(dis_final[order(dis_final[,2],decreasing=TRUE),][,2]))/(max(dis_final[order(dis_final[,2],decreasing=TRUE),][,2])-min(dis_final[order(dis_final[,2],decreasing=TRUE),][,2])))
rownames(s)<-NULL


res<-cbind(d,s)
rownames(res)<-NULL
colnames(res)<-c("Disease","Score")

res<-res[order(res[,2],decreasing=TRUE),]

rownames(res)<-c(1:(dim(res)[1]))
rownames(res)<-NULL
res[,2]=''
res<-res[1:10,]

symps<-paste(symps[,1],collapse=' ')
res<-paste(res[,1],collapse=' ')

#################################################################
################ convert the result to a JSON
#################################################################

t<-read.csv("C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\automated_log.csv")
a<-as.data.frame(cbind(as.character(age),gender,symps,hist_name,clin_name,res))
colnames(a)<-colnames(t)
t<-rbind(t,a)
write.csv(t,file="C:\\Users\\pavankumar.buduguppa\\Documents\\Projects\\medical\\MED BAYES 4.0\\automated_log.csv",row.names=FALSE)


