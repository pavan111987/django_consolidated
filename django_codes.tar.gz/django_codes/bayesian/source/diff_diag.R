
#######################################
#### read the command line/ terminal level arguments...In this case we are reading a JSON sent by the Django server
#######################################

args <- commandArgs(trailingOnly = TRUE)


#########################################
#### Enter the Required inputs
#########################################
#library(e1071)
#library(rjson)

#age=35
#gender='M'

#symps<-as.data.frame(c('CONFUSION','PALPITATION','EXCESSIVE SWEATING'))


#hist_name<-as.data.frame(c('NONE'))

#clin_name<-as.data.frame(c('NONE'))

#ip_json<-toJSON(list(age=age,gender=gender,symptoms=symps,"Medical History"=hist_name,"Clinical Finding"=clin_name))

### "{\"age\":35,\"gender\":\"M\",\"symptoms\":{\"c(\\\"CONFUSION\\\", \\\"PALPITATION\\\", \\\"EXCESSIVE SWEATING\\\")\":[\"CONFUSION\",\"PALPITATION\",\"EXCESSIVE SWEATING\"]},\"Medical History\":{\"c(\\\"NONE\\\")\":\"NONE\"},\"Clinical Finding\":{\"c(\\\"NONE\\\")\":\"NONE\"}}"

###########################################
###### Read the JSON as a character string
##########################################
 
ip_json<-as.character(args[1])


##########################################
##### Decode the 'XXX' as '\"' which can be decoded by the 'rjson' library in R
##########################################

ip_json<-gsub("XXX","\"",ip_json)

#print (ip_json)

options(warn=-1)

library(e1071)
library(rjson)

options(warn=0)

##########################################
##### Parse the age, gende, symptoms, past medical history and Clinical findings variables from the JSON
##########################################

 
age<-fromJSON(ip_json)$age
gender<-fromJSON(ip_json)$gender
symps<-as.data.frame(fromJSON(ip_json)$symptoms)
hist_name<-as.data.frame(fromJSON(ip_json)$"Medical History")
clin_name<-as.data.frame(fromJSON(ip_json)$"Clinical Finding")

###########################################################
################ Load the files for the input
###########################################################

x<-read.csv("medical bayes test.csv")
symp_list<-unique(x[,3])
symp_list<-as.vector(symp_list[order(symp_list)])
prev_lookup<-read.csv("prevalance lookup.csv")
med_hist<-read.csv("pmx.csv")
clin_find<-read.csv("clinical finding.csv")
hist_map<-read.csv("pmx mapping.csv")
clin_list<-unique(clin_find[,2])
hist_list<-unique(hist_map[,1])
dis_icd<-read.csv("disease icd mapping.csv")
pmxpx<-read.csv("pmx px.csv")
clin_px<-read.csv("clinical finding px.csv")
prev_lookup<-read.csv("prevalance lookup.csv")
dis_prev<-read.csv("gen disease prev.csv")
symp_prev<-read.csv("gen symptom prev.csv")
clin_find<-read.csv("clinical finding.csv")
char_symp<-read.csv("char symp.csv")
med_hist<-read.csv("pmx.csv")
hist_map<-read.csv("pmx mapping.csv")


###########################################################
###################### Building the Bayesian
###########################################################
options(show.error.messages=FALSE)
library(e1071)
library(rjson)
options(show.error.messages=TRUE)

###########################################################
################ Load the files for the input
###########################################################
#symps<-as.data.frame(c('FEVER','RASH'))
#age<-40
#gender<-'M'
#hist_name<-as.data.frame(c('ALLERGY_ALMOND'))
#clin_name<-as.data.frame(c('NONE'))


#########################################################
################ This part of the code checks if all the symptoms entered are within the 526 symptoms
################ if the symptoms are other than the 526 the they will be ignored
#########################################################
 
temp<-as.data.frame(NULL)
count<-1

for (i in 1:length(symp_list))
{
for (j in 1:dim(symps)[1])
{
if (symps[j,1]==symp_list[i])
{
temp[count,1]<-symps[j,1]
count<-count+1
}

}
}


symps<-temp
###########################################################

###########################################################
###################### Building the Bayesian
###########################################################

verify<-x

########################################################## 
##################### This part of the code gets the disease prevalance for the age and gender
##########################################################

lp<-which((age>=prev_lookup[,2])*(age<=prev_lookup[,3])*(gender==prev_lookup[,4])==1)


##########################################################
#################### Here we assign weights/ scores to the disease prevalance 
#################### Tweak these weights only after a careful consideration of the error patterns 
##########################################################

dis_prev<-dis_prev[,c(1,(lp+1),18)]
dis_prev[dis_prev[,2]=="No",4]<-"0"
dis_prev[dis_prev[,2]=="Rare",4]<-"1"
dis_prev[dis_prev[,2]=="Uncommon",4]<-"2"
dis_prev[dis_prev[,2]=="Common",4]<-"4"
dis_prev[dis_prev[,2]=="Most Common",4]<-"8"

prev1<-dis_prev

############################################################
################### This part of the code applies the first level of bayesian probabilities
################### The output probabilities are based on the symptoms
################### The initial probabilities are set to 1
############################################################
 
x_bayes<-x[,c(1,3,5)]

p<-as.data.frame(NULL)
p[(1:(dim(dis_prev)[1])),1]<-1

for ( i in 1:(dim(symps)[1]))
{
temp_p<-as.data.frame(NULL)
px<-symp_prev[as.character(symps[i,1])==as.character(symp_prev[,1]),12]
for (j in 1:(dim(dis_prev)[1]))
{
idx<-((as.character(dis_prev[j,1])==as.character(x_bayes[,1]))*(as.character(symps[i,1])==as.character(x_bayes[,2])))
if (sum(idx)==0)
{
pxy<-0
}
if (sum(idx)>0)
{
pxy<-x_bayes[idx,3]
}
py<-dis_prev[j,3]
temp_p[j,1]<-(py*pxy)/(px)
}

##################################################
######### Here we convert the probabilities to score by multiplying them with the disease prevalance scores
##################################################

dis<-dis_prev[,1]

temp_p<-cbind(dis,temp_p)
colnames(temp_p)<-c("DISEASE","SCORE")
rownames(temp_p)<-NULL
#temp_p<-temp_p[order(temp_p[,1],decreasing=FALSE),]
temp_p[,2]<-(temp_p[,2]-min(temp_p[,2]))/(max(temp_p[,2])-min(temp_p[,2]))

##################################################
######## We always multiply the obtained score with (1 + obtained score) * priors
######## We do that to ensure the scores with Diseases with zeros due to one symptom are not lost 
#################################################

p[,1]<-(p[,1])*(1+(temp_p[,2]))

}

##################################################
######### Here we generate the obtained scores and Disease as a Data frame in the form of dis_final
##################################################

p[p[,1]==min(p[,1]),1]<-0

p[,1]<-(p[,1]*as.numeric(dis_prev[,4]))

dis_final<-cbind(dis_prev[,1],p)

#dis_final[order(dis_final[,2],decreasing=TRUE),][1:10,]


##################################################
########## If the past medical history entered is 'NONE' then this block of code will be skipped
##################################################
 
if (hist_name[1,1]!='NONE')
{


#################################################
########### The weights are assigned based on the feedback obtained from the MDP team
#################################################
 
med_hist<-med_hist[,c(1,2,(2+lp),19)]
med_hist[as.character(med_hist[,3])=="No",5]<-"0"
med_hist[as.character(med_hist[,3])=="Rare",5]<-"2"
med_hist[as.character(med_hist[,3])=="Uncommon",5]<-"4"
med_hist[as.character(med_hist[,3])=="Common",5]<-"8"
med_hist[as.character(med_hist[,3])=="Most Common",5]<-"16"


bayes_hist<-med_hist[,c(1,2)]
colnames(bayes_hist)<-c("Disease.Name","Hist")


hist_name<-as.data.frame(hist_name)
rownames(hist_name)<-NULL
colnames(hist_name)<-c("Hist")

hist_temp<-as.data.frame(unique(bayes_hist[,1]))

hist_name_final<-as.data.frame(NULL)
idx=1
for (i in 1:dim(hist_name)[1])
{
if ((as.character(hist_name[i,1])==as.character(hist_map[,1]))*1.0>0)
{
hist_name_final[idx,1]<-hist_map[as.character(hist_name[i,1])==as.character(hist_map[,1]),2][1]	
idx=idx+1
}
}

hist_name_final<-as.data.frame(unique(hist_name_final))

p<-as.data.frame(NULL)
p[1:(dim(hist_temp)[1]),1]<-1

for (i in (1:(dim(hist_name_final)[1])))
{
  if (sum(1.0*(as.character(hist_name_final[i,1])==as.character(bayes_hist[,2])))>0)
  { 
  t<-bayes_hist[as.character(bayes_hist[,2])==as.character(hist_name_final[i,1]),1]
  px<-pmxpx[as.character(pmxpx[,1])==as.character(hist_name_final[i,1]),2]
  for (j in (1:length(t)))
   {
    p[as.character(t[j])==as.character(hist_temp[,1]),1]<-(1+(p[as.character(t[j])==as.character(hist_temp[,1]),1]/px))
   }
  }
}

hist_temp[,2]<-p[,1]

for (j in 1:(dim(hist_temp)[1]))
{
  for (i in 1:(dim(hist_name_final)[1]))
   {
   if (sum((((as.character(hist_temp[j,1])==as.character(med_hist[,1]))*(as.character(hist_name_final[i,1])==as.character(med_hist[,2])))==1))!=0)
   {
   hist_temp[j,2]<-hist_temp[j,2]*(as.numeric(med_hist[(((as.character(hist_temp[j,1])==as.character(med_hist[,1]))*(as.character(hist_name_final[i,1])==as.character(med_hist[,2])))==1),4]))[1]
   }
    
   }
}

hist_temp[is.na(hist_temp[,2]),2]<-0
hist_temp[hist_temp[,2]==0,2]<-1
hist_temp[hist_temp[,2]<1,2]<-hist_temp[hist_temp[,2]<1,2]+1

#################################################################
######### updating of the disease and scores based on PMX
#################################################################
 
for (i in 1:(dim(hist_temp)[1]))
{ 
dis_final[as.character(hist_temp[i,1])==dis_final[,1],2]<-(hist_temp[i,2]*dis_final[as.character(hist_temp[i,1])==dis_final[,1],2])
}

}



if (clin_name[1,1]!='NONE')
{
clin_find<-clin_find[,c(1,2,2+lp)]
clin_bayes<-clin_find[,c(1,2)]

clin_find[as.character(clin_find[,3])=="No",4]<-"0"
clin_find[as.character(clin_find[,3])=="Rare",4]<-"1.5"
clin_find[as.character(clin_find[,3])=="Uncommon",4]<-"2.25"
clin_find[as.character(clin_find[,3])=="Common",4]<-"3.375"
clin_find[as.character(clin_find[,3])=="Most Common",4]<-"5.0625"

clin_name<-as.data.frame(clin_name)
rownames(clin_name)<-NULL
colnames(clin_name)<-colnames(clin_bayes)[2]


find_temp<-as.data.frame(unique(clin_bayes[,1]))

p<-as.data.frame(NULL)
p[(1:(dim(find_temp)[1])),1]<-1

for (i in 1:(dim(clin_name)[1]))
{
if (sum(1.0*(as.character(clin_name[i,1])==as.character(clin_bayes[,2])))>0)
  { 
  
t<-clin_bayes[as.character(clin_bayes[,2])==as.character(clin_name[i,1]),1]
px<-clin_px[as.character(clin_px[,1])==as.character(clin_name[i,1]),2]
for (j in (1:length(t)))
{
p[as.character(t[j])==as.character(find_temp[,1]),1]<-(1+(p[as.character(t[j])==as.character(find_temp[,1]),1]/px))
}
}
}

find_temp[,2]<-p[,1]



for (j in 1:(dim(find_temp)[1]))
{
  for (i in 1:(dim(clin_name)[1]))
   {
   if (sum((((as.character(find_temp[j,1])==as.character(clin_find[,1]))*(as.character(clin_name[i,1])==as.character(clin_find[,2])))==1))!=0)
   {
   find_temp[j,2]<-find_temp[j,2]*as.numeric(clin_find[(((as.character(find_temp[j,1])==as.character(clin_find[,1]))*(as.character(clin_name[i,1])==as.character(clin_find[,2])))==1),4])[1]
   }
    
   }
}

find_temp[is.na(find_temp[,2]),2]<-0
find_temp[find_temp[,2]==0,2]<-1
find_temp[find_temp[,2]<1,2]<-find_temp[find_temp[,2]<1,2]+1

for (i in 1:(dim(find_temp)[1]))
{ 
dis_final[as.character(find_temp[i,1])==dis_final[,1],2]<-(find_temp[i,2]*dis_final[as.character(find_temp[i,1])==dis_final[,1],2])
}

}

d<-as.data.frame(dis_final[order(dis_final[,2],decreasing=TRUE),][,1])
rownames(d)<-NULL
s<-as.data.frame(10*(dis_final[order(dis_final[,2],decreasing=TRUE),][,2]-min(dis_final[order(dis_final[,2],decreasing=TRUE),][,2]))/(max(dis_final[order(dis_final[,2],decreasing=TRUE),][,2])-min(dis_final[order(dis_final[,2],decreasing=TRUE),][,2])))
rownames(s)<-NULL


res<-cbind(d,s)
rownames(res)<-NULL




if (dim(res[round(res[,2],0)>=1,])[1]<=13)
{
res<-res[1:13,]
}
if (dim(res[round(res[,2],0)>=1,])[1]>13)
{
res<-res[round(res[,2],0)>=1,]
}

for (i in 1:(dim(res)[1]))
{
res[i,3]<-dis_icd[which(res[i,1]==dis_icd[,1]),2]
}

if (dim(res)[1]>13)
{
res<-res[1:13,]
}

res<-res[res[,2]>0,]

colnames(res)<-c("Disease","Score","ICD_10_Code")



#################################################################
################ convert the result to a JSON
#################################################################

res_json<-toJSON(split(res,(1:nrow(res))))

res_json

