import json
import os


object={}

object['age']=35
object['gender']='M'
object['symptoms']=['CONFUSION','PALPITATION','EXCESSIVE SWEATING']
object['Medical History']=['NONE']
object['Clinical Finding']=['NONE']


#### r expecting

#"{\"age\":35,\"gender\":\"M\",\"symptoms\":[\"CONFUSION\",\"PALPITATION\",\"EXCESSIVE SWEATING\"],\"Medical History\":[\"NONE\"],\"Clinical Finding\":[\"NONE\"]}"

#"{XXXClinical FindingXXX: [XXXNONEXXX], XXXgenderXXX: XXXMXXX, XXXageXXX: 35, XXXMedical HistoryXXX: [XXXNONEXXX], XXXsymtomsXXX: [XXXCONFUSIONXXX, XXXPALPITATIONXXX, XXXEXCESSIVE SWEATINGXXX]}"
##### python getting

ip_json=json.dumps(object)

ip_json=str(ip_json)
2p
enc_ip_json=str('XXX'.join(ip_json.split('"')))

command=str('Rscript diff_diag.R "'+enc_ip_json+'"')

os.system(command)

