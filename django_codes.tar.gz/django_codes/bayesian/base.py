"""
The processing is performed here
"""

import json
import subprocess
import os

class REngine:
	def __init__(self):
		pass

	@classmethod
	def run(cls, data):
		command = 'Rscript'
		script = 'diff_diag.R'

		data_json = str(json.dumps(data))
		data_json_cut = data_json.split('"')
		encoded_json = str("XXX".join(data_json_cut))
		encoded_json_arg = '"' + encoded_json + '"'

		# args = [encoded_json_arg]
		# line = [command, script] + args

		os.chdir('bayesian/source')
		os_command = str(command + ' ' + script + ' "' + encoded_json + '"')
		output = os.popen(os_command).read()
		os.chdir('../..')

		cleaned_output = output[4:]
		print output
		print 'PROCESSED OUTPUT'
		print cleaned_output
		# loading once with the "" coverts to unicode
		cleaned_output = json.loads(cleaned_output)

		return cleaned_output
