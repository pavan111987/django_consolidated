"""
Process requests
"""

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.serializers import ValidationError
from django.http import Http404

from bayesian.serializers import ResultsSerializer

class DiagnosisView(APIView):

	def post(self, request, format=None):
		# print 'REQUEST.DATA'
		# print request.data
		print request.META.get('HTTP_APIKEY')
		data = request.data.copy()
		data['api_key'] = request.META.get('HTTP_APIKEY', None)
		serializer = ResultsSerializer(data=data)

		if serializer.is_valid(raise_exception=True):
			return Response(serializer.data)
